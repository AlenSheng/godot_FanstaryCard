extends SceneTree
func _initialize() -> void:
    call_deferred("run")
func run() -> void:
    var ui_scripts = ["res://ui/main.gd", "res://ui/reference_ui.gd", "res://ui/season_journey_reward_view.gd", "res://ui/season_cosmetic_art.gd", "res://tests/ui_visual_review.gd"]
    for path in ui_scripts:
        var candidate = load(path)
        if candidate == null or not candidate.can_instantiate():
            quit(3)
            return
    var script = load("res://tests/test_journey_reward_controller.gd")
    if script == null or not script.can_instantiate():
        quit(2)
        return
    var result: Dictionary = await script.new().run_test()
    var failures: Array[String] = []
    for key in result.get("checks", {}):
        if not result.checks[key]: failures.append(key)
    var output := {"ok": result.get("ok", false) and failures.is_empty(), "checks": result.get("checks", {}).size(), "failures": failures, "case": result}
    var file := FileAccess.open("res://case-results.json", FileAccess.WRITE)
    file.store_string(JSON.stringify(output))
    file.close()
    print(JSON.stringify(output))
    quit(0 if output.ok else 1)
