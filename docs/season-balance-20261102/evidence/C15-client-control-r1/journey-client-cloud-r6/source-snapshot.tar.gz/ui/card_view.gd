extends Button

const Art = preload("res://ui/art.gd")
const P = preload("res://ui/palette.gd")
const CardDetails = preload("res://ui/card_details.gd")
const ElementRules = preload("res://state/element_rules.gd")
const CARD_SHADER = preload("res://ui/card_view.gdshader")
const BATTLE_FONT_SIZE := 24
const BATTLE_TEXT_BREAKS := TextServer.BREAK_MANDATORY | TextServer.BREAK_WORD_BOUND | TextServer.BREAK_ADAPTIVE
static var CLASS_NAMES: Dictionary = preload("res://data/localization_legacy.json").data.card_class_names
static var _materials: Dictionary = {}

static func clear_material_cache() -> void:
	_materials.clear()

func configure(id: String, info: Dictionary, description: String, selected: bool, options: Dictionary = {}) -> void:
	for child in get_children(): child.free()
	custom_minimum_size = Vector2(218, 376)
	clip_contents = true
	tooltip_text = P.localized_text(description)
	mouse_default_cursor_shape = Control.CURSOR_ARROW if disabled else Control.CURSOR_POINTING_HAND
	var monster: bool = info.get("source", "") == "Monster"
	var collection: bool = options.get("collection", false) and not options.get("preview", false) and not monster
	var copy_count: int = maxi(0, int(options.get("copy_count", 0)))
	var unowned: bool = collection and copy_count == 0
	material = _card_material(unowned) if unowned else null
	for state in ["normal", "disabled", "hover", "pressed"]:
		add_theme_stylebox_override(state, StyleBoxEmpty.new())
	add_theme_stylebox_override("focus", P.box(Color.TRANSPARENT, P.GOLD, 2))
	if monster:
		var backdrop := Art.image(self, Art.texture("Cards/Art/monster_card_backdrop.png"), Vector2.ZERO)
		backdrop.name = "MonsterBackdrop"
		backdrop.position = Vector2(14, 14)
		backdrop.size = Vector2(190, 285)
		backdrop.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	var illustration := Art.image(self, Art.card(id), Vector2.ZERO)
	illustration.name = "Illustration"
	illustration.position = Vector2(14, 14)
	illustration.size = Vector2(190, 285)
	if illustration.texture == null:
		_text(P.localized("illustration_missing"), Rect2(14, 112, 190, 60), 22, P.MUTED)
	if selected and options.get("selected_overlay", false):
		var selected_overlay := ColorRect.new()
		selected_overlay.name = "SelectedIllustrationOverlay"
		selected_overlay.color = Color(0.16, 0.18, 0.19, 0.62)
		selected_overlay.position = illustration.position
		selected_overlay.size = illustration.size
		selected_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
		selected_overlay.material = CanvasItemMaterial.new()
		add_child(selected_overlay)
	var quality: String = str(info.get("quality", "White")).to_lower()
	var frame_key := "UI/Cards/card_frame_monster_clean.png" if monster else "UI/Codex/qframe_%s.png" % quality
	var frame := Art.image(self, Art.texture(frame_key), Vector2.ZERO)
	frame.name = "CardFrame"
	frame.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	frame.stretch_mode = TextureRect.STRETCH_SCALE
	if monster: frame.material = _monster_frame_material()
	if not monster:
		if frame.texture == null: frame.texture = Art.texture("UI/Codex/qframe_common.png")
		if selected: frame.texture = Art.texture("UI/Codex/qframe_selected.png")
		frame.material = _card_material(unowned, true)
	var lines := description.split("\n\n", true, 1)
	var passed_effect: String = lines[1] if lines.size() > 1 else description
	# Build compact summaries from the catalog's effects and level growth so
	# upgraded cards cannot reuse the base-level numbers from the text table.
	var effect: String = passed_effect if options.get("configured_description", false) else CardDetails.face_description(id, int(options.get("level", 0)), info)
	if effect.is_empty(): effect = _face_description(id, passed_effect)
	set_meta("battle_layout", bool(options.get("battle_layout", false)))
	if options.get("battle_layout", false):
		_battle_text(id, info, effect, selected, options, monster)
	elif monster:
		_monster_text(id, info, effect, selected, int(options.get("level", 0)))
	else:
		var level := int(options.get("level", 0))
		# card_view.gdshader moves the frame's text panel below the portrait:
		# its usable interior is y=303..357, not the source texture's y=256..348.
		var title := _text(CardDetails.localized_face_name(id, info), Rect2(24, 303, 170, 28), 18, P.PAPER if unowned else P.GOLD, true, P.scaled_font("title"))
		title.name = "CardName"
		var effect_label := _text(effect.replace("\n", " "), Rect2(24, 331, 170, 24), 16, P.PAPER, false)
		effect_label.name = "CardEffect"
		effect_label.max_lines_visible = 1
		effect_label.autowrap_mode = TextServer.AUTOWRAP_OFF
		effect_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		_fit_card_effect_font(effect_label, 16)
		var hero_class: String = P.word(info.get("hero_class", ""))
		if not hero_class.is_empty(): _class_badge(str(info.get("hero_class")), hero_class)
		var battle_element_hint := _battle_element_hint(str(info.get("element", "None")), str(options.get("battle_target_element", "None")))
		if not battle_element_hint.is_empty(): _battle_element_badge(battle_element_hint)
		elif level > 0: _level_badge(level)
		if selected:
			var selection := _text(P.localized("selected"), Rect2(75, 260, 68, 33), 18, P.GOLD)
			selection.name = "SelectedIndicator"
			var selection_style := P.box(Color("172d35"), P.GOLD, 1)
			for side in [SIDE_LEFT, SIDE_TOP, SIDE_RIGHT, SIDE_BOTTOM]: selection_style.set_content_margin(side, 0)
			selection.add_theme_stylebox_override("normal", selection_style)
	for child in get_children():
		# Ownership remains visible in the illustration/frame. Keep readable text
		# on the standard font path rather than dimming glyphs with that shader.
		if child is Label: child.use_parent_material = false
		elif child is CanvasItem and child.material == null: child.use_parent_material = true

## Battle cards keep the five authored slots and original illustration bounds.
## Their text determines the height of an opaque panel above the artwork.
## A 24px design font remains 12 physical pixels at the supported 960px width.
## Collection and shop cards continue through their existing layout above.
func _battle_text(id: String, info: Dictionary, effect: String, selected: bool, options: Dictionary, monster: bool) -> void:
	var font_size := maxi(BATTLE_FONT_SIZE, int(options.get("battle_font_size", BATTLE_FONT_SIZE)))
	var text_width := 174.0
	var title_text := CardDetails.localized_face_name(id, info)
	var effect_text := effect.replace(P.localized("card_face_separator"), "\n")
	var title_font := P.scaled_font("title")
	var effect_font := P.font_for_text(effect_text, font_size, true)
	var title_height := ceilf(title_font.get_multiline_string_size(title_text, HORIZONTAL_ALIGNMENT_CENTER, text_width, font_size, -1, BATTLE_TEXT_BREAKS).y) + 6.0
	var effect_height := ceilf(effect_font.get_multiline_string_size(effect_text, HORIZONTAL_ALIGNMENT_CENTER, text_width, font_size, -1, BATTLE_TEXT_BREAKS).y) + 8.0
	var text_top := maxf(52.0, 360.0 - title_height - effect_height - 8.0)
	var panel := Panel.new()
	panel.name = "BattleTextPanel"
	panel.position = Vector2(16, text_top - 6.0)
	panel.size = Vector2(186, 366.0 - panel.position.y)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var panel_style := P.box(Color("101b21"), P.GOLD if selected else Color("47626a"), 2)
	for side in [SIDE_LEFT, SIDE_TOP, SIDE_RIGHT, SIDE_BOTTOM]: panel_style.set_content_margin(side, 0)
	panel.add_theme_stylebox_override("panel", panel_style)
	add_child(panel)
	var title := _text(title_text, Rect2(22, text_top, text_width, title_height), font_size, P.PAPER if monster else P.GOLD, false, title_font)
	title.name = "MonsterName" if monster else "CardName"
	_battle_label(title, "card_name")
	var summary_rect := Rect2(22, text_top + title_height + 8.0, text_width, effect_height)
	var summary := _text(effect_text, summary_rect, font_size, P.PAPER, false, effect_font)
	summary.name = "MonsterEffect" if monster else "CardEffect"
	_battle_label(summary, "card_effect")
	set_meta("battle_required_text_height", title_height + effect_height + 8.0)
	set_meta("battle_text_top", text_top)
	set_meta("battle_art_height", 285.0)
	set_meta("battle_effect_parts", effect_text.split("\n").size())
	set_meta("battle_summary_rect", summary_rect)
	set_meta("battle_font_size", font_size)
	if not monster:
		var hero_class := str(info.get("hero_class", ""))
		if not P.word(info.get("hero_class", "")).is_empty(): _class_badge(hero_class, P.word(hero_class))
		var hint := _battle_element_hint(str(info.get("element", "None")), str(options.get("battle_target_element", "None")))
		if not hint.is_empty(): _battle_element_badge(hint)
		elif int(options.get("level", 0)) > 0: _level_badge(int(options.level))

func _battle_label(label: Label, role: String) -> void:
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.max_lines_visible = -1
	label.text_overrun_behavior = TextServer.OVERRUN_NO_TRIMMING
	label.add_theme_constant_override("line_spacing", 0)
	label.set_meta("battle_primary_text", true)
	label.set_meta("battle_text_role", role)
	label.set_meta("minimum_effective_font_size", 12.0)

func _face_description(id: String, fallback: String) -> String:
	var locale := P.language()
	if locale not in ["zh-CN", "en"]: return fallback
	var descriptions: Dictionary = P.language_pack_section("card_descriptions")
	var configured := str(descriptions.get("card.face.desc." + id, "")).strip_edges()
	return configured if not configured.is_empty() else fallback

func _card_material(grayscale: bool, reframe: bool = false) -> ShaderMaterial:
	var key := ("gray" if grayscale else "color") + ("_frame" if reframe else "_body")
	if not _materials.has(key):
		var result := ShaderMaterial.new()
		result.shader = CARD_SHADER
		result.set_shader_parameter("grayscale", grayscale)
		result.set_shader_parameter("reframe", reframe)
		_materials[key] = result
	return _materials[key]

func _monster_frame_material() -> ShaderMaterial:
	if not _materials.has("monster_frame"):
		var result := ShaderMaterial.new()
		result.shader = CARD_SHADER
		result.set_shader_parameter("monster_reframe", true)
		_materials["monster_frame"] = result
	return _materials["monster_frame"]

func _level_badge(level: int) -> void:
	var badge := Art.image(self, Art.texture("UI/Codex/mana_cost_badge.png"), Vector2.ZERO)
	badge.name = "CardLevelBadge"
	badge.position = Vector2(2, 3)
	badge.size = Vector2(37, 37)
	var value := _text(str(level), Rect2(4, 5, 33, 33), 20, P.PAPER)
	value.name = "CardLevel"

func _battle_element_hint(card_element: String, target_element: String) -> String:
	if card_element not in ["Fire", "Wood", "Water", "Metal", "Earth"]: return ""
	if target_element not in ["Fire", "Wood", "Water", "Metal", "Earth"]: return ""
	if ElementRules.counters(card_element, target_element): return "recommended"
	if ElementRules.counters(target_element, card_element): return "countered"
	return ""

func _battle_element_badge(kind: String) -> void:
	var badge := Panel.new()
	badge.name = "BattleElementHintBadge"
	badge.position = Vector2(2, 3)
	badge.size = Vector2(37, 37)
	badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := StyleBoxFlat.new()
	style.bg_color = Color("287db6") if kind == "recommended" else Color("a9433d")
	style.border_color = Color("8ed7f0") if kind == "recommended" else Color("f0aaa0")
	style.set_border_width_all(2)
	style.set_corner_radius_all(18)
	badge.add_theme_stylebox_override("panel", style)
	add_child(badge)
	var badge_key := "battle_card_recommended_badge" if kind == "recommended" else "battle_card_countered_badge"
	var tooltip_key := "battle_card_recommended_tooltip" if kind == "recommended" else "battle_card_countered_tooltip"
	var label := _text(P.localized(badge_key), Rect2(2, 2, 33, 33), 17, P.PAPER)
	label.name = "BattleElementHintText"
	badge.tooltip_text = P.localized(tooltip_key)

func _class_badge(hero_class: String, symbol: String) -> void:
	# The pad sits below the sprite so its 28x28 rectangle cannot cover the
	# decorative ring; the ring's opaque pixels mask the pad at the edges.
	var center_back := ColorRect.new()
	center_back.name = "ClassBadgeCenter"
	center_back.color = Color("080b0c")
	center_back.position = Vector2(171, 10)
	center_back.size = Vector2(28, 28)
	center_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center_back)
	var badge := Art.image(self, Art.texture("UI/Codex/class_badge_%s.png" % hero_class.to_lower()), Vector2.ZERO)
	badge.name = "ClassBadge"
	badge.position = Vector2(156, -5)
	badge.size = Vector2(58, 58)
	badge.tooltip_text = P.localized_text(P.localized("class_restriction") % P.localized_text(CLASS_NAMES.get(hero_class, symbol)))
	badge.mouse_filter = Control.MOUSE_FILTER_PASS
	var label := _text(symbol, Rect2(168, 7, 34, 34), 22, P.PAPER)
	label.name = "ClassSymbol"
	tooltip_text += "\n\n" + badge.tooltip_text

func _monster_text(id: String, info: Dictionary, effect: String, selected: bool, level: int = 0) -> void:
	var banner := ColorRect.new()
	banner.color = Color(0.03, 0.06, 0.08, 0.88)
	banner.position = Vector2(17, 28)
	banner.size = Vector2(184, 34)
	banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(banner)
	var title_text := P.localized("monster") + " " + CardDetails.localized_face_name(id, info)
	if P.language() != "zh-CN": title_text = CardDetails.localized_face_name(id, info)
	var title := _text(title_text, Rect2(19, 28, 180, 34), 21, P.PAPER, true, P.scaled_font("title"))
	title.name = "MonsterName"
	var effect_label := _text(effect, Rect2(21, 304, 176, 38), 17, P.PAPER)
	effect_label.name = "MonsterEffect"
	effect_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	effect_label.max_lines_visible = 1
	effect_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	if id == "M-BOXSPIRIT":
		var element: String = info.get("element", "None")
		_text(P.word(element), Rect2(116, 258, 80, 35), 23, P.ELEMENT.get(element, Color.WHITE)).name = "MonsterElement"
	_text(P.localized("card_monster_selected") if selected else P.localized("battle_monster_card"), Rect2(24, 344, 170, 19), 13, P.GOLD if selected else Color("d3b6ab")).name = "MonsterFooter"

func _fit_card_effect_font(label: Label, requested_size: int) -> void:
	var typeface: Font = P.font_for_text(label.text, requested_size, true)
	# Faces reserve one summary line. Keep its authored size; the tooltip and
	# card details retain the complete effects when the summary is elided.
	label.add_theme_font_override("font", typeface)
	label.add_theme_font_size_override("font_size", requested_size)

func _text(value: String, rect: Rect2, font_size: int, color: Color, fit_to_rect: bool = true, typeface_override: Font = null) -> Label:
	var label := Label.new()
	var display_text := P.system_display_text(P.localized_text(value))
	label.text = display_text
	P.apply_text_direction(label)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	label.clip_text = true
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var typeface: Font = typeface_override if typeface_override != null else P.font_for_text(display_text, font_size, true)
	label.add_theme_font_override("font", typeface)
	label.add_theme_font_size_override("font_size", P.fit_font_size(typeface, font_size, rect.size.y, rect.size.x - 8.0, display_text) if fit_to_rect else font_size)
	label.add_theme_color_override("font_color", color)
	add_child(label)
	label.position = rect.position
	label.size = rect.size
	if fit_to_rect: P.fit_control_font(label, typeface, font_size, 8.0)
	return label
