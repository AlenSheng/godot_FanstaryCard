extends SceneTree
func _initialize() -> void:
    call_deferred("run")
func run() -> void:
    var script = load("res://tests/test_journey_reward_controller.gd")
    if script == null or not script.can_instantiate():
        quit(2)
        return
    var result: Dictionary = await script.new().run_test()
    var failures: Array[String] = []
    for key in result.get("checks", {}):
        if not result.checks[key]: failures.append(key)
    var output := {"ok": result.get("ok", false) and failures.is_empty(), "checks": result.get("checks", {}).size(), "failures": failures, "case": result}
    var file := FileAccess.open("res://case-results.json", FileAccess.WRITE)
    file.store_string(JSON.stringify(output))
    file.close()
    print(JSON.stringify(output))
    quit(0 if output.ok else 1)
