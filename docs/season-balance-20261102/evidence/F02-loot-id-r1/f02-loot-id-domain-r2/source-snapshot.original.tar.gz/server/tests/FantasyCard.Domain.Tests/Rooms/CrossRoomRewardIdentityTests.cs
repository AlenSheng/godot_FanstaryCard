using System.Text.Json;
using FantasyCard.Domain.Combat;
using FantasyCard.Domain.Configuration;
using FantasyCard.Domain.Players;
using FantasyCard.Domain.Rooms;
using FantasyCard.Domain.Seasons;
using FantasyCard.Domain.Tests.Combat;

namespace FantasyCard.Domain.Tests.Rooms;

public sealed class CrossRoomRewardIdentityTests
{
    private const int Seed = 73;
    private static readonly Guid FirstRoom = Guid.Parse("68e94e64-682d-44d4-bdd4-5d4e60bccb01");
    private static readonly Guid SecondRoom = Guid.Parse("68e94e64-682d-44d4-bdd4-5d4e60bccb02");

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void SameSeedRoomsMintDifferentEquipmentWhileRewardDataStayEqual(bool seasonal)
    {
        var first = ClearedRoom(FirstRoom, seasonal);
        var second = ClearedRoom(SecondRoom, seasonal);
        var a = Assert.Single(first.Capture().Players).RewardChoice!;
        var b = Assert.Single(second.Capture().Players).RewardChoice!;
        var firstItem = a.Options.Single(x => x.Kind == RewardChoiceKind.Equipment).Item!;
        var secondItem = b.Options.Single(x => x.Kind == RewardChoiceKind.Equipment).Item!;
        var output = Environment.GetEnvironmentVariable("FANTASYCARD_LOOT_ID_PROOF_OUTPUT");
        if (output is not null)
            File.AppendAllText(output, JsonSerializer.Serialize(new { seasonal, seed = Seed, first = first.Capture(), second = second.Capture(),
                item_ids_equal = firstItem.ItemId == secondItem.ItemId, controlled_one_HP_fixtures = 2, timed_routes = 0 }) + Environment.NewLine);
        Assert.Equal(firstItem.Equipment, secondItem.Equipment);
        Assert.Equal(a.Options.Select(x => (x.OptionId, x.Kind, x.HealPercent, x.Item?.Quantity)), b.Options.Select(x => (x.OptionId, x.Kind, x.HealPercent, x.Item?.Quantity)));
        Assert.Equivalent(first.Capture().RandomStreams, second.Capture().RandomStreams, strict: true);
        Assert.NotEqual(firstItem.ItemId, secondItem.ItemId);
    }

    private static BattleRoom ClearedRoom(Guid roomId, bool seasonal)
    {
        var config = GameConfigCatalog.Current;
        var catalog = CombatCardCatalog.Create(config);
        var context = seasonal ? new SeasonContext("f02-loot-id", 0, "season-v1", config.Version, "season-equipment-v1") : null;
        var room = new BattleRoom(roomId, config.Version, catalog, Seed, season: context);
        var player = room.AddPlayer(new(Guid.NewGuid(), HeroClass.Mage, SeasonFenxianTests.Starter(HeroClass.Mage), null));
        room.InitializeMap(ChaosMapGenerator.Generate(Seed, 1, seasonal ? config.SeasonThemes : null));
        // Identity fixture only: actual resolver/choice path, with controlled one-HP targets. No route/balance claim.
        foreach (var monster in player.Pve!.Monsters.ToArray())
        {
            monster.TakeDamage(monster.Hp + monster.Shield - 1);
            SeasonFenxianTests.SetHand(player, "C01");
            room.PlayCards(player.PlayerId, player.Pve.BattleId, monster.MonsterId, [player.Combat.Deck.Hand[0].InstanceId],
                room.Revision, DateTimeOffset.UnixEpoch, room.NewCombatActionId(player.PlayerId));
            room.Advance(TimeSpan.FromMilliseconds(500), DateTimeOffset.UnixEpoch);
        }
        Assert.Equal(RoomPlayerPhase.Choice, player.Phase);
        return room;
    }
}
