using System.Globalization;
using System.Net;
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Text.Json;
using FantasyCard.Contracts.Realtime;
using FantasyCard.Domain.Combat;
using FantasyCard.Domain.Configuration;
using FantasyCard.Domain.Players;
using FantasyCard.Domain.Rooms;
using FantasyCard.Domain.Seasons;
using FantasyCard.Server.Common;
using FantasyCard.Server.Rooms;
using FantasyCard.Server.Seasons;
using FantasyCard.Server.Tests.Config;
using FantasyCard.Server.Tests.Persistence;
using Npgsql;

namespace FantasyCard.Server.Tests.EndToEnd;

public sealed partial class ProcessLifecycleRecoveryTests
{
    [Theory(Skip = "Requires an owned local PostgreSQL database.", SkipUnless = nameof(HasPrivateDatabase))]
    [Trait("Category", "PostgresIntegration")]
    [InlineData("valid")]
    [InlineData("missing")]
    [InlineData("corrupt")]
    public async Task Full_host_original16_and_current17_credit_survive_abrupt_restart_and_bad_archive_isolation(string archiveState)
    {
        await using var db = await PostgresTestSchema.CreateAsync(migrate: false);
        Record("SEASON17-schema", new { schema = new NpgsqlConnectionStringBuilder(db.ConnectionString).SearchPath, archiveState });
        await db.MigrateAsync();
        using var deadline = Deadline(90); var ct = deadline.Token;
        using var archive = new ConfigArchiveDirectory();
        var originalBytes = File.ReadAllBytes(FindOriginal16());
        var original = GameConfigCatalog.Load(originalBytes); var current = GameConfigCatalog.Current;
        Assert.Equal("season-v1-config-16", original.Version); Assert.Equal("season-v1-config-17", current.Version);
        PublishedConfigTestInputs.Store(archive.Root, original.Version, originalBytes, original.ContentHash);
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var oldSeason = SeasonDefinition.FromCalendarDays("process-original16", today.AddDays(-49), original.Version, "season-equipment-v1", highestOpenDifficulty: 5);
        var newSeason = SeasonDefinition.FromCalendarDays("process-current17", today.AddDays(-7), current.Version, "season-equipment-v1", highestOpenDifficulty: 5);
        var seasons = new SeasonRepository(db.DataSource, TimeProvider.System);
        await seasons.PublishAsync(oldSeason, original.ContentHash, ct, original);
        await seasons.PublishAsync(newSeason, current.ContentHash, ct, current);
        var oldPlayer = await SeedPlayerAsync(db, "Original16 credit", ct);
        var newPlayer = await SeedPlayerAsync(db, "Current17 credit", ct);
        var old = await SeedSeasonCreditRoom(db, original, oldSeason, oldPlayer.Id, null, ct);
        var next = await SeedSeasonCreditRoom(db, current, newSeason, newPlayer.Id, .75, ct);
        using var metrics = new ServerMetrics(); var snapshots = new RoomSnapshotRepository(db.DataSource, TimeProvider.System, metrics);
        await snapshots.SaveIfDueAsync(old.Room.Capture(), ct); await snapshots.SaveIfDueAsync(next.Room.Capture(), ct);
        var ledgerBefore = await db.ScalarAsync<long>("SELECT count(*) FROM economy_ledger");
        const string walletQuery = "SELECT jsonb_build_object('wallets',(SELECT jsonb_agg(to_jsonb(w) ORDER BY player_id) FROM player_wallets w),'materials',(SELECT jsonb_agg(to_jsonb(m) ORDER BY player_id) FROM player_materials m),'season',(SELECT jsonb_agg(to_jsonb(s) ORDER BY player_id,season_id) FROM player_season_wallets s))::text";
        var walletsBefore = await db.ScalarAsync<string>(walletQuery);
        var port = ReservePort(); using var oldClient = Client(port, oldPlayer.Token); using var newClient = Client(port, newPlayer.Token);
        int firstPid;
        await using (var first = FullHost.Start(db.ConnectionString, port, "season17-" + archiveState + "-before", configArchiveDirectory: archive.Root))
        {
            firstPid = first.ProcessId;
            await first.WaitForHealthAsync(newClient, "/health/ready", HttpStatusCode.OK, ct);
            using var oldSocket = await ConnectAsync(oldClient, port, ct);
            using var newSocket = await ConnectAsync(newClient, port, ct);
            AssertCredit(await SnapshotAsync(oldSocket, ct), old.Room.Capture(), null);
            AssertCredit(await SnapshotAsync(newSocket, ct), next.Room.Capture(), .75);
            // Keep both sockets live until the OS process is gone. No graceful
            // disconnect checkpoint or expiry is substituted for abrupt death.
            await first.KillAsync();
        }
        var durableOld = await snapshots.GetAsync(old.Room.RoomId, ct); var durableNew = await snapshots.GetAsync(next.Room.RoomId, ct);
        Assert.NotNull(durableOld); Assert.NotNull(durableNew);
        var rawOld = await db.ScalarAsync<string>("SELECT snapshot_json::text FROM room_snapshots WHERE room_id=$1", old.Room.RoomId);
        var originalPath = Path.Combine(archive.Root, original.Version, "fantasycard.config.bytes");
        if (archiveState == "missing") File.Delete(originalPath);
        if (archiveState == "corrupt") { var bytes = File.ReadAllBytes(originalPath); bytes[^1] ^= 1; File.WriteAllBytes(originalPath, bytes); }
        int secondPid;
        await using (var second = FullHost.Start(db.ConnectionString, port, "season17-" + archiveState + "-after", configArchiveDirectory: archive.Root))
        {
            secondPid = second.ProcessId; Assert.NotEqual(firstPid, secondPid);
            await second.WaitForHealthAsync(newClient, "/health/ready", archiveState == "valid" ? HttpStatusCode.OK : HttpStatusCode.ServiceUnavailable, ct);
            using var newSocket = await ConnectAsync(newClient, port, ct);
            AssertCredit(await SnapshotAsync(newSocket, ct), durableNew, .75);
            if (archiveState == "valid")
            {
                using var oldSocket = await ConnectAsync(oldClient, port, ct);
                AssertCredit(await SnapshotAsync(oldSocket, ct), durableOld, null);
            }
            else
            {
                Assert.Equal(rawOld, await db.ScalarAsync<string>("SELECT snapshot_json::text FROM room_snapshots WHERE room_id=$1", old.Room.RoomId));
                Assert.Contains(old.Room.RoomId.ToString(), second.CapturedOutput, StringComparison.OrdinalIgnoreCase);
            }
            var savedSnapshot = (await snapshots.GetAsync(next.Room.RoomId, ct))!;
            Assert.Equal(durableNew.RandomStreams, savedSnapshot.RandomStreams);
            var saved = Assert.Single(savedSnapshot.Players);
            Assert.Equal(.75, saved.Combat.FenxianReturnCredit); Assert.Equal(500, saved.Combat.FenxianReturnRateBasisPoints);
            Assert.Equal("Running", await db.ScalarAsync<string>("SELECT status FROM matches WHERE match_id=$1", old.Match));
            Assert.Equal("Running", await db.ScalarAsync<string>("SELECT status FROM matches WHERE match_id=$1", next.Match));
            Assert.Equal(0L, await db.ScalarAsync<long>("SELECT count(*) FROM match_settlements"));
            Assert.Equal(ledgerBefore, await db.ScalarAsync<long>("SELECT count(*) FROM economy_ledger"));
            Assert.Equal(walletsBefore, await db.ScalarAsync<string>(walletQuery));
        }
        Record("SEASON17-credit-restart", new { archiveState, firstPid, secondPid, originalVersion = original.Version, currentVersion = current.Version,
            oldRoom = old.Room.RoomId, newRoom = next.Room.RoomId, credit = .75, rateBasisPoints = 500, originalPolicy = "SeasonBoundedRhythm",
            newPolicy = "SeasonRateBudgetedRhythm", newMatchesSimulated = 0, newB05Encounters = 0, newD03Encounters = 0,
            checkpointScope = "Declared idle ActionBar checkpoints; no battle actions or full entry/settlement acceptance", rawOldAfterFirstKillSha256 = Convert.ToHexString(SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(rawOld))).ToLowerInvariant() });
    }

    private static void AssertCredit(RoomSnapshotEventPayload actual, BattleRoomSnapshot expected, double? credit)
    {
        var player = Assert.Single(expected.Players);
        Assert.Equal(expected.RoomId, actual.RoomId); Assert.Equal(expected.ConfigVersion, actual.ConfigVersion);
        Assert.Equal(expected.Season!.SeasonId, actual.Season!.SeasonId); Assert.Equal("ActionBar", actual.Player.Phase);
        Assert.Equal(player.Combat.Deck.Hand.Select(c => c.InstanceId), actual.Player.Hand.Select(c => c.InstanceId));
        Assert.Equal(player.Combat.Deck.Library.Count, actual.Player.LibraryCount);
        var numerical = actual.Player.NumericalState!;
        Assert.Equal(credit is null ? "SeasonBoundedRhythm" : "SeasonRateBudgetedRhythm", numerical.FenxianPolicy);
        Assert.Equal(credit?.ToString("R", CultureInfo.InvariantCulture), numerical.FenxianReturnCredit);
        Assert.Equal(credit is null ? (int?)null : 500, numerical.FenxianReturnRateBasisPoints);
        Assert.Equal(70, actual.Player.Combat.MaximumHp); Assert.Equal(player.Combat.Hp, actual.Player.Combat.Hp);
    }

    private static async Task<(Guid Match, BattleRoom Room)> SeedSeasonCreditRoom(PostgresTestSchema db, GameConfigCatalog config, SeasonDefinition season, Guid player, double? credit, CancellationToken ct)
    {
        var match = Guid.NewGuid(); var catalog = CombatCardCatalog.Create(config);
        var room = new BattleRoom(Guid.NewGuid(), config.Version, catalog, 73, season: season.ContextFor(0));
        var cards = Enumerable.Range(1, 13).Select(i => $"C{i:D2}").Concat(Enumerable.Range(1, 6).Select(i => $"MAG-{i:D2}")).Append("MAG-10").ToArray();
        room.AddPlayer(new(player, HeroClass.Mage, cards, null)); room.InitializeMap(ChaosMapGenerator.Generate(73, 1));
        var snapshot = room.Capture(); var position = snapshot.Map!.Cells.First(c => c.HasEvacuation).Position;
        var self = Assert.Single(snapshot.Players);
        room = BattleRoom.Restore(snapshot with { Players = [self with { Position = position, Phase = RoomPlayerPhase.ActionBar, Pve = null,
            ClearedCells = [position], Combat = self.Combat with { FenxianReturnCredit = credit } }] }, catalog, 73);
        await SqlAsync(db, """
            INSERT INTO matches(match_id,room_id,mode,difficulty,seed,config_version,status,created_at,season_id,ruleset_id,stats_version)
            VALUES($1,$2,'ChaosRealm','D0',73,$3,'Running',$4,$5,'season-v1','season-equipment-v1')
            """, ct, match, room.RoomId, config.Version, season.StartsAtUtc.AddMinutes(1), season.SeasonId);
        await SqlAsync(db, "INSERT INTO match_players(match_id,player_id,is_bot,state) VALUES($1,$2,false,'Active')", ct, match, player);
        return (match, room);
    }

    private static string FindOriginal16()
    {
        for (var directory = new DirectoryInfo(AppContext.BaseDirectory); directory is not null; directory = directory.Parent)
        {
            var path = Path.Combine(directory.FullName, "server/config/archive/season-v1-config-16/fantasycard.config.bytes");
            if (File.Exists(path)) return path;
        }
        throw new FileNotFoundException("Pinned original16 archive required.");
    }
}
