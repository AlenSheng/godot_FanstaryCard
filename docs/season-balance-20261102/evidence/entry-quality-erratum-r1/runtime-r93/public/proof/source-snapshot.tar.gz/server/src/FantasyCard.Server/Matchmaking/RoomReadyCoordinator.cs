using System.Diagnostics;
using FantasyCard.Contracts.Realtime;
using FantasyCard.Domain.Combat;
using FantasyCard.Domain.Configuration;
using FantasyCard.Domain.Rooms;
using FantasyCard.Server.Bootstrap;
using FantasyCard.Server.Common;
using FantasyCard.Server.Realtime;
using FantasyCard.Server.Rooms;

namespace FantasyCard.Server.Matchmaking;

public interface IRoomReadyService
{
    Task<ReadyLobbyView?> GetAsync(Guid playerId, CancellationToken cancellationToken);
    Task<ReadyLobbyView> ReadyAsync(Guid playerId, CancellationToken cancellationToken);
}

public sealed partial class RoomReadyCoordinator(
    MatchmakingRepository repository,
    RoomRegistry roomRegistry,
    RoomSnapshotRepository snapshots,
    RealtimeEventStore eventStore,
    ConnectionRegistry connections,
    TimeProvider timeProvider,
    ILogger<RoomReadyCoordinator> logger,
    ServerMetrics? metrics = null,
    PublishedConfigCatalogs? configurations = null) : BackgroundService, IRoomReadyService
{
    private ReadyMatchLaunch? _pendingLaunch;
    private readonly PublishedConfigCatalogs _configurations = configurations ?? new(GameConfigCatalog.Current);

    public Task<ReadyLobbyView?> GetAsync(Guid playerId, CancellationToken cancellationToken) =>
        repository.GetReadyLobbyAsync(playerId, cancellationToken);

    public Task<ReadyLobbyView> ReadyAsync(Guid playerId, CancellationToken cancellationToken) =>
        repository.MarkReadyAsync(playerId, timeProvider.GetUtcNow(), cancellationToken);

    public async Task NotifyRequiredAsync(PendingMatch match, CancellationToken cancellationToken)
    {
        // A room has four seats. Bound concurrent delivery across players,
        // keeping each player's found/required pair awaited in order.
        await Parallel.ForEachAsync(match.PlayerIds,
            new ParallelOptions { MaxDegreeOfParallelism = 4, CancellationToken = cancellationToken },
            async (playerId, deliveryToken) =>
        {
            var found = eventStore.Create(playerId, "match.found", "matchmaker",
                new MatchFoundEventPayload(match.MatchId, match.RoomId, match.ReadyDeadline.ToUnixTimeMilliseconds()));
            var startedAt = Stopwatch.GetTimestamp();
            await connections.SendIfConnectedAsync(playerId, found, deliveryToken);
            metrics?.ObserveMatchLaunchPhase("found_send", Stopwatch.GetElapsedTime(startedAt));
            var message = eventStore.Create(playerId, "room.ready_required", "matchmaker",
                new RoomReadyRequiredEventPayload(match.MatchId, match.RoomId,
                    match.ReadyDeadline.ToUnixTimeMilliseconds(), 0, match.PlayerIds.Count));
            startedAt = Stopwatch.GetTimestamp();
            await connections.SendIfConnectedAsync(playerId, message, deliveryToken);
            metrics?.ObserveMatchLaunchPhase("required_send", Stopwatch.GetElapsedTime(startedAt));
        });
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                if (!await ProcessNextAsync(timeProvider.GetUtcNow(), stoppingToken))
                {
                    await Task.Delay(TimeSpan.FromMilliseconds(100), stoppingToken);
                    continue;
                }
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                return;
            }
            catch (Exception exception)
            {
                LaunchFailed(logger, exception);
                await Task.Delay(TimeSpan.FromSeconds(1), stoppingToken);
            }
        }
    }

    internal async Task<bool> ProcessNextAsync(DateTimeOffset now, CancellationToken cancellationToken)
    {
        var startedAt = Stopwatch.GetTimestamp();
        // Keep the assignment until MarkRunning is confirmed. A committed
        // Running match is absent from ClaimReadyMatch after a lost response.
        var launch = _pendingLaunch ?? await repository.ClaimReadyMatchAsync(now, cancellationToken);
        metrics?.ObserveMatchLaunchPhase("claim", Stopwatch.GetElapsedTime(startedAt));
        if (launch is null) return false;
        _pendingLaunch = launch;
        if (launch.Aborted)
        {
            foreach (var playerId in launch.RemovedPlayerIds)
            {
                var removed = eventStore.Create(playerId, "room.ready_removed", "context-unavailable",
                    new RoomReadyRemovedEventPayload(launch.Assignment.MatchId, launch.RemovalReason));
                await connections.SendIfConnectedAsync(playerId, removed, cancellationToken);
            }
            _pendingLaunch = null;
            return true;
        }
        await LaunchAsync(launch, cancellationToken);
        return true;
    }

    private async Task LaunchAsync(ReadyMatchLaunch launch, CancellationToken cancellationToken)
    {
        var assignment = launch.Assignment;
        var startedAt = Stopwatch.GetTimestamp();
        var persisted = await snapshots.GetAsync(assignment.RoomId, cancellationToken);
        if (persisted is not null)
            RoomSnapshotRepository.RequireMatchContext(persisted, assignment.RoomId,
                assignment.ConfigVersion ?? BootstrapRepository.CurrentConfigVersion, assignment.Season);
        var room = persisted is null
            ? CreateRoom(assignment)
            : BattleRoom.Restore(persisted, CombatCardCatalog.Create(_configurations.Resolve(persisted.ConfigVersion)), assignment.Seed);
        metrics?.ObserveMatchLaunchPhase("build", Stopwatch.GetElapsedTime(startedAt));
        startedAt = Stopwatch.GetTimestamp();
        await snapshots.SaveIfDueAsync(room.Capture(), cancellationToken);
        metrics?.ObserveMatchLaunchPhase("snapshot", Stopwatch.GetElapsedTime(startedAt));
        RoomActor actor;
        var registered = false;
        try
        {
            startedAt = Stopwatch.GetTimestamp();
            actor = roomRegistry.Register(room, assignment.MatchId, startTicker: false);
            metrics?.ObserveMatchLaunchPhase("register", Stopwatch.GetElapsedTime(startedAt));
            registered = true;
            startedAt = Stopwatch.GetTimestamp();
            await repository.MarkRunningAsync(assignment.MatchId, cancellationToken);
            metrics?.ObserveMatchLaunchPhase("mark_running", Stopwatch.GetElapsedTime(startedAt));
            _pendingLaunch = null;
            actor.StartTicker();
        }
        catch
        {
            metrics?.MatchLaunchFailed(registered ? "mark_running" : "register");
            if (registered) await roomRegistry.RemoveAsync(assignment.RoomId);
            throw;
        }

        await Parallel.ForEachAsync(launch.HumanPlayerIds,
            new ParallelOptions { MaxDegreeOfParallelism = 4, CancellationToken = cancellationToken },
            async (playerId, deliveryToken) =>
        {
            var deliveryStartedAt = Stopwatch.GetTimestamp();
            var state = await actor.ExecuteAsync(new GetRoomClientStateCommand(playerId), deliveryToken);
            var snapshot = RoomSnapshotProjection.Build(state, playerId, assignment.MatchId, timeProvider.GetUtcNow());
            var started = eventStore.Create(playerId, "room.started", "ready-complete",
                new RoomStartedEventPayload(assignment.MatchId, assignment.RoomId, assignment.Players.Count, snapshot),
                roomRevision: state.Snapshot.Revision);
            await connections.SendIfConnectedAsync(playerId, started, deliveryToken);
            metrics?.ObserveMatchLaunchPhase("started_send", Stopwatch.GetElapsedTime(deliveryStartedAt));
        });

        foreach (var playerId in launch.RemovedPlayerIds)
        {
            var removed = eventStore.Create(playerId, "room.ready_removed", "ready-timeout",
                new RoomReadyRemovedEventPayload(assignment.MatchId, "ready_timeout"));
            await connections.SendIfConnectedAsync(playerId, removed, cancellationToken);
        }
    }

    private BattleRoom CreateRoom(MatchAssignment assignment)
    {
        var configVersion = assignment.ConfigVersion ?? BootstrapRepository.CurrentConfigVersion;
        var configuration = _configurations.Resolve(configVersion);
        var room = new BattleRoom(assignment.RoomId, configVersion,
            CombatCardCatalog.Create(configuration), assignment.Seed, assignment.Season is null
                ? configuration.Numerics : NumericalRules.SeasonV1,
            assignment.Season);
        foreach (var player in assignment.Players)
        {
            var wornArmor = (player.EquipmentIds ?? []).Select(id =>
            {
                var item = player.Equipment?.SingleOrDefault(value => value.ItemId == id);
                var details = item is null ? null : new EquipmentRewardData(
                    item.Slot, item.Quality, item.Element.ToString(), item.EffectAffix,
                    item.SecondaryTrait ?? "DrawInterval", item.Level,UniqueAffix:item.UniqueAffix,UniqueElement:item.UniqueElement?.ToString(),StatsVersion:assignment.Season?.StatsVersion);
                return new ExplorationItem(id.ToString("D"), ExplorationItemKind.Equipment,
                    Equipment: details, IsGenerated: false);
            }).ToArray();
            var equipment = EquipmentCombatRules.Calculate(player.Equipment, configuration,assignment.Season?.StatsVersion);
            var state = room.AddPlayer(new BattleRoomPlayerSetup(player.PlayerId, player.HeroClass,
                player.CardIds, null, WeaponLevel: player.WeaponLevel,
                InventoryCapacity: player.InventoryCapacity, SafeSlots: player.SafeSlots,
                WornArmor: wornArmor, IsBot: player.IsBot, Equipment: equipment,
                SafeSlotIndexes: player.SafeSlotIndexes, DisplayName: player.DisplayName, CardLevels: player.CardLevels,
                BorrowedTemplateId: player.BorrowedTemplateId, LootPreferenceElement: player.LootPreferenceElement));
            for (var potion = 0; potion < player.PotionCount; potion++)
                if (!state.Inventory.TryAdd(new ExplorationItem($"health_potion:{potion + 1}", ExplorationItemKind.HealthPotion,IsCombatProjection:player.IsBot && room.BotRewardPolicy is not null)))
                    throw new InvalidOperationException("Preparation potion count exceeds the exploration inventory capacity.");
        }
        room.InitializeMap(ChaosMapGenerator.Generate(assignment.Seed, assignment.Players.Count,assignment.Season is not null?configuration.SeasonThemes:null));
        return room;
    }

    [LoggerMessage(EventId = 3011, Level = LogLevel.Error, Message = "Ready-match launch iteration failed.")]
    private static partial void LaunchFailed(ILogger logger, Exception exception);
}
