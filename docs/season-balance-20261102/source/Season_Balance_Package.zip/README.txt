遗境行者 赛季数值提案与测算包 第二版
日期：2026-11-02

先看 Season_Balance_Design.md，再打开 Season_Balance_Model.xlsx。
在线完整提案：https://chatgpt.com/space/page_413e1379186c81919c40e26d0ba3ee83

方案性质
这是基于25份项目文档的候选规则与离线计算，不是已发布的游戏配置。
未读取或执行目标仓库的生产C#，未完成CombatService完整对局仿真。
六档曲线、强化价、掉率和保底均为下一阶段校准输入。
已有GDD与服务器未被修改。

工作簿
13个工作表，黄色为输入。参数变动可重算公式。
新增红装周投放、双币市场、商店与活动、全服资源账。
验证在Artifact Tool计算与渲染引擎完成，未在本地Excel/WPS重新打开。
P0的8/3/12三卡诊断假定已拥有这些牌，不是新号初始20卡组。
普通抽牌吞吐代理不等于DPS、TTK或胜率。
净碎片不等于装备本体、印记、药剂与金币全部可持续。

无需网络的复算
在解压目录运行：
  node analysis/verify_combat_math.mjs
  python analysis/independent_economy_check.py
  node analysis/red_market_model_v2.mjs
  python analysis/market_audit_v2.py
  python analysis/shop_event_audit_v2.py
  python analysis/verify_market_model_v2.py
上述脚本使用Node或Python标准库，不连接游戏服务器。
参考结果在 analysis 下，包含输入SHA-256和验证边界。
基准检查对所选提案数值做回归断言；有意调整参数后需同步审查断言。

重新生成原始候选基线
  node analysis/build_season_model.mjs
  python analysis/build_market_model_v2.py
这会重写analysis/season_model.json并在outputs/season_balance_20261102生成基准输入和CSV。
它用于重新生成本提案基线，不用于保留手工修改过的JSON。
如果已经直接调过JSON，不要先运行这一步覆盖修改。

重新导出工作簿
build_workbook.mjs需要含@oai/artifact-tool的受管主Node运行时。
可显式传入常规模型、输出目录、基础算术参考与市场模型：
  node build_workbook.mjs analysis/season_model.json rebuilt analysis/arithmetic_results.json analysis/market_model_v2.json
在普通电脑上不保证具备该依赖；直接用Excel修改工作簿无需该脚本。
中文预览使用Noto Sans CJK SC；字体和运行时依赖不随包分发。

接入项目
config_samples是五行元数据CSV示例，不能直接热加载。
按既有FantasyCard_Config.xlsx字段合并、强校验、Protobuf导出与版本锁流程接入。
JSON只是离线输入，不能绕过现有配置发布规范。
Excel里的试调不会自动写回JSON或生产源表；确定方案后只保留一份正式策划源表。

核心默认值
42日，支持30至60日；保留每逻辑服务器每自然周最多1件新红。
原自然周周一04点，不滚存；Boss、未来装备箱与活动共用，交易/遗物不新增。
新D2以上核心Boss独立0.4%；D2以上橙红合计最多穿1件，普通三选一仍不出红。
42日与周界对齐最多6件原始红，全服理想情况下至多2件红+5；+4/+5各吞1红不变。
常规1橙4紫+3强化60碎，已学模板重铸另6碎，必须有真实同品质本体。
全+5强化780碎且另耗两橙八紫材料；永久专武仍248，不能用新白防具28替代。
D2条件路线成功基础碎片40；70%撤离下仅基础格掉含重铸净8.2片/尝试。
该基础分项不能当全渠道收入；补三选一碎片、商店1包与均摊活动后，3整局/日净65.346607碎，未扣额外高阶强化/专武/首次投入。
全服装备流动另计死亡最终带出率；不能把个人死亡丢失全算系统销毁。
金币/钻石市场均10%卖方税，成交本金是转移；碎片与魂不直接交易。
普通商店保持120金20碎、日限3，购包花金币不能省略；永久钻石保留财富优势，不自动开放钻兑金。
偶尔活动基准42天2场各3日、每期12章共享兑换预算；34.56碎季均仅适用规定参与/满额完成/兑换假设。
红词缀与390强化费均为本轮候选，未通过真实PVP验证；保留周配额不等于已经上线这些候选值。
每天严格30分钟不能被承诺42天打满30级；前20级放主奖励。

构筑、路线、选择率和撤离率均须真实对局采样。
最终放行需验证三职业、返牌、盾循环、PVP、死亡重建和季末归档。
