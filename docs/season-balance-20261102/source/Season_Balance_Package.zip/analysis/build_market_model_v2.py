"""Offline, reproducible season economy extension. No production I/O."""
from pathlib import Path
import json, math, hashlib, csv, io
from fractions import Fraction

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'outputs'/'season_balance_20261102'
BASE=json.loads((ROOT/'analysis'/'season_model.json').read_text())
BASE_HASH=hashlib.sha256((ROOT/'analysis'/'season_model.json').read_bytes()).hexdigest()

def avg_floor(a,b,scale,mult=1):
    s=Fraction(str(scale))*mult
    return sum((k*s).numerator//(k*s).denominator for k in range(a,b+1))/(b-a+1)

def fee(price,rate=.1):
    return max(1,math.floor(Fraction(price)*Fraction(str(rate))))

def min_sale_for_net(net,rate=.1):
    x=max(1,math.ceil(net))
    while x-fee(x,rate)<net: x+=1
    return x

def distribution(n,p):
    return [math.comb(n,k)*p**k*(1-p)**(n-k) for k in range(n+1)]

assumptions={
 'seasonDays':42,'activePlayers':1000,'dailyMinutes':60,'minutesPerAttempt':18,'attemptsPerDay':3,
 'difficultyIndex':2,'extractionRate':.7,'gearChoiceRate':.75,'fragmentChoiceRate':.15,'healChoiceRate':.10,
 'doubleFragmentBiasRate':.5,'deadGearRecoveredRate':.5,'rebuildFragmentCost':66,
 'marketEligibleFraction':.25,'recipeSampleUnusedFraction':.5,'targetElementWeight':.4,'targetEffectWeight':1/3,'targetSlotWeight':.2,
 'fragmentPacksPerDay':1,'cardPacksPerDay':.5,'warriorPacksPerDay':.25,'classPacksPerDay':.05,
 'potionsPerAttempt':.25,'refreshFirstRate':.1,'refreshSecondRate':.02,'refreshThirdRate':.005,
 'advancedBagUseRate':0,'topBagUseRate':0,'goldTradesPer1000Attempts':250,'goldTradePrice':200,
 'diamondTradesPer1000Attempts':5,'diamondTradePrice':500,'diamondSystemGrantPer1000Attempts':0,
 'diamondTopupsPer1000Attempts':0,'diamondCosmeticsSinkPer1000Attempts':0,
 'examplePurpleBodyPriceGold':100,'exampleOrangeBodyPriceGold':400,
 'upgradePurpleFrom3To5Per1000Attempts':100,'upgradeOrangeFrom3To5Per1000Attempts':25,
 'notes':[
  '全部是压力试算输入，不是线上DAU、价格、选择率、回收率、购买率或成交量。',
  '每人3局是严格完整局；60/18的跨日均摊口径不用于本扩展。',
  'D2 R1是特定布局完整路线；个人示例失败不带出、也不从别人遗物获利。',
  '全服账只计已带出的新来源；另输入死亡已穿戴装备的最终回收率，失败者未带出新掉落被别人拾取的增量默认0，必须实测另记。',
  '碎片压力账按每次失败都花66重建，未抵扣买到可直接使用的已强化二手装；实际账按真实强化/重铸事件扣费。',
  '日均0.5卡包等表示玩家群平均购买频率，不是半个商品或单账号必然支出。',
  'marketEligibleFraction表示符合交易资格且实际挂牌的综合比例，不只是有资格；不能把未上架库存计成新挂单。',
  '碎片选择率与装备、回血互斥；健康高价值与成功率相关，当前独立条件仅供灵敏度检查。'
 ]
}
shops=[
 {'id':'fragment','name':'装备碎片包','priceGold':120,'dailyLimit':3,'units':20,'resource':'绑定碎片','defaultPacksPerDay':assumptions['fragmentPacksPerDay']},
 {'id':'warrior','name':'勇士之魂包','priceGold':180,'dailyLimit':3,'units':20,'resource':'绑定勇士魂','defaultPacksPerDay':assumptions['warriorPacksPerDay']},
 {'id':'class','name':'自选职业魂包','priceGold':400,'dailyLimit':1,'units':12,'resource':'绑定职业魂','defaultPacksPerDay':assumptions['classPacksPerDay']},
 {'id':'card','name':'随机卡礼包','priceGold':250,'dailyLimit':5,'units':3,'resource':'白绿蓝紫卡副本','defaultPacksPerDay':assumptions['cardPacksPerDay']},
 {'id':'potion','name':'生命药剂','priceGold':100,'dailyLimit':4,'units':1,'resource':'药剂','defaultPacksPerDay':assumptions['potionsPerAttempt']*assumptions['attemptsPerDay']},
 {'id':'advancedBag','name':'高级探索包','priceGold':800,'dailyLimit':None,'units':1,'resource':'可复用直到死亡','defaultPacksPerDay':0},
 {'id':'topBag','name':'顶级探索包','priceGold':2200,'dailyLimit':None,'units':1,'resource':'可复用直到死亡','defaultPacksPerDay':0},
]
event={
 'count':2,'durationDays':3,'tokensPerEvent':12,'participationRate':.6,'completionFraction':.8,'redemptionRate':.9,
 'tokenName':'活动徽记','tokenScope':'账号+season_id+event_id；不可交易，不从钻石购买，不可跨期滚存',
 'defaultBranch':'fragment','branches':[
  {'id':'fragment','tokenCost':3,'rewardCount':10,'reward':'绑定装备碎片'},
  {'id':'warrior','tokenCost':3,'rewardCount':6,'reward':'绑定勇士魂'},
  {'id':'class','tokenCost':3,'rewardCount':2,'reward':'绑定自选职业魂'},
  {'id':'potion','tokenCost':6,'rewardCount':1,'reward':'药剂','limitPerEvent':1},
 ],
 'directGoldPerCompletedEvent':0,'directDiamondsPerCompletedEvent':0,
 'directPurpleBodiesPerCompletedEvent':0,'directOrangeBodiesPerCompletedEvent':0,'directRedBodiesPerCompletedEvent':0,
 'scopeNote':'完成比例指参与者中拿满12章的账号比例，余者本例按0兑换；不是平均进度80%。实际部分完成者须按每人可整次兑换的章数统计。同一12徽记预算择项兑换，不能把所有分支上限累加；活动红及红材料默认0，任何以后启用的红发放也必须占服务器同一周配额。'
}
market={
 'taxRateGold':.1,'taxRateDiamond':.1,'minFee':1,'listingSlotsShared':8,'listingDurationHours':48,'listingFee':0,
 'goldPriceCap':99999,'orangeDiamondCap':2000,'redDiamondCap':8000,
 'allowed':{'white':['gold'],'green':['gold'],'blue':['gold'],'purple':['gold'],'orange':['gold','diamond'],'red':['gold','diamond']},
 'excluded':['魂','装备碎片','印记','活动徽记','卡牌','专武','背包','药剂','借用装备','绑定装备'],
 'materialMeaning':'可交易真实同品质装备可作为+4/+5材料；不新增可交易碎片或可双花的材料副本',
 'bindingValueNote':'绑定碎片与合法绑定材料可通过强化商品间接增加可交易成品价值；属于有消耗的加工，不等于资源可直接转账。',
 'diamondWallet':'永久钱包，允许买本季真实橙红；财富优势保留。季金币/装备/市场订单仍按季隔离。',
 'npcFxEnabled':False,'legacyFxGoldPerDiamond':20,'legacyFxDailyDiamondCap':5000,
 'singleListingRule':'同一item_id只能一个币种一个挂单，切换先原子撤销并解锁，再重挂；金币与钻石成交不能串账。',
 'materialSearch':'品质、强化等级、是否可作为材料、绑定、配方可提取状态、总价和单价；默认先+0材料，不做系统保价。',
 'recipePolicy':'原始自然掉落或正常印记打造且未提取的紫橙样本，只可登记一次；交易继承，重铸产物永不可再次提供配方；红、活动材料、借用和Bot不可登记。',
 'reforgeProvenance':'输出继承输入本体的绑定与赛季限制；借用、Bot投影、活动纯材料不可作为可穿戴重铸输入；不因新item_id洗掉来源或禁交易标记。',
 'marketDomain':'同一逻辑server_id与season_id内共享全部房间和频道市场，不自动跨服务器合池。'
}
red={
 'weeklyQuota':1,'bossChance':.004,'chestChance':.0008,'chestEnabled':False,'minimumDifficulty':2,
 'weekStarts':'Monday 04:00 server timezone','exampleTimezone':'Asia/Shanghai','alignedSeasonWeeks':6,
 'finalRetainedFraction':.7,'bossKillsPerWeekCases':[50,100,250,500,750,1000,2000],
 'legacyCosts':[96,192,384,768,1536],'candidateCosts':[6,9,15,120,240],
 'extraBodiesFor4':1,'extraBodiesFor5':1,'recipeAllowed':False,'reforgeAllowed':False,
 'candidate':{'damageBase':.32,'damagePerLevel':.04,'resistBase':.18,'resistPerLevel':.01,'speedBase':.12,'speedPerLevel':.006,
  'fenYuanBonus':.15,'jiChouBonus':.04,'drawFloor':1.8,'lianZhuChance':.10,'shiYiExtraOpeningCard':1,'jinChanEscapeBonus':.15},
 'legacyUnique':{'fenYuanBonus':.35,'jiChouBonus':.25,'jiChouFloor':1.5,'lianZhuChance':.20},
 'definition':'每逻辑服、自然周最多生成1个新红item；未必每周必出。交易、死亡遗物、材料消耗、跨季、重启均不重置或退回周额度。',
 'candidateNotice':'周1红是用户保留约束；红属性/独有词缀与390碎费用是本轮候选，尚未经真实PVP验证，不能当已生效规则。'
}

p=assumptions['extractionRate']; n=assumptions['attemptsPerDay']; q=assumptions['gearChoiceRate']; fq=assumptions['fragmentChoiceRate']; h=assumptions['doubleFragmentBiasRate']
diff=BASE['difficulties'][assumptions['difficultyIndex']]; counts=BASE['route']['counts']; layers=BASE['layers']
gold=sum(c*math.floor(Fraction(str(diff['goldScale']))*l['gold']) for c,l in zip(counts,layers))
frag=sum(c*avg_floor(l['fragmentMin'],l['fragmentMax'],diff['fragmentScale']) for c,l in zip(counts,layers))
doublefrag=sum(c*avg_floor(l['fragmentMin'],l['fragmentMax'],diff['fragmentScale'],2) for c,l in zip(counts,layers))
extraFragAttempt=p*fq*((1-h)*frag+h*doublefrag)
candidates=[sum(c*next(x for x in BASE['loot'] if x['difficultyId']==diff['id'] and x['layerId']==l['id'])['weights'][i] for c,l in zip(counts,layers)) for i in range(5)]
newGearAttempt=[x*q*p for x in candidates]
eventCoverage=event['participationRate']*event['completionFraction']*event['redemptionRate']
maxEventFragments=(event['tokensPerEvent']//3)*10
eventFragSeason=event['count']*maxEventFragments*eventCoverage
eventFragDay=eventFragSeason/assumptions['seasonDays']
shopFragDay=assumptions['fragmentPacksPerDay']*20
rebuildDay=n*(1-p)*assumptions['rebuildFragmentCost']
baseGrossDay=n*p*frag
refGoldPerAttempt=60*assumptions['refreshFirstRate']+180*assumptions['refreshSecondRate']+450*assumptions['refreshThirdRate']

results={'sources':{'successGold':gold,'successBaseFragments':frag,'successDoubleChoiceFragments':doublefrag,'additionalChoiceFragmentsPerAttempt':extraFragAttempt,'newGearPerAttempt':dict(zip(['white','green','blue','purple','orange'],newGearAttempt))},
 'event':{'coverage':eventCoverage,'maxFragmentsPerEvent':maxEventFragments,'maxFragmentsPerParticipatingSeason':maxEventFragments*event['count'],'meanFragmentsPerActiveSeason':eventFragSeason,'meanFragmentsPerActiveDay':eventFragDay,'meanFragmentsOnOneEventBurstDay':maxEventFragments*eventCoverage},
 'dailyFragments':{'baseGross':baseGrossDay,'extraChoiceGross':n*extraFragAttempt,'shopGross':shopFragDay,'eventGross':eventFragDay,'rebuildSpend':rebuildDay,'netBaseOnly':baseGrossDay-rebuildDay,'netWithChoice':baseGrossDay+n*extraFragAttempt-rebuildDay,'netWithChoiceAndShop':baseGrossDay+n*extraFragAttempt+shopFragDay-rebuildDay,'netAll':baseGrossDay+n*extraFragAttempt+shopFragDay+eventFragDay-rebuildDay},
 'personalGoldScenarios':[], 'globalStock':[], 'marketDepth':[], 'redWeekly':[], 'taxExamples':[], 'processingExamples':[]}

for packs in range(4):
 results['personalGoldScenarios'].append({'fragmentPacks':packs,'goldIncome':n*p*gold,'shopCost':packs*120,'remainingBeforeOtherSpending':n*p*gold-packs*120,'fragmentNetWithChoice':baseGrossDay+n*extraFragAttempt+packs*20-rebuildDay,'remainingAfterOnePotion':n*p*gold-packs*120-100})
for recovery in [0,.25,.5,.75,1]:
 record={'deadRecovery':recovery,'marksEarned':1000*p*3}
 for quality,index,wear,cost in [('orange',4,1,14),('purple',3,4,4)]:
  natural=1000*newGearAttempt[index]; lost=1000*(1-p)*wear; destroyed=lost*(1-recovery)
  record[quality]={'naturalNew':natural,'personalLost':lost,'transferredFromDeaths':lost*recovery,'finallyDestroyed':destroyed,'netBeforeCraftUpgrade':natural-destroyed,'noRecoveryPersonalDeficit':max(0,lost-natural)}
 results['globalStock'].append(record)

for players in [100,300,1000,3000,10000]:
 lam=players*n*newGearAttempt[4]*assumptions['targetElementWeight']*assumptions['targetEffectWeight']*assumptions['targetSlotWeight']*assumptions['marketEligibleFraction']
 ls=lam*assumptions['recipeSampleUnusedFraction']
 results['marketDepth'].append({'activePlayers':players,'targetOrangeListingsPerDay':lam,'probAnyTargetListing48h':-math.expm1(-2*lam),'unusedRecipeListingsPerDay':ls,'probAnyUnusedSample48h':-math.expm1(-2*ls),'meaning':'Poisson新挂单到达概率，非买家成交率；未计价格、竞争和库存已有挂单'})
for bosskills in red['bossKillsPerWeekCases']:
 prob=-math.expm1(bosskills*math.log1p(-red['bossChance'])); retained=prob*red['finalRetainedFraction']; dist=distribution(6,retained)
 results['redWeekly'].append({'bossKills':bosskills,'weeklyAnyGenerated':prob,'weeklyNone':1-prob,'sixWeeksExpectedGenerated':6*prob,'sixWeeksExpectedRetained':6*retained,'probRetainedAtLeast3':sum(dist[3:]),'expectedMaxPlus5IfPerfectlyConcentrated':sum((k//3)*v for k,v in enumerate(dist))})
results['redQuota']={'alignedDays':[{'days':d,'fullWeeks':d//7,'maxTouchedWeekKeys':math.ceil((d+7-1e-9)/7),'note':'按实际起止时间枚举；首尾自然周与相邻赛季共享，不是独立赠送额'} for d in [30,42,60]],'aligned42MaximumItems':6,'aligned42MaximumPlus5Items':2,'sixDropsThreePlus3OwnersAndOnePlus5':{'plus3':3,'plus5':1,'remainingPhysicalItems':4}}
for currency,price in [('gold',9),('gold',1000),('diamond',2000),('diamond',8000)]:
 rate=market['taxRateGold'] if currency=='gold' else market['taxRateDiamond']
 results['taxExamples'].append({'currency':currency,'price':price,'fee':fee(price,rate),'sellerNet':price-fee(price,rate)})
for quality,bodyPrice,enhance,reforge in [('purple',assumptions['examplePurpleBodyPriceGold'],10,1),('orange',assumptions['exampleOrangeBodyPriceGold'],20,2)]:
 resourceCost=6*(enhance+reforge); total=bodyPrice+resourceCost
 results['processingExamples'].append({'quality':quality,'assumedBodyPriceGold':bodyPrice,'boundFragmentsConsumed':enhance+reforge,'shopReplacementCostGold':resourceCost,'totalReplacementCostGold':total,'minimumSaleToRecoverCostGold':min_sale_for_net(total,market['taxRateGold']),'note':'6金/碎是有限商店替代成本，不是回购价；不保证市场愿意支付加工费'})

attempts=1000; playerDays=attempts/n
eventDirectCoverage=event['participationRate']*event['completionFraction']
eventGold=playerDays/assumptions['seasonDays']*event['count']*eventDirectCoverage*event['directGoldPerCompletedEvent']
eventDiamond=playerDays/assumptions['seasonDays']*event['count']*eventDirectCoverage*event['directDiamondsPerCompletedEvent']
eventPurple=playerDays/assumptions['seasonDays']*event['count']*eventDirectCoverage*event['directPurpleBodiesPerCompletedEvent']
eventOrange=playerDays/assumptions['seasonDays']*event['count']*eventDirectCoverage*event['directOrangeBodiesPerCompletedEvent']
sourceGold=attempts*p*gold+eventGold
shopCost=sum(x['priceGold']*x['defaultPacksPerDay']*playerDays for x in shops if x['id'] not in ['potion','advancedBag','topBag'])
potCost=attempts*assumptions['potionsPerAttempt']*100
refreshCost=attempts*refGoldPerAttempt
bagCost=attempts*(1-p)*(assumptions['advancedBagUseRate']*800+assumptions['topBagUseRate']*2200)
goldTax=assumptions['goldTradesPer1000Attempts']*fee(assumptions['goldTradePrice'],market['taxRateGold'])
diaTax=assumptions['diamondTradesPer1000Attempts']*fee(assumptions['diamondTradePrice'],market['taxRateDiamond'])
results['globalCurrencies']={'attempts':attempts,'equivalentActivePlayerDays':playerDays,'goldCreated':sourceGold,'eventGoldCreated':eventGold,'eventDiamondCreated':eventDiamond,'goldShopSink':shopCost,'goldPotionSink':potCost,'goldRefreshSink':refreshCost,'goldBagReplacementSink':bagCost,'goldTaxSink':goldTax,'goldNet':sourceGold-shopCost-potCost-refreshCost-bagCost-goldTax,'diamondTurnover':assumptions['diamondTradesPer1000Attempts']*assumptions['diamondTradePrice'],'diamondTaxSink':diaTax,'diamondNet':assumptions['diamondSystemGrantPer1000Attempts']+assumptions['diamondTopupsPer1000Attempts']+eventDiamond-diaTax-assumptions['diamondCosmeticsSinkPer1000Attempts'],'diamondNote':'默认新增钻石0；成交依赖既有钻石余额。没有充值/赠钻数据，不能判断钻石供应是否充足。'}
results['globalCurrencies']['goldNetPerActiveDay']=results['globalCurrencies']['goldNet']/playerDays
results['globalFragments']={'base':attempts*p*frag,'choice':attempts*extraFragAttempt,'shop':playerDays*shopFragDay,'event':playerDays*eventFragDay,'rebuild':attempts*(1-p)*assumptions['rebuildFragmentCost'],'optionalUpgradeSpend':120*assumptions['upgradePurpleFrom3To5Per1000Attempts']+240*assumptions['upgradeOrangeFrom3To5Per1000Attempts']}
gf=results['globalFragments']; gf['netBeforeOptionalUpgrade']=gf['base']+gf['choice']+gf['shop']+gf['event']-gf['rebuild'];gf['netAfterOptionalUpgrade']=gf['netBeforeOptionalUpgrade']-gf['optionalUpgradeSpend']
materialRecovery=assumptions['deadGearRecoveredRate']
results['globalMaterials']={'purpleForOptionalUpgrades':2*assumptions['upgradePurpleFrom3To5Per1000Attempts'],'orangeForOptionalUpgrades':2*assumptions['upgradeOrangeFrom3To5Per1000Attempts'],'eventPurpleBodies':eventPurple,'eventOrangeBodies':eventOrange,'purpleNetAfterOptionalUpgrades':1000*newGearAttempt[3]+eventPurple-1000*(1-p)*4*(1-materialRecovery)-2*assumptions['upgradePurpleFrom3To5Per1000Attempts'],'orangeNetAfterOptionalUpgrades':1000*newGearAttempt[4]+eventOrange-1000*(1-p)*(1-materialRecovery)-2*assumptions['upgradeOrangeFrom3To5Per1000Attempts'],'note':'本体已持有，+3升+5只额外吞2件；默认新增打造0，实际若打造必须把唯一新物品也记入来源。'}
results['warehousePressure']={'newGearPerActiveDay':sum(newGearAttempt)*n,'netNewBeforeUpgradeAndDiscardPerActiveDay':(sum(newGearAttempt)-(1-p)*5*(1-assumptions['deadGearRecoveredRate']))*n,'warehouseSlots':50,'listingSlots':8,'note':'这是总装备数量压力，不是预测满仓日；含低品质、换装替换、材料消耗与选碎片行为必须另记。拍卖挂单不是装备销毁。'}
results['choiceProfiles']=[]
for label,gc,fc in [('偏装备',.85,.05),('基准',.75,.15),('偏碎片',.45,.45)]:
 extra=n*p*fc*((1-h)*frag+h*doublefrag)
 results['choiceProfiles'].append({'name':label,'gearChoice':gc,'fragmentChoice':fc,'healChoice':.1,'fragmentNetPerDay':baseGrossDay+extra+shopFragDay+eventFragDay-rebuildDay,'orangeNewPer1000':1000*candidates[4]*gc*p,'purpleNewPer1000':1000*candidates[3]*gc*p,'orangeNetBeforeCraftUpgradePer1000':1000*candidates[4]*gc*p-1000*(1-p)*(1-assumptions['deadGearRecoveredRate']),'purpleNetBeforeCraftUpgradePer1000':1000*candidates[3]*gc*p-1000*(1-p)*4*(1-assumptions['deadGearRecoveredRate'])})
results['eventShopSubstitution']={'goldSinkReductionPerActiveSeasonIfAllDisplacesShop':eventFragSeason*6,'goldSinkReductionPerActiveDayIfAllDisplacesShop':eventFragDay*6,'goldSinkReductionPer1000EligibleAccountsSeason':eventFragSeason*6*1000,'note':'这只是减少回收的上界，不是金币新增；不能在固定商店购买基准上同时全额扣减商店支出。'}
results['currencyBridge']={'legacyFxGoldDailyMaximum':market['legacyFxGoldPerDiamond']*market['legacyFxDailyDiamondCap'],'baselineGoldDaily':n*p*gold,'baselineDaysEquivalent':market['legacyFxGoldPerDiamond']*market['legacyFxDailyDiamondCap']/(n*p*gold),'turnaroundRequiredGoldRatio':1/(1-market['taxRateGold'])/(1-market['taxRateDiamond']),'note':'相同经济等值的跨币转卖两次税约剩81%，实际逐单整数税；没有固定汇率保证。'}
boss=500; chests=1000; pb=-math.expm1(boss*math.log1p(-.004)); pc=-math.expm1(chests*math.log1p(-.0008))
results['chestStress']={'enabled':False,'weeklyBossKills':boss,'weeklyChests':chests,'probAnyRed':1-(1-.004)**boss*(1-.0008)**chests,'probChestWinsIfChestFirst':pc,'probChestWinsIfBossFirst':(1-pb)*pc,'orangeExpectationWhenQuotaUsed':chests*.02,'purpleExpectation':chests*.12,'goldCostAt800':chests*800,'diamondCostAt60':chests*60,'note':'未来若开启的压力分支；不能与当前默认无宝箱重复计入。开奖先后改变谁拿走唯一红，周配额不保证公平分配。'}

checks=[]
def ck(name,condition):
 checks.append({'name':name,'passed':bool(condition)})
 if not condition: raise AssertionError(name)
def eq(a,b):return abs(a-b)<1e-8
ck('三选一互斥概率和',eq(q+fq+assumptions['healChoiceRate'],1))
ck('额外碎片倍率先乘后取整',eq(frag,40) and eq(doublefrag,86.5))
ck('活动有限预算与34.56碎',eq(eventFragSeason,34.56))
ck('周配额始终最多1',all(0<=x['weeklyAnyGenerated']<=1 for x in results['redWeekly']))
ck('六周至多两个红+5',red['alignedSeasonWeeks']//3==2)
ck('红渠道与普通五色分离',all(len(x['weights'])==5 for x in BASE['loot']) and BASE['redRules']['weeklyQuota']==1)
ck('D2+入场可红、常规掉落不红',all((d['entryQualityCap']==5 and d['qualityCap']==4) if i>=2 else d['entryQualityCap']<5 for i,d in enumerate(BASE['difficulties'])))
ck('全服装备回收是转移',all(eq(s[c]['personalLost'],s[c]['transferredFromDeaths']+s[c]['finallyDestroyed']) for s in results['globalStock'] for c in ['orange','purple']))
ck('六金碎片不是卖回金',shops[0]['priceGold']/shops[0]['units']==6 and '装备碎片' in market['excluded'])
ck('默认不开放钻兑金和箱',not market['npcFxEnabled'] and not red['chestEnabled'])
ck('合法正价格税不超标价',all(0<fee(x)<=x for x in range(1,10001)))
ck('材料吞件只计额外两件',results['globalMaterials']['purpleForOptionalUpgrades']==200 and results['globalMaterials']['orangeForOptionalUpgrades']==50)
ck('活动分支药剂不越额',6<=event['tokensPerEvent'])
ck('默认活动不直接造可交易装备',all(event[k]==0 for k in ['directPurpleBodiesPerCompletedEvent','directOrangeBodiesPerCompletedEvent','directRedBodiesPerCompletedEvent']))
ck('股本与流量明示钻库存依赖',results['globalCurrencies']['diamondNet']==-250)
ck('日均常规片账全渠道',eq(results['dailyFragments']['netAll'],65.34660714285712))
ck('一次提取与重铸禁传配方', '只可登记一次' in market['recipePolicy'] and '永不可' in market['recipePolicy'])

model={'meta':{'version':'season-economy-v2-20261102','baseModelSha256':BASE_HASH,'proposalOnly':True,'productionTested':False,'sources':['GDD_BASE_v0.69 §2.5、4.7、5.6、6.1–6.8','GDD v0.70 §6.9','SERVER_IMPLEMENTATION_STATUS_AND_PLAN V015、商店与市场事务','本轮用户保留每服每周1红、扩展双币市场与投放校验']},'assumptions':assumptions,'shops':shops,'events':event,'market':market,'red':red,'results':results,'checks':checks}
OUT.mkdir(parents=True,exist_ok=True)
for path in [ROOT/'analysis'/'market_model_v2.json',OUT/'market_model_v2.json']:
 path.write_text(json.dumps(model,ensure_ascii=False,indent=2)+'\n')

def write_config(name,fields,types,descriptions,rows):
 buf=io.StringIO(newline='');w=csv.writer(buf);w.writerows([fields,types,['true']*len(fields),['server']*len(fields),descriptions]+rows)
 (OUT/'config_samples'/name).write_text('\ufeff'+buf.getvalue(),encoding='utf-8',newline='')
write_config('SeasonRedRules.csv',['rule_id','weekly_quota','min_difficulty','boss_chance','chest_enabled','chest_chance','timezone','week_start_hour'],['string','int64','int64','double','bool','double','string','int64'],['红独立渠道','逻辑服全渠道周上限','新六档映射D2+','核心Boss独立概率','未来宝箱默认关闭','若启用必须同配额','示例时区','周一04周界'],[['weekly-red',1,2,.004,'false',.0008,'Asia/Shanghai',4]])
write_config('SeasonMarketRules.csv',['rule_id','currency','tax_rate','min_fee','listing_hours','shared_slots','orange_price_cap','red_price_cap'],['string','string','double','int64','int64','int64','int64','int64'],['稳定主键','币种分账','卖家承担','最低费','时长','两币共享总栏位','橙上限','红上限'],[['gold-market','gold',.1,1,48,8,99999,99999],['diamond-market','diamond',.1,1,48,8,2000,8000]])
write_config('SeasonActivityExchange.csv',['rule_id','cost_tokens','reward_kind','reward_count','per_event_limit'],['string','int64','string','int64','int64'],['兑换主键','共用徽记预算','奖励类型','数量','单期上限'],[['event-fragments',3,'bound_fragments',10,4],['event-warrior',3,'bound_warrior_soul',6,4],['event-class',3,'bound_class_soul',2,4],['event-potion',6,'potion',1,1]])
print(json.dumps({'checksPassed':len(checks),'model':str(ROOT/'analysis'/'market_model_v2.json'),'dailyFragments':results['dailyFragments'],'globalCurrencies':results['globalCurrencies'],'globalMaterials':results['globalMaterials']},ensure_ascii=False,indent=2))
