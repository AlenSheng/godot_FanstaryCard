import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root = process.env.SEASON_WORKSPACE_ROOT || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = process.env.SEASON_OUTPUT_DIR || path.join(root, 'outputs/season_balance_20261102');
await fs.mkdir(path.join(root, 'analysis'), {recursive:true});
await fs.mkdir(out, {recursive:true});
const difficulties = [
  ['D0','标准',1,1,1,1,1,1,2,0],
  ['D1','进阶',1.6,1.25,1,1.2,1.15,1.4,3,0.5],
  ['D2','精英',2.6,1.5,0.98,1.4,1.3,1.9,4,0.6],
  ['D3','英雄',4,1.85,0.96,1.65,1.45,2.5,4,0.7],
  ['D4','灾厄',5.8,2.2,0.94,1.9,1.6,3.2,4,0.8],
  ['D5','巅峰',8,2.6,0.92,2.2,1.75,4,4,1],
].map(([id,name,hpScale,damageScale,intervalScale,goldScale,soulScale,fragmentScale,qualityCap,purpleAffixChance],index)=>({id,name,hpScale,shieldScale:hpScale,damageScale,intervalScale,goldScale,soulScale,fragmentScale,qualityCap,purpleAffixChance,cardEffectiveLevelCap:index,weaponEffectiveLevelCap:index,entryQualityCap:index>=2?5:qualityCap,redDropEligible:index>=2}));
const equipment = [
 ['white','白',.04,.02,.01,.0025,0,.0025,[1,1,2,8,16],[8,16,32,64,128]],
 ['green','绿',.07,.04,.015,.004,.03,.003,[1,2,3,12,24],[12,24,48,96,192]],
 ['blue','蓝',.11,.06,.02,.005,.05,.0035,[2,3,3,20,40],[20,40,80,160,320]],
 ['purple','紫',.15,.09,.025,.006,.07,.004,[2,3,5,40,80],[32,64,128,256,512]],
 ['orange','橙',.22,.13,.03,.008,.10,.005,[4,6,10,80,160],[64,128,256,512,1024]],
].map(([id,name,damageBase,resistBase,damagePerLevel,resistPerLevel,speedBase,speedPerLevel,costs,oldCosts],index)=>({id,name,index,damageBase,resistBase,damagePerLevel,resistPerLevel,speedBase,speedPerLevel,costs,oldCosts}));
const lootValues = [
 [[70,30,0,0,0],[0,60,40,0,0],[0,20,80,0,0],[0,0,100,0,0]],
 [[20,60,20,0,0],[0,25,65,10,0],[0,0,65,35,0],[0,0,20,80,0]],
 [[0,30,65,5,0],[0,0,55,43,2],[0,0,25,65,10],[0,0,0,70,30]],
 [[0,10,60,30,0],[0,0,30,65,5],[0,0,10,70,20],[0,0,0,50,50]],
 [[0,0,45,55,0],[0,0,15,75,10],[0,0,0,65,35],[0,0,0,35,65]],
 [[0,0,25,75,0],[0,0,5,80,15],[0,0,0,50,50],[0,0,0,20,80]],
];
const layers = [
 {id:'outer',name:'外层',gold:10,soulMin:1,soulMax:3,classSoul:1,fragmentMin:1,fragmentMax:2},
 {id:'middle',name:'中层角格',gold:18,soulMin:3,soulMax:6,classSoul:2,fragmentMin:2,fragmentMax:4},
 {id:'elite',name:'精英格',gold:32,soulMin:6,soulMax:10,classSoul:4,fragmentMin:4,fragmentMax:7},
 {id:'boss',name:'Boss格',gold:60,soulMin:10,soulMax:16,classSoul:8,fragmentMin:6,fragmentMax:10},
];
const loot=[];
for(let d=0;d<6;d++) for(let l=0;l<4;l++) loot.push({
 id:`${d}_${l}`,difficultyId:difficulties[d].id,layerId:layers[l].id,
 weights:lootValues[d][l].map(x=>x/100),
 qualityCap: l===0 ? Math.min(3,difficulties[d].qualityCap):difficulties[d].qualityCap,
 promotionCap:Math.min(3,difficulties[d].qualityCap),
 note:'基础候选概率；健康偏置/匣灵+1均最多升到紫；自然橙不降级；最终再截难度与来源帽；升档不叠加'
});
const monsterGroups=[
 ['O1','孤焰','outer',18, [['火蝠',78,0,3.6,'火3',3,.10]]],
 ['O2','孤棘','outer',16, [['棘螨',84,0,4.0,'木3',3,.10]]],
 ['O3','孤浊','outer',16, [['浊螅',86,0,4.2,'水3',3,.10]]],
 ['O4','孤砂','outer',14, [['砂蜥',92,8,4.6,'土3',3,.10]]],
 ['O5','孤锈','outer',14, [['锈刃鼠',80,0,3.6,'金3',3,.10]]],
 ['O6','双蝠','outer',8, [['火蝠',42,0,3.6,'火2',2,.10],['火蝠',42,0,3.6,'火2',2,.10]]],
 ['O7','金木','outer',7, [['锈刃鼠',44,0,3.8,'金2',2,.10],['棘螨',46,0,4,'木2',2,.10]]],
 ['O8','水土','outer',7, [['浊螅',46,0,4.2,'水2',2,.10],['砂蜥',50,6,4.6,'土2',2,.10]]],
 ['M1','双焰','middle',24, [['火蝠',56,0,3.8,'火2',2,.10],['火蝠',56,0,3.8,'火2',2,.10]]],
 ['M2','潮岩','middle',22, [['浊螅',60,0,4.2,'水2',2,.10],['砂蜥',66,8,4.6,'土2',2,.10]]],
 ['M3','刃藤','middle',22, [['锈刃鼠',58,0,3.6,'金2',2,.10],['棘螨',62,0,4,'木2',2,.10]]],
 ['M4','双潮','middle',16, [['浊螅',64,0,4,'水2',2,.10],['浊螅',64,0,4,'水2',2,.10]]],
 ['M5','焰岩','middle',16, [['火蝠',54,0,3.6,'火2',2,.10],['砂蜥',64,8,4.6,'土2',2,.10]]],
 ['E1','金卫','elite',24, [['金卫',200,12,4.4,'金4 金4 盾12 金6',4,.15]]],
 ['E2','火劫使','elite',18, [['火劫使',188,0,4.2,'火4 蓄力 火6 火4',4,.15]]],
 ['E3','沼母','elite',18, [['沼母',210,8,4.6,'水4 水4 盾10 水6',4,.15]]],
 ['E4','石甲卫','elite',18, [['石甲卫',184,24,4.8,'土4 盾14 土4 直7',4,.15]]],
 ['E5','棘林卫','elite',14, [['棘林卫',196,0,4.2,'木4 强化 木4 木5',4,.15]]],
 ['E6','卫蝠','elite',8, [['金卫',160,10,4.4,'金4 金4 盾12 金6',4,.15],['火蝠',40,0,3.6,'火2',2,.10]]],
 ['B1','湮核一期','boss',100, [['湮核一期',280,20,4.4,'火4 木4 盾10 火5 蓄力 直6',4,.20]]],
 ['B2','湮核二期','boss',0, [['湮核二期',280,0,3.8,'金5 土5 盾8 金5 土5 直8',5,.20]]],
 ['C1','匣灵','outer',0, [['匣灵',84,0,4,'80%元素3 / 20%直3',3,.10]]],
].map(([id,name,layerId,weight,members])=>({id,name,layerId,weight,members:members.map(([name,hp,shield,interval,intents,firstDamage,elementBoost])=>({name,hp,shield,interval,intents,firstDamage,elementBoost}))}));
const builds=[
 {id:'P0',name:'裸装算术锚',cardLevel:0,gear:[],effect:'无',difficulty:'D0'},
 {id:'P1',name:'绿蓝起步',cardLevel:1,gear:[{quality:'green',level:0,count:3},{quality:'blue',level:0,count:2}],effect:'无',difficulty:'D1'},
 {id:'P2',name:'蓝装成型',cardLevel:2,gear:[{quality:'blue',level:1,count:5}],effect:'无',difficulty:'D2'},
 {id:'P3',name:'紫装单套',cardLevel:3,gear:[{quality:'purple',level:2,count:5}],effect:'3紫破击，其余无效果',difficulty:'D3'},
 {id:'P4',name:'橙紫常规',cardLevel:4,gear:[{quality:'purple',level:3,count:4},{quality:'orange',level:3,count:1}],effect:'1橙+2紫破击，另2紫不触发其他套',difficulty:'D4'},
 {id:'P5',name:'橙紫极限',cardLevel:5,gear:[{quality:'purple',level:5,count:4},{quality:'orange',level:5,count:1}],effect:'1橙+3紫破击，另1紫不触发其他套',difficulty:'D5'},
];
const model={
 meta:{title:'遗境行者赛季数值候选基线',version:'season-balance-proposal-20261102-v2',date:'2026-11-02',status:'含每服周红配额、双币市场、商店与活动的文档及算术测算，未接生产配置，未验证真实对局',combatBaseline:'combat-current-b7a6154 / GDD v0.70',sourcesRead:25},
 assumptions:{seasonDays:42,dailyMinutes:60,minutesPerAttempt:18,extractionRate:.7,selectedDifficultyIndex:2,gearChoiceRate:.75,targetElementWeight:.4,targetEffectWeight:1/3,targetSlotWeight:.2,baseDrawInterval:4,drawFloor:1.8,resistCap:.6,defenseReduction:0,referenceTargetResist:0,referenceCardValues:[8,3,12],gearRebuildLevel:3,stageScaleRule:'min(1,seasonDays/42);只缩短30天季，不延长60天装备成本；每级ceil',returnKitGrant:0},
 difficulties,equipment,loot,layers,monsterGroups,builds,
 route:{id:'R1',name:'条件深图路线',counts:[5,1,1,1],coordinates:[[0,0],[0,1],[0,2],[0,3],[0,4],[1,4],[2,4],[2,3]],bossCoordinate:[2,3],note:'仅在该Boss与出生布局下成立；Boss格清理后可撤离。不是全随机地图均值；18分钟为待测假设；失败当次无安全格带出，未计药剂/付费包/刷新/市场/额外三选一碎片。'},
 progression:{levels:30,firstLevelXp:200,stepXp:15,clearXp:[6,10,25,80],extractXp:70,failedAttemptXp:24,failedXpMeaning:'仅失败前实际清理4外层格的假设；死亡本身不发经验',weeklyContractCount:3,weeklyContractXp:300,contractCompletionFraction:1,purpleTokenCost:4,orangeTokenCost:14,craftWishPity:3,eliteTokens:1,bossTokens:2,tokenCapPerRun:4,tokenScope:'D1蓝图章，D2+橙图章；高级可向低级1:1抵扣，不可反向；成功撤离结算；刷新/市场/遗物不计'},
 rebuild:{learnedRecipeScope:'当前赛季紫橙品质+部位+元素+效果；只有原始自然掉落或正常印记打造、尚未提取的真实装备可登记；原始item_id只可提取一次，交易保留记录；重铸产物、借用、机器人和活动材料不可登记；红装不可登记或重铸',reforgePurpleCost:1,reforgeOrangeCost:2,fullSetReforgeCost:6,consumeSameQualityBody:true,resultLevel:0,refundEnhancement:false,note:'重铸消耗或原地替换真实同品质本体，不复制装备；旧属性与强化不保留，确认前报价；首次成型与重复重建分别测量。模板重铸产物不产生新的可学习样本。重铸继承本体绑定与来源季限制，借用、Bot投影、活动纯材料不得作为可穿戴重铸输入，不得洗掉交易限制。'},
 combatProposal:{ruleset:'season-combat-v1-candidate',hpRounding:'max(1,floor(baseHP*hpScale))',shieldRounding:'floor(baseShield*shieldScale)，包括意图循环盾',damageOrder:['基础意图按现行蓄力或强化','floor(完整意图*难度倍率)','元素自身增幅与对应抗性后floor，直伤直通','盾职业载壁减伤后floor','PVE未取消且命中的正伤害意图最低1','先盾后血'],minimumDamage:1,minimumDamageScope:'仅本季PVE怪物一次完成的正伤害意图，取消/免疫/纯效果不抬1，PVP保持原样',bossPhaseRatio:.5,castIntervalMs:500,mageFix:'R<2清连携且无焚弦即时抽牌；R>=2按旧E推进，焚弦即时抽数<=min(旧档,N实际耗牌-1)；原卡牌抽牌保留',openGate:'水系和纯抽牌每500ms持续资源正收益仍须真实领域仿真验收，不宣称已解决'},
 seasonalFairness:{cardAndWeapon:'永久等级不改；赛季房间有效等级=min(实际等级,D0-D5档位上限0..5)，PVE/PVP一致；新手可借对应职业固定20张模板及专武，投影到该档上限，不可出售拆解或写回永久存档',entryQuality:'D0最多蓝、D1最多紫、D2+允许橙或红；橙红合计最多1件；普通三选一仍最多橙，红走独立周配额',matchmaking:'同一难度内优先按真实有效属性与装备套装状态匹配，不能只用旧V；不增加独立新手队列',diamondWallet:'钻石永久余额可用于本季橙红市场，存在跨季财富优势；金币和物品仍按季隔离，不自动开放钻兑金'},
 redRules:{enabled:true,weeklyQuota:1,scope:'logical_server_id + natural_week_key；所有地图、难度、渠道和赛季共享',weekBoundary:'服务器时区周一04:00，示例Asia/Shanghai；不滚存，不随重启或换季重置',bossChance:.004,bossEligibleDifficultyMin:2,chestChance:.0008,chestEnabled:false,redNormalLootWeight:0,reforgeAllowed:false,recipeAllowed:false,upgradeMaterialSameQuality:true,materialBodiesForMax:2,dropTo:'临时背包/掉落托管，尚未带出不等于最终持有',legacyAffixPolicy:'保留旧表作为对照；market_model_v2.red.candidate提供待仿真调整参数'},
 validations:{probabilitySum:1,regularLootContainsNoRed:true,weeklyRedEnabled:true,orangeWearCap:1,slotCount:5,cardMaxLevel:5,equipmentMaxLevel:5,bossPhaseRatio:.5,fullCombatSimulation:false},
 notes:[
 '数值是待校准设计输入，所有日期/胜率/局时不是线上实测。',
 '固定三卡样本仅测增伤与抽牌吞吐代理，不等于DPS/TTK或合法完整20卡组胜率。P0假定已拥有8/3/12三卡，并非新号初始默认20张的战斗表现。',
 '样本假设5件均带间隔词条、同一元素；鞋若是逃脱词条，间隔会更慢。',
 '怪物初始盾及循环上盾都按盾倍率；Boss二期是同一个实体、不可重复计其HP。',
 '赛季奖励升档最多升到紫，已自然掷出的橙不降级；所有来源最终服从难度品质帽。',
 '新强化价按可掉落装备重建预算设计，+3常规、+4/+5高风险可选；不是沿用旧橙1984价格。全套+3为60碎，重铸已学模板额外6碎，仍需本体。',
 '专武248成本属于永久养成，不能使用新白装28成本；卡牌魂价保持原表。',
 '收益先逐格逐次floor再求期望；死亡损失记个人成本，拾取与市场是全服转移。',
 '保留每服自然周最多1红，全渠道共享；D2+核心Boss额外0.4%，正常三选一仍无红；D5不要求红装。商店宝箱渠道与额外活动红默认不开，若开也必须占同一配额。',
 '市场、商店、活动和全服流动性在market_model_v2.json单独复算；常规算术表仍区分60强化与66含重铸成本，不能把前者当完整重建成本。',
 ],
 sourceReferences:[
 {file:'GDD.md',section:'§0、§3.1–3.6、§6.9',use:'规则优先级、现行伤害与经济口径'},
 {file:'GDD_BASE_v0.69.md',section:'§2.3、§3.4、§4.6–4.8、§5.6–5.14、§6',use:'现有卡牌装备、成本、地图怪表、机器人和经济'},
 {file:'SERVER_IMPLEMENTATION_STATUS_AND_PLAN.md',section:'配置、V015、托管、遥测',use:'现有服务端边界'},
 {file:'SERVER_0_TO_1_GUIDE.md',section:'配置发布、结算持久化',use:'五行表头与Protobuf导出'},
 ]
};
await fs.writeFile(path.join(root,'analysis/season_model.json'),JSON.stringify(model,null,2));
await fs.writeFile(path.join(out,'season_model_inputs.json'),JSON.stringify(model,null,2));

const floor=(x)=>Math.floor(x+1e-9);
const intMean=(min,max,m)=>{let s=0;for(let x=min;x<=max;x++)s+=floor(x*m);return s/(max-min+1);};
const csv=(rows)=>rows.map(row=>row.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(',')).join('\r\n')+'\r\n';
const results={checks:[],builds:[],economy:[],lootRisk:[],season:[]};
for(const b of builds){
 let damage=0,resist=0,speed=0,cost3=0,cost5=0;
 for(const g of b.gear){const e=equipment.find(x=>x.id===g.quality);damage+=g.count*(e.damageBase+g.level*e.damagePerLevel);resist+=g.count*(e.resistBase+g.level*e.resistPerLevel);speed+=g.count*(e.speedBase+g.level*e.speedPerLevel);cost3+=g.count*e.costs.slice(0,3).reduce((a,b)=>a+b,0);cost5+=g.count*e.costs.reduce((a,b)=>a+b,0);}
 const t=Math.max(1.8,4*(1-speed));const hit=[8,3,12].map(x=>floor((x+b.cardLevel)*(1+damage)*1.4)).reduce((a,b)=>a+b,0);
 results.builds.push({...b,damage,resistRaw:resist,resistEffective:Math.min(.6,resist),interval:t,hit,drawThroughputProxy:hit/31*4/t,cost3,cost5});
}
const counts=model.route.counts;
for(const d of difficulties){
 let gold=0,soul=0,classSoul=0,fragments=0,orange=0;
 layers.forEach((l,i)=>{gold+=counts[i]*floor(l.gold*d.goldScale);soul+=counts[i]*intMean(l.soulMin,l.soulMax,d.soulScale);classSoul+=counts[i]*floor(l.classSoul*d.soulScale);fragments+=counts[i]*intMean(l.fragmentMin,l.fragmentMax,d.fragmentScale);orange+=counts[i]*loot.find(x=>x.difficultyId===d.id&&x.layerId===l.id).weights[4];});
 const perAttempt=.7*fragments-.3*60;
 results.economy.push({difficulty:d.id,gold,soul,classSoul,fragments,orangeCandidates:orange,orangeExtractedPerAttempt:orange*.75*.7,fragmentsPerDay:fragments*.7*60/18,rebuildCost:60,fragmentNetPerAttempt:perAttempt,fragmentNetPerDay:perAttempt*60/18,breakEven:60/(60+fragments),full5BreakEven:780/(780+fragments)});
}
for(const d of [30,42,60]){
 const f=Math.min(1,d/42),pc=equipment[3].costs.map(v=>Math.ceil(v*f)),oc=equipment[4].costs.map(v=>Math.ceil(v*f));
 const xp=Array.from({length:30},(_,i)=>Math.ceil((200+15*i)*f)).reduce((a,b)=>a+b,0);
 const xpDay=60/18*(.7*215+.3*24)+900/7;
 results.season.push({days:d,cost3:4*pc.slice(0,3).reduce((a,b)=>a+b,0)+oc.slice(0,3).reduce((a,b)=>a+b,0),cost5:4*pc.reduce((a,b)=>a+b,0)+oc.reduce((a,b)=>a+b,0),xpTotal:xp,conditionalXpDay:xpDay,conditionalTrackDays:xp/xpDay});
}
const p=.3*.75*.7*.4/3*.2;
results.lootRisk={example:'D2 Boss单候选、目标元素40%、目标效果1/3、指定部位1/5，选装75%、撤离70%；独立同分布示例',p,expectedAttempts:1/p,p50:Math.ceil(Math.log(.5)/Math.log(1-p)),p90:Math.ceil(Math.log(.1)/Math.log(1-p)),note:'未计中层/精英其他橙；真实选择和撤离与品质有关，实际须条件联合模拟'};
const ring=([r,c])=>Math.min(r,c,5-r,5-c);
for(let i=1;i<model.route.coordinates.length;i++){const a=model.route.coordinates[i-1],b=model.route.coordinates[i];if(Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])!==1||ring(b)<ring(a))throw new Error('Illegal route');}
for(const l of loot){if(Math.abs(l.weights.reduce((a,b)=>a+b,0)-1)>1e-8)throw new Error('Bad weights '+l.id);l.weights.forEach((p,q)=>{if(p<0||q>l.qualityCap&&p>0)throw new Error('Bad quality cap '+l.id);});}
results.checks.push({name:'24掉落行概率和及品质帽',passed:true},{name:'R1四邻且不可向外',passed:true},{name:'D0-D5血量与资源单调',passed:difficulties.every((d,i)=>!i||d.hpScale>=difficulties[i-1].hpScale)},{name:'1橙4紫+3成本',value:60,passed:true},{name:'1橙4紫+5成本',value:780,passed:true});
await fs.writeFile(path.join(out,'arithmetic_results.json'),JSON.stringify(results,null,2));
await fs.writeFile(path.join(root,'analysis/arithmetic_results.json'),JSON.stringify(results,null,2));

const csvDir=path.join(out,'config_samples');await fs.mkdir(csvDir,{recursive:true});
function sourceRows(fields,types,scope,descriptions,data){return [fields,types,fields.map(()=>true),fields.map(()=>scope),descriptions,...data];}
await fs.writeFile(path.join(csvDir,'SeasonDifficulty.csv'),'\uFEFF'+csv(sourceRows(
 ['difficulty_id','name_key','hp_scale','shield_scale','damage_scale','interval_scale','gold_scale','soul_scale','fragment_scale','quality_cap','purple_affix_chance','entry_quality_cap','red_boss_enabled'],
 ['string','string',...Array(7).fill('double'),'int64','double','int64','bool'],'both',
 ['稳定难度主键','本地化名称键','生命倍率','护盾倍率','意图伤害倍率','间隔倍率','金币倍率','魂倍率','碎片倍率','普通候选帽：0白1绿2蓝3紫4橙','紫装效果词缀概率','入场帽，5红；橙红合计最多1','独立红渠道，必须同时占全服自然周配额'],
 difficulties.map(d=>[d.id,`difficulty_${d.id}`,d.hpScale,d.shieldScale,d.damageScale,d.intervalScale,d.goldScale,d.soulScale,d.fragmentScale,d.qualityCap,d.purpleAffixChance,d.entryQualityCap,d.redDropEligible]))));
await fs.writeFile(path.join(csvDir,'SeasonLoot.csv'),'\uFEFF'+csv(sourceRows(
 ['loot_rule_id','difficulty_id','layer_id','white_weight','green_weight','blue_weight','purple_weight','orange_weight','quality_cap','promotion_cap'],
 ['string','string','string','double','double','double','double','double','int64','int64'],'both',
 ['稳定掉落主键','难度','格类别','白概率','绿概率','蓝概率','紫概率','橙概率','最终品质帽','额外升档最多至此，天然更高不降'],
 loot.map(l=>[l.id,l.difficultyId,l.layerId,...l.weights,l.qualityCap,l.promotionCap]))));
await fs.writeFile(path.join(csvDir,'SeasonEquipment.csv'),'\uFEFF'+csv(sourceRows(
 ['quality_id','damage_base','resist_base','damage_per_level','resist_per_level','speed_base','speed_per_level','cost_1','cost_2','cost_3','cost_4','cost_5'],
 ['string',...Array(6).fill('double'),...Array(5).fill('int64')],'both',
 ['品质','基础元素增伤','基础抗性','每级增伤','每级抗性','间隔减幅','每级间隔减幅','强化到1费用','到2费用','到3费用','到4费用','到5费用'],
 equipment.map(e=>[e.id,e.damageBase,e.resistBase,e.damagePerLevel,e.resistPerLevel,e.speedBase,e.speedPerLevel,...e.costs]))));
await fs.writeFile(path.join(csvDir,'SeasonProgression.csv'),'\uFEFF'+csv(sourceRows(
 ['level_id','level','xp_to_next_42'],['string','int64','int64'],'both',['稳定等级主键','从此级升级','42天基准经验'],Array.from({length:30},(_,i)=>[`SL${i}`,i,200+15*i]))));
console.log(JSON.stringify({model:path.join(root,'analysis/season_model.json'),results},null,2));
