"""Independent conditional arithmetic audit of the proposed season economy.

This is not a combat simulation. It assumes a completed legal R1 path, iid
extraction success and choice rates, and only the inputs explicitly supplied.
No spreadsheet files are created or edited.
"""
from __future__ import annotations

import json
import math
import hashlib
from collections import defaultdict
from decimal import Decimal, ROUND_FLOOR
from pathlib import Path

BASE = Path(__file__).resolve().parent
MODEL_BYTES = (BASE / "season_model.json").read_bytes()
M = json.loads(MODEL_BYTES)
OLD = json.loads((BASE / "arithmetic_results.json").read_text())
A = M["assumptions"]
P = M["progression"]
DIFF = {x["id"]: x for x in M["difficulties"]}
GEAR = {x["id"]: x for x in M["equipment"]}
LOOT = {(x["difficultyId"], x["layerId"]): x for x in M["loot"]}
LAYERS = M["layers"]
COUNTS = M["route"]["counts"]
PE = A["extractionRate"]
CHOICE = A["gearChoiceRate"]
MINUTES = A["minutesPerAttempt"]


def floor_scaled(value, multiplier):
    return int((Decimal(value) * Decimal(str(multiplier))).to_integral_value(rounding=ROUND_FLOOR))


def uniform_floor_mean(lo, hi, multiplier):
    return sum(floor_scaled(i, multiplier) for i in range(lo, hi + 1)) / (hi - lo + 1)


def geom_summary(prob):
    if prob <= 0:
        return {"probabilityPerAttempt": 0, "expectedAttempts": None, "p50Attempts": None, "p90Attempts": None}
    return {
        "probabilityPerAttempt": prob,
        "expectedAttempts": 1 / prob,
        "p50Attempts": max(1, math.ceil(math.log1p(-0.5) / math.log1p(-prob))),
        "p90Attempts": max(1, math.ceil(math.log1p(-0.9) / math.log1p(-prob))),
    }


def binom_mass(n, k, p=PE):
    if not 0 <= k <= n:
        return 0.0
    return math.comb(n, k) * p**k * (1 - p)**(n - k)


def success_count_cdf(n, minimum, p=PE):
    if n < minimum:
        return 0.0
    return max(0.0, min(1.0, 1 - sum(binom_mass(n, k, p) for k in range(minimum))))


def first_quantile(cdf, q):
    for n in range(1, 10001):
        if cdf(n) >= q:
            return n
    raise ValueError("quantile beyond explicit bound")


def natural_success_chance(did, fit, quality=4):
    no_hit = 1.0
    expected_count = 0.0
    for layer, count in zip(LAYERS, COUNTS):
        probability = LOOT[(did, layer["id"])]["weights"][quality] * CHOICE * fit
        no_hit *= (1 - probability) ** count
        expected_count += count * probability
    return 1 - no_hit, expected_count


def craft_distribution(token_cost, desired_effect=False):
    tokens_per_success = min(P["tokenCapPerRun"], COUNTS[2] * P["eliteTokens"] + COUNTS[3] * P["bossTokens"])
    if desired_effect:
        effect_probability = 1 / 3
        weights = [effect_probability, (1 - effect_probability) * effect_probability, (1 - effect_probability) ** 2]
    else:
        weights = [1.0]
    thresholds = [math.ceil(token_cost * (i + 1) / tokens_per_success) for i in range(len(weights))]
    cdf = lambda n: sum(w * success_count_cdf(n, t) for w, t in zip(weights, thresholds))
    return {
        "tokenCostEach": token_cost,
        "marksPerSuccess": tokens_per_success,
        "weightsByCraftNumber": weights,
        "successThresholds": thresholds,
        "hardBoundSuccessfulExtractions": max(thresholds),
        "hardBoundAttempts": None,
        "expectedAttempts": sum(w * t / PE for w, t in zip(weights, thresholds)),
        "p50Attempts": first_quantile(cdf, .5),
        "p90Attempts": first_quantile(cdf, .9),
    }


def combined_distribution(craft, natural_chance_per_success):
    weights, thresholds = craft["weightsByCraftNumber"], craft["successThresholds"]

    def cdf(n):
        no_hit = 0.0
        for successes in range(min(n + 1, max(thresholds))):
            craft_hit = sum(w for w, t in zip(weights, thresholds) if successes >= t)
            no_hit += binom_mass(n, successes) * (1 - natural_chance_per_success) ** successes * (1 - craft_hit)
        return 1 - no_hit

    return {"p50Attempts": first_quantile(cdf, .5), "p90Attempts": first_quantile(cdf, .9)}


checks = []


def check(name, condition, **values):
    checks.append({"name": name, "passed": bool(condition), **values})


new3 = sum(GEAR["orange"]["costs"][:3]) + 4 * sum(GEAR["purple"]["costs"][:3])
new5 = sum(GEAR["orange"]["costs"]) + 4 * sum(GEAR["purple"]["costs"])
old3 = sum(GEAR["orange"]["oldCosts"][:3]) + 4 * sum(GEAR["purple"]["oldCosts"][:3])
reforge = M.get("rebuild", {}).get("reforgeOrangeCost", 2) + 4 * M.get("rebuild", {}).get("reforgePurpleCost", 1)
complete_rebuild = new3 + reforge
check("new full set +3 cost", new3 == 60, value=new3)
check("new full set +5 cost", new5 == 780, value=new5)
check("old full set +3 cost", old3 == 1344, value=old3)
check("permanent weapon independent cost", sum(GEAR["white"]["oldCosts"]) == 248 and sum(GEAR["white"]["costs"]) == 28, weaponCost=248, seasonalWhiteCost=28)
check("learned recipe reforge plus enhancement", reforge == 6 and complete_rebuild == 66, value=complete_rebuild)

sources = []
for did, difficulty in DIFF.items():
    fragments = sum(c * uniform_floor_mean(l["fragmentMin"], l["fragmentMax"], difficulty["fragmentScale"]) for l, c in zip(LAYERS, COUNTS))
    baseline = next(x for x in OLD["economy"] if x["difficulty"] == did)
    check(f"{did} independently rounded fragment expectation", math.isclose(fragments, baseline["fragments"], abs_tol=1e-10), actual=fragments, prior=baseline["fragments"])
    sources.append({
        "difficulty": did,
        "oneOrangeFourPurpleLegalForDifficulty": difficulty["qualityCap"] >= 4,
        "loadoutCaveat": "D0/D1 cannot carry this loadout; their cost60/780 ratios are hypothetical stress diagnostics only, not an available farming path" if difficulty["qualityCap"] < 4 else "legal quality cap; real combat viability unverified",
        "fragmentsPerSuccessfulR1": fragments,
        "netPerAttemptAt70pct_plus3": PE * fragments - (1 - PE) * new3,
        "breakEven_plus3": new3 / (new3 + fragments),
        "breakEven_plus5": new5 / (new5 + fragments),
        "maximumSustainableRebuildCostAt70pct": PE * fragments / (1 - PE),
        "excludes": "body acquisition, crafting marks, gear materials, potions, gold, marketplace, extra fragment choice, safety slots",
    })

natural = []
fit_rates = {
    "anyOrange": 1.0,
    "themeElementAndEffectAnySlot": A["targetElementWeight"] * A["targetEffectWeight"],
    "themeElementEffectAndSlot": A["targetElementWeight"] * A["targetEffectWeight"] * A["targetSlotWeight"],
    "offThemeElementEffectAndSlot": ((1 - A["targetElementWeight"]) / 4) * A["targetEffectWeight"] * A["targetSlotWeight"],
}
for did in ["D2", "D3", "D4", "D5"]:
    for target, fit in fit_rates.items():
        q, mean = natural_success_chance(did, fit)
        natural.append({"difficulty": did, "target": target, "fitConditionalOnOrange": fit, "probabilityPerSuccessfulR1": q,
                        "expectedCountPerAttempt": PE * mean, **geom_summary(PE * q)})

crafts = {
    "anyOrangeFixedSlotAndElement": craft_distribution(P["orangeTokenCost"]),
    "targetOrangeWithThreeCraftEffectGuarantee": craft_distribution(P["orangeTokenCost"], True),
    "targetPurpleWithThreeCraftEffectGuarantee": craft_distribution(P["purpleTokenCost"], True),
}
combined = []
for did in ["D2", "D3", "D4", "D5"]:
    for name, target in [("anyOrangeFixedSlotAndElement", "anyOrange"), ("targetOrangeWithThreeCraftEffectGuarantee", "themeElementEffectAndSlot")]:
        q, _ = natural_success_chance(did, fit_rates[target])
        combined.append({"difficulty": did, "target": target, **combined_distribution(crafts[name], q)})

success_xp = sum(c * x for c, x in zip(COUNTS, P["clearXp"])) + P["extractXp"]
failed_xp = P["failedAttemptXp"]
xp_per_attempt = PE * success_xp + (1 - PE) * failed_xp
xp_total = sum(P["firstLevelXp"] + P["stepXp"] * i for i in range(P["levels"]))
check("30 earned levels XP", xp_total == 12525, actual=xp_total)
check("R1 success XP", success_xp == 215, actual=success_xp)

xp_rows = []
for minutes in [30, 60, 120]:
    for contract_completion in [.5, 1.0]:
        contract_daily_average = P["weeklyContractCount"] * P["weeklyContractXp"] * contract_completion / 7
        for time_policy in ["averagedBudgetAcrossDays", "strictWholeAttemptsEachDay"]:
            attempts_per_day = minutes / MINUTES if time_policy == "averagedBudgetAcrossDays" else minutes // MINUTES
            expected_daily_xp = attempts_per_day * xp_per_attempt + contract_daily_average
            expected_finish = xp_total / expected_daily_xp
            discrete_finish = None
            for day in range(1, 366):
                attempts = math.floor(day * minutes / MINUTES) if time_policy == "averagedBudgetAcrossDays" else day * (minutes // MINUTES)
                contracts = math.floor((day // 7) * P["weeklyContractCount"] * contract_completion)
                total = attempts * xp_per_attempt + contracts * P["weeklyContractXp"]
                if total >= xp_total:
                    discrete_finish = day
                    break
            xp_rows.append({
                "dailyMinutes": minutes,
                "weeklyContractCompletion": contract_completion,
                "timePolicy": time_policy,
                "attemptsPerDay": attempts_per_day,
                "expectedXpPerDayIncludingAmortizedWeekly": expected_daily_xp,
                "expectedDaysWithSmoothedWeekly": expected_finish,
                "expectedThresholdDayWeeklyPaidAtEnd": discrete_finish,
                "fractionOf12525ByDay42Smoothed": 42 * expected_daily_xp / xp_total,
                "weeklyPaidAtEndAssumption": "all completed weekly contracts credited on day7,14,...; 50% floors cumulative completed contract count; no claim of stochastic completion probability",
            })

resource_at_d2 = next(x["fragmentsPerSuccessfulR1"] for x in sources if x["difficulty"] == "D2")
death_thresholds = {
    "oldPlus3Cost": old3,
    "oldPlus3BreakEven": old3 / (old3 + resource_at_d2),
    "newPlus3Cost": new3,
    "newPlus3BreakEven": new3 / (new3 + resource_at_d2),
    "learnedRecipeReforgeCost": reforge,
    "completeLearnedRecipeRebuildCost": complete_rebuild,
    "completeRebuildFragmentBreakEven": complete_rebuild / (complete_rebuild + resource_at_d2),
    "completeRebuildFragmentNetAt70pct": PE * resource_at_d2 - (1 - PE) * complete_rebuild,
    "newPlus5Cost": new5,
    "newPlus5BreakEven": new5 / (new5 + resource_at_d2),
    "netAt70pct": PE * resource_at_d2 - (1 - PE) * new3,
    "extraFragmentCostBudgetPerAttemptBeforeBreakEven": PE * resource_at_d2 - (1 - PE) * new3,
    "successRates": [{"successRate": p, "netPlus3": p * resource_at_d2 - (1 - p) * new3} for p in [.4, .5, .6, .65, .7, .8, .9]],
}

# Exact finite sum for only the modeled random fragment gain, conditional on
# successful extraction, followed by an absorbing reserve-shortage process.
gain_distribution = {0: 1.0}
for layer, count in zip(LAYERS, COUNTS):
    lo, hi = layer["fragmentMin"], layer["fragmentMax"]
    die = defaultdict(float)
    for v in range(lo, hi + 1):
        die[floor_scaled(v, DIFF["D2"]["fragmentScale"])] += 1 / (hi - lo + 1)
    for _ in range(count):
        nxt = defaultdict(float)
        for old, po in gain_distribution.items():
            for gain, pg in die.items():
                nxt[old + gain] += po * pg
        gain_distribution = dict(nxt)
check("D2 distribution mean", math.isclose(sum(v * p for v, p in gain_distribution.items()), 40, abs_tol=1e-10))

reserve_risk = []
for rebuild_cost in [new3, complete_rebuild]:
    for reserve in [0, 60, 120, 180, 300]:
        alive = {reserve: 1.0}
        bankrupt = 0.0
        for attempt in range(1, 141):
            nxt = defaultdict(float)
            for balance, mass in alive.items():
                for gain, pg in gain_distribution.items():
                    nxt[balance + gain] += mass * PE * pg
                if balance < rebuild_cost:
                    bankrupt += mass * (1 - PE)
                else:
                    nxt[balance - rebuild_cost] += mass * (1 - PE)
            alive = dict(nxt)
            if attempt in [30, 60, 140]:
                reserve_risk.append({"rebuildCost": rebuild_cost, "startingLiquidFragmentReserve": reserve, "attemptHorizon": attempt,
                                     "probabilityCannotImmediatelyRebuildPlus3AtLeastOnce": bankrupt})

# Body throughput is distinct from fragment throughput. This optimistic
# accounting ignores slot collisions and assumes sufficient inventory buffer.
_, orange_per_success = natural_success_chance("D2", 1, 4)
_, purple_per_success = natural_success_chance("D2", 1, 3)
death_per_success = (1 - PE) / PE
ordinary_tokens_needed = max(0, death_per_success - orange_per_success) * P["orangeTokenCost"] + max(0, 4 * death_per_success - purple_per_success) * P["purpleTokenCost"]
crafts_per_desired = 1/3 + 2 * 2/9 + 3 * 4/9
desired_orange_natural_per_success = orange_per_success * fit_rates["themeElementEffectAndSlot"]
long_run_desired_orange_from_marks_per_success = 3 / (P["orangeTokenCost"] * crafts_per_desired)
body_check = {
    "orangeNaturalPerSuccess": orange_per_success,
    "purpleNaturalPerSuccess": purple_per_success,
    "orangeNaturalPerAttempt": PE * orange_per_success,
    "purpleNaturalPerAttempt": PE * purple_per_success,
    "orangeLossPerAttempt": 1 - PE,
    "purpleLossPerAttempt": 4 * (1 - PE),
    "ordinaryBodyMarkBudgetNeededPerSuccess": ordinary_tokens_needed,
    "ordinaryBodyMarkBudgetNeededPerAttempt": PE * ordinary_tokens_needed,
    "markIncomePerSuccess": 3,
    "expectedCraftsForDesiredEffectWithThirdGuarantee": crafts_per_desired,
    "targetOrangeNaturalPerSuccess": desired_orange_natural_per_success,
    "targetOrangeFromMarksPerSuccessAllMarksAllocated": long_run_desired_orange_from_marks_per_success,
    "targetOrangeBreakEvenExtractionRateOptimistic": 1 / (1 + desired_orange_natural_per_success + long_run_desired_orange_from_marks_per_success),
    "note": "best-case long-run mark carry, all marks to orange for target calculation; no slot collisions, no purple mark use, no material sacrifices. Target-body sustainability therefore worse in actual constrained play.",
}

body_rebuild_cost_in_marks = P["orangeTokenCost"] + 4 * P["purpleTokenCost"]
natural_body_substitution_in_marks = orange_per_success * P["orangeTokenCost"] + purple_per_success * P["purpleTokenCost"]
steady_body_break_even = body_rebuild_cost_in_marks / (body_rebuild_cost_in_marks + natural_body_substitution_in_marks + 3)
recipe_rows = []
for p in [.5, .6, .65, .6896551724137931, .7, .75, .8]:
    deficit_orange = max(0, (1 - p) - p * orange_per_success)
    deficit_purple = max(0, 4 * (1 - p) - p * purple_per_success)
    needed_marks = deficit_orange * P["orangeTokenCost"] + deficit_purple * P["purpleTokenCost"]
    recipe_rows.append({"extractionRate": p, "fragmentNetPerAttempt": p * resource_at_d2 - (1-p)*complete_rebuild,
                        "bodyMarkNeedPerAttempt": needed_marks, "markIncomePerAttempt": 3*p,
                        "netMarksAfterBodyReplacement": 3*p-needed_marks})

upper_successes = math.ceil(body_rebuild_cost_in_marks / 3)
recipe_check = {
    "status": "conditional steady-state arithmetic only, all five target templates already learned",
    "fragmentRebuildCost": complete_rebuild,
    "fragmentNetPerAttempt70pct": PE * resource_at_d2 - (1-PE) * complete_rebuild,
    "fragmentBreakEven": complete_rebuild / (complete_rebuild + resource_at_d2),
    "bodyMarkBreakEven": steady_body_break_even,
    "naturalOrangePerSuccessfulRun": orange_per_success,
    "naturalPurplePerSuccessfulRun": purple_per_success,
    "bodyMarkNeedPerAttempt70pct": PE * ordinary_tokens_needed,
    "markIncomePerAttempt70pct": 3 * PE,
    "netMarksAfterReplacement70pct": 3 * PE - PE * ordinary_tokens_needed,
    "sensitivity": recipe_rows,
    "startingFromNoBodiesCraftOnlyBound": {
        "marksForOneOrangeFourPurple": body_rebuild_cost_in_marks,
        "successfulExtractionsNeeded": upper_successes,
        "p50AttemptsToCollectThatManySuccesses": first_quantile(lambda n: success_count_cdf(n, upper_successes), .5),
        "p90AttemptsToCollectThatManySuccesses": first_quantile(lambda n: success_count_cdf(n, upper_successes), .9),
        "note": "Pessimistic craft-only path ignores natural bodies, assumes R1 remains playable at70% success without this target kit. Not a measured rebuild time or an attempt-count guarantee. Tokens are reserved entirely for this kit; no concurrent consumption.",
    },
    "invariants": [
        "Every reforge consumes or atomically replaces exactly one same-quality real body and gives exactly one +0 output; no enhancement refund.",
        "Registration does not destroy or duplicate the body; immutable recipe key includes season+quality+slot+element+effect.",
        "Full provenance survives sale, drop, pick-up and reforge; bots or borrowed originals cannot become registrable via a new owner or new item id.",
        "Replacement-body crafting retains full14/4 mark cost and does not mint bonus bodies at effect pity.",
        "Reforging always occurs in the hall, respects learned targets and quality restrictions, and has a versioned quote and atomic consumption.",
        "This supports repeated reconstruction after first learning. It does not prove first-five-template acquisition time, actual post-death combat viability, or liquidity availability.",
    ],
}

recipe_difficulty_rows = []
for did in ["D2", "D3", "D4", "D5"]:
    _, o = natural_success_chance(did, 1, 4)
    _, v = natural_success_chance(did, 1, 3)
    def net_mark(p):
        need = max(0, 1-p-p*o)*P["orangeTokenCost"] + max(0, 4*(1-p)-p*v)*P["purpleTokenCost"]
        return 3*p-need
    lo, hi = 0.0, 1.0
    for _ in range(60):
        mid = (lo+hi)/2
        if net_mark(mid) >= 0:
            hi = mid
        else:
            lo = mid
    fragments = next(x["fragmentsPerSuccessfulR1"] for x in sources if x["difficulty"] == did)
    recipe_difficulty_rows.append({"difficulty": did, "orangePerSuccess": o, "purplePerSuccess": v,
                                   "fragmentBreakEvenExtraction": complete_rebuild/(complete_rebuild+fragments),
                                   "bodyMarkBreakEvenExtraction": hi,
                                   "bindingMinimumExtractionForBoth": max(hi, complete_rebuild/(complete_rebuild+fragments)),
                                   "fragmentNetAt70pct": PE*fragments-(1-PE)*complete_rebuild,
                                   "marksAfterReplacementAt70pct": net_mark(PE),
                                   "note": "same conditional R1 and choice rates; do not assume real extraction success or attempt duration is equal across difficulties"})
recipe_check["difficultySensitivity"] = recipe_difficulty_rows

results = {
    "scope": "Independent conditional arithmetic. No real combat, route generation, actual player behavior, telemetry, or measured extraction rates.",
    "modelVersion": M["meta"]["version"],
    "modelSha256": hashlib.sha256(MODEL_BYTES).hexdigest(),
    "checks": checks,
    "sourceFragComparisons": sources,
    "naturalOrange": natural,
    "crafting": crafts,
    "naturalPlusCrafting": combined,
    "xp": {"successXp": success_xp, "failedXpAssumption": failed_xp, "expectedXpPerAttempt": xp_per_attempt, "total": xp_total, "sensitivity": xp_rows},
    "deathSustainability": death_thresholds,
    "bodySustainability": body_check,
    "learnedRecipeRebuild": recipe_check,
    "reserveRuinRisk": reserve_risk,
    "limitations": [
        "Extraction and gear choice modeled independent of rolled reward value, combat state, and player behavior.",
        "R1 is one legal conditional layout, not a random-map population average.",
        "Failed XP24 represents an assumed four cleared outer cells, not an automatic death grant.",
        "Three-craft guarantee must have state keyed by quality+slot+element+chosen effect and survive retries; it guarantees success count, never a finite number of failed attempts.",
        "Fragment-positive expectation does not establish sustainable item bodies, affixes, account solvency, or real success rates.",
        "Daily 30/18 is only a flexible cross-day time budget; strict 30-minute sessions fit one fixed18-minute attempt.",
        "Reserve-risk model starts with already-equipped +3 gear and assumes fresh replacement bodies are free and immediately available. It is a liquidity warning, not player retention prediction.",
        "Natural target element40% is the favored season element; an off-theme element has15% under equal distribution of the remaining60%.",
    ],
}
(BASE / "independent_economy_results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")
lines = ["Independent economy arithmetic review", f"Checks: {sum(x['passed'] for x in checks)}/{len(checks)}", "", "D2 natural orange:"]
for row in natural:
    if row["difficulty"] == "D2":
        lines.append(f"{row['target']}: P50={row['p50Attempts']} P90={row['p90Attempts']} mean={row['expectedAttempts']:.3f} p/attempt={row['probabilityPerAttempt']:.8f}")
lines += ["", "Crafting:"]
for name, row in crafts.items():
    lines.append(f"{name}: P50={row['p50Attempts']} P90={row['p90Attempts']} mean={row['expectedAttempts']:.3f}; successful-extraction bound={row['hardBoundSuccessfulExtractions']}")
lines += ["", "XP sensitivity:"]
for row in xp_rows:
    lines.append(f"{row['dailyMinutes']}min {row['weeklyContractCompletion']:.0%} {row['timePolicy']}: smoothed={row['expectedDaysWithSmoothedWeekly']:.2f}days weekly-arrears-day={row['expectedThresholdDayWeeklyPaidAtEnd']}")
lines += ["", "Body sustainability before learned recipes:", json.dumps(body_check, ensure_ascii=False),
          "", "Learned recipe rebuild:", json.dumps(recipe_check, ensure_ascii=False), "", "Reserve risk (140 attempts):"]
for row in reserve_risk:
    if row["attemptHorizon"] == 140:
        lines.append(f"cost={row['rebuildCost']} reserve={row['startingLiquidFragmentReserve']}: {row['probabilityCannotImmediatelyRebuildPlus3AtLeastOnce']:.2%}")
(BASE / "independent_economy_review.txt").write_text("\n".join(lines) + "\n")
print("\n".join(lines))
assert all(x["passed"] for x in checks), "Independent check failed"
