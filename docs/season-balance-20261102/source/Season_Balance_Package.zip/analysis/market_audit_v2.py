"""Market/material arithmetic for Relicbound season proposal v2.

Reads the prior candidate as a source. Never modifies that model or workbook.
All population, resale, recovery and listing-depth scenarios are explicitly
assumed. This is not a live price model or a combat simulation.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import math
from collections import defaultdict
from decimal import Decimal, ROUND_FLOOR
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODEL_BYTES = (ROOT / "season_model.json").read_bytes()
M = json.loads(MODEL_BYTES)
A = M["assumptions"]
P = M["progression"]
LAYERS = M["layers"]
COUNTS = M["route"]["counts"]
LOOT = {(x["difficultyId"], x["layerId"]): x for x in M["loot"]}
DIFF = {x["id"]: x for x in M["difficulties"]}
N = 1000
p = .7
choose_gear = .75
checks = []


def check(name, ok, **detail):
    checks.append({"name": name, "passed": bool(ok), **detail})


def floor_scale(value, factor):
    return int((Decimal(value) * Decimal(str(factor))).to_integral_value(rounding=ROUND_FLOOR))


def expected_floor(lo, hi, factor):
    return sum(floor_scale(i, factor) for i in range(lo, hi + 1)) / (hi - lo + 1)


def tax(price):
    return max(1, price // 10)


def proceeds(price):
    return price - tax(price)


def binomial_at_least(n, k, success=.7):
    if n < k:
        return 0.0
    return max(0, min(1, 1 - sum(math.comb(n, j) * success**j * (1-success)**(n-j) for j in range(k))))


def quantile(cdf, q):
    for n in range(1, 10001):
        if cdf(n) >= q:
            return n
    raise RuntimeError("quantile exceeded finite search domain")


fresh = {}
for quality_index, quality in enumerate(["white", "green", "blue", "purple", "orange"]):
    candidates = sum(c * LOOT[("D2", layer["id"])]["weights"][quality_index] for c, layer in zip(COUNTS, LAYERS))
    fresh[quality] = N * p * choose_gear * candidates
gold_success = sum(c * floor_scale(layer["gold"], DIFF["D2"]["goldScale"]) for c, layer in zip(COUNTS, LAYERS))
frag_success = sum(c * expected_floor(layer["fragmentMin"], layer["fragmentMax"], DIFF["D2"]["fragmentScale"]) for c, layer in zip(COUNTS, LAYERS))
gold = N * p * gold_success
fragments = N * p * frag_success
marks = N * p * 3
deaths = N * (1-p)
lost = {"orange": deaths, "purple": 4 * deaths}
gear = {x["id"]: x for x in M["equipment"]}
cost3 = sum(gear["orange"]["costs"][:3]) + 4 * sum(gear["purple"]["costs"][:3])
cost5 = sum(gear["orange"]["costs"]) + 4 * sum(gear["purple"]["costs"])
reforge_cost = M.get("rebuild", {}).get("fullSetReforgeCost", 6)
cost_rebuild = cost3 + reforge_cost

check("full successful export by quality", math.isclose(sum(fresh.values()), 4200))
check("D2 gold/fragments", gold_success == 223 and math.isclose(frag_success, 40), gold=gold_success, fragments=frag_success)
check("D2 orange/purple", math.isclose(fresh["orange"], 220.5) and math.isclose(fresh["purple"], 1065.75))
check("full rebuild", cost_rebuild == 66)

stock_rows = []
for recovery in [0, .25, .5, .8]:
    for full_set_plus5_actions in [0, 10, 25]:
        sinks = {q: lost[q] * (1-recovery) for q in lost}
        materials = {"orange": 2 * full_set_plus5_actions, "purple": 8 * full_set_plus5_actions}
        balances = {q: fresh[q] - sinks[q] - materials[q] for q in lost}
        craft_extra = {q: max(0, -balances[q]) for q in lost}
        required_marks = 14 * craft_extra["orange"] + 4 * craft_extra["purple"]
        fragment_consumption = deaths * cost_rebuild + full_set_plus5_actions * (cost5 - cost3)
        stock_rows.append({
            "wornDeathGearFinalRecoveryFraction": recovery,
            "fullSetPlus3ToPlus5Actions": full_set_plus5_actions,
            "naturalNewOrange": fresh["orange"], "naturalNewPurple": fresh["purple"],
            "personalLossOrange": lost["orange"], "personalLossPurple": lost["purple"],
            "trueRoomEndDestruction": sinks,
            "upgradeMaterialDestruction": materials,
            "stockChangeBeforeCraft": balances,
            "minimumExtraBodyCrafts": craft_extra,
            "marksToFillQualityShortage": required_marks,
            "marksAfterBodyCrafts": marks-required_marks,
            "fragmentConsumptionUnderAllOwnersRebuildPolicy": fragment_consumption,
            "fragmentNetUnderAllOwnersRebuildPolicy": fragments-fragment_consumption,
            "note": "Recovery is final re-export by anyone. No failed-run newly generated loot, bot loot, shop/activity gear or direct reuse benefit is counted. Reforge changes body attributes one-for-one and is not a net body sink.",
        })

# Every first craft makes a real body even when its effect misses the wish.
# Therefore first-learning craft bodies must offset ordinary replacement needs.
wish_probs = {1: 1/3, 2: 2/9, 3: 4/9}
expected_crafts = sum(k*v for k, v in wish_probs.items())
learning_mark_distribution = defaultdict(float)
for counts in itertools.product([1, 2, 3], repeat=5):
    total_marks = 14*counts[0]+4*sum(counts[1:])
    probability = math.prod(wish_probs[x] for x in counts)
    learning_mark_distribution[total_marks] += probability
expected_learning_marks = sum(k*v for k, v in learning_mark_distribution.items())
learning_success_cdf = lambda n: sum(prob*binomial_at_least(n, math.ceil(mark_cost/3)) for mark_cost, prob in learning_mark_distribution.items())
check("first five templates mark mean", math.isclose(expected_learning_marks, 190/3))
check("first template distribution normalized", math.isclose(sum(learning_mark_distribution.values()), 1))

learning_rows = []
for recovery in [0, .25, .5]:
    for learners in [0, 10, 20, 25, 30, 40]:
        learning_bodies = {"orange": learners*expected_crafts, "purple": learners*4*expected_crafts}
        true_destruction = {q: lost[q]*(1-recovery) for q in lost}
        extra = {q: max(0, true_destruction[q]-fresh[q]-learning_bodies[q]) for q in lost}
        learning_spend = learners*expected_learning_marks
        extra_spend = extra["orange"]*14 + extra["purple"]*4
        naive_double_counted = learning_spend + sum(max(0, true_destruction[q]-fresh[q]) * {"orange":14,"purple":4}[q] for q in lost)
        check(f"learning body credit {recovery}/{learners}", learning_spend+extra_spend <= naive_double_counted+1e-8)
        learning_rows.append({
            "wornDeathGearFinalRecoveryFraction": recovery,
            "newFiveTemplateLearners": learners,
            "originalBodiesFromLearningCrafts": learning_bodies,
            "learningCraftMarkCost": learning_spend,
            "additionalReplacementCraftMarkCost": extra_spend,
            "totalUniqueCraftMarkCost": learning_spend+extra_spend,
            "markBalanceAfterUniqueCrafts": marks-learning_spend-extra_spend,
            "wrongNaiveLearningPlusAllReplacementCost": naive_double_counted,
            "note": "Only quality-total expectation; first-learning and survival order not simulated. Market purchases substitute for self-crafting, but do not create new bodies or reset extraction eligibility.",
        })

sample_supply = {
    "themeElementChance": .4, "effectChanceConditionalOnAffix": 1/3, "slotChance": .2,
    "targetOrangeOriginalSamplesPer1000Attempts": fresh["orange"]*.4/3*.2,
    "targetPurpleOriginalSamplesPer1000Attempts": fresh["purple"]*.4*DIFF["D2"]["purpleAffixChance"]/3*.2,
    "eligibleSource": "original field drops or normal token crafts, not reforged/event-material/borrowed/bot; unextracted flag persists across sale",
    "registrationConsumesBody": False,
    "registrationConsumesTeachingRight": True,
    "reforgeOutputsTeachingRight": False,
}

availability = []
for active_orange_listings in [5, 10, 20, 50, 100]:
    for currency_share in [1, .5, .2]:
        for unextracted_fraction in [1, .5]:
            matching = active_orange_listings * (.4/3*.2) * currency_share * unextracted_fraction
            availability.append({"activeOrangeListingsAcrossCurrencies": active_orange_listings,
                                 "payableCurrencyShare": currency_share,
                                 "unextractedFraction": unextracted_fraction,
                                 "expectedTargetListings": matching,
                                 "poissonChanceAtLeastOneTarget": -math.expm1(-matching)})

sale_rates = []
for arrivals_per_listing_day in [.05, .1, .2, .5, 1, 2]:
    sale_rates.append({"effectiveBuyerArrivalPerListingDay": arrivals_per_listing_day,
                       "saleChanceWithin48h": -math.expm1(-2*arrivals_per_listing_day),
                       "uncensoredP50Days": math.log(2)/arrivals_per_listing_day,
                       "uncensoredP90Days": math.log(10)/arrivals_per_listing_day})

tax_examples = []
for currency, value in [("gold", 1), ("gold", 9), ("gold", 19), ("gold", 1000), ("gold", 99999), ("diamond", 2000), ("diamond", 8000)]:
    buyer, seller, sink = -value, proceeds(value), tax(value)
    check(f"ledger {currency}/{value}", buyer+seller+sink == 0)
    tax_examples.append({"currency":currency,"gross":value,"buyerDelta":buyer,"sellerDelta":seller,"treasurySink":sink,"allPlayerWalletDelta":buyer+seller})

# Executable-quote counterexample, NOT a recommended price or market forecast.
cycle = {"itemAGoldAsk":1000,"itemADiamondBid":100,"itemBDiamondAsk":90,"itemBGoldBid":1200}
diamond_after_a = proceeds(cycle["itemADiamondBid"])
gold_end = proceeds(cycle["itemBGoldBid"])
check("synthetic player-arbitrage budget", diamond_after_a == cycle["itemBDiamondAsk"])
cycle.update({"initialGold":1000,"initialDiamond":0,"finalGold":gold_end,"finalDiamond":0,
              "traderGoldProfit":gold_end-1000,
              "globalGoldTax":tax(1000)+tax(1200),
              "globalDiamondTax":tax(100)+tax(90),
              "sourceOfProfit":"counterparty price differences, not system currency creation",
              "conditions":"all four quotes executable with adequate depth; two sales by trader, two purchases; no NPC gold-diamond exchange enabled"})

results = {
    "status":"independent market accounting scenarios; no observed DAU, prices, trading volume or recovery rate",
    "inputSha256":hashlib.sha256(MODEL_BYTES).hexdigest(),
    "checks":checks,
    "normalizedInputs":{"attempts":N,"difficulty":"D2","route":"R1 conditional layout","extractionRate":p,"gearChoiceRate":choose_gear,
                        "successes":N*p,"deaths":deaths,"minutesPerAttemptNotUsedForPopulationForecast":18,
                        "freshExportedGear":fresh,"goldFromSuccessfulDirectExtraction":gold,
                        "fragmentsFromSuccessfulDirectExtraction":fragments,"marks":marks,
                        "redMint":"not inferred from attempt count; separate server/week quota ledger"},
    "stockAndUpgradeScenarios":stock_rows,
    "firstLearning":{"craftsPerTargetMean":expected_crafts,"fiveTemplateMarkMean":expected_learning_marks,
                     "fiveTemplateMarkWorst":90,"fiveTemplateMarkBest":30,
                     "selfCraftOnlyP50Attempts":quantile(learning_success_cdf,.5),
                     "selfCraftOnlyP90Attempts":quantile(learning_success_cdf,.9),
                     "note":"not a market-inclusive time; all five template wishes independent, natural matching samples ignored",
                     "markDistribution":dict(learning_mark_distribution)},
    "learningAndReplacementWithoutDoubleCount":learning_rows,
    "originalTeachingSamples":sample_supply,
    "lowDepthTargetAvailability":availability,
    "sellThroughPoissonScenarios":sale_rates,
    "effectiveArrivalRequiredFor90pctSaleWithin48h":-math.log(.1)/2,
    "goldDiamondTaxExamples":tax_examples,
    "syntheticCrossCurrencyArbitrage":cycle,
    "worldLedgers":{
        "gold":"new PVE exports + explicit NPC buyback/event grants + enabled FX mint - NPC spending - gold market tax - irreversible gold loss; player-market gross is transfer",
        "diamond":"purchases/top-ups + explicit transferable grants - NPC spending - diamond market tax - refunds/chargebacks; sale proceeds are transfer",
        "equipment":"fresh natural + normal craft + bot + NPC/activity grants - room-end unexported destruction - enhancement material consumption - true dismantling; transfers/registration/reforge do not add net bodies",
        "unextractedSamples":"opening eligible samples + eligible original natural + original normal craft - first extractions - unextracted samples lost at room end or consumed as enhancement material - unextracted input samples used for reforging; market transfer no change; reforging produces zero sample rights",
        "red":"quota successful atomic mint + opening stock - true destruction - enhancement materials; resale/death movement never restores quota",
    },
}
(ROOT/"market_audit_v2_results.json").write_text(json.dumps(results,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"passed":sum(x["passed"] for x in checks),"total":len(checks),
                  "normalizedInputs":results["normalizedInputs"],"firstLearning":{k:v for k,v in results["firstLearning"].items() if k!="markDistribution"},
                  "stockBaseRows":[x for x in stock_rows if x["fullSetPlus3ToPlus5Actions"]==0],
                  "learningExample":[x for x in learning_rows if x["wornDeathGearFinalRecoveryFraction"]==0 and x["newFiveTemplateLearners"] in [10,20,30]],
                  "sampleSupply":sample_supply,"cycle":cycle},ensure_ascii=False,indent=2))
assert all(x["passed"] for x in checks)
