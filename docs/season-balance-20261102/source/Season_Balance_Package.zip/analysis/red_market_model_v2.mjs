#!/usr/bin/env node
/** Independent red-item arithmetic. Not production DB/concurrency/combat tests. */
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';

const dir=path.dirname(fileURLToPath(import.meta.url));
const input=path.resolve(process.argv[2]??path.join(dir,'season_model.json'));
const output=path.resolve(process.argv[3]??path.join(dir,'red_market_results_v2.json'));
const bytes=await fs.readFile(input), model=JSON.parse(bytes);
const day=86400000, week=7*day, offsetMinutes=480;
const floor=(v)=>Math.floor(v+1e-9);
const red={id:'red',damageBase:.32,damagePerLevel:.04,resistBase:.18,resistPerLevel:.01,
  speedBase:.12,speedPerLevel:.006,costs:[6,9,15,120,240],
  unique:{fireBonus:.15,rapidExtraSpeed:.04,rapidFloor:1.8,doubleDraw:.10,openingDraw:1,escapeBonus:.15}};
const checks=[];
function test(name,actual,expected){const passed=JSON.stringify(actual)===JSON.stringify(expected);checks.push({name,passed,actual,expected});return passed;}
const tidy=x=>Number(x.toFixed(12));

// This task proposes Asia/Shanghai, fixed UTC+8, with Monday 04:00 local reset.
// A logical economy realm shares this single epoch; process IDs/seasons are not quota keys.
function weekStartUtc(t){
  const shifted=new Date(t+offsetMinutes*60000-4*3600000);
  const dow=(shifted.getUTCDay()+6)%7;
  const dateMidnight=Date.UTC(shifted.getUTCFullYear(),shifted.getUTCMonth(),shifted.getUTCDate());
  return dateMidnight-dow*day+4*3600000-offsetMinutes*60000;
}
function localIso(t){return new Date(t+offsetMinutes*60000).toISOString().replace('Z','+08:00');}
function buckets(start,days){
  const end=start+days*day,rows=[];
  for(let w=weekStartUtc(start);w<end;w+=week){
    if(w+week>start)rows.push({weekStart:localIso(w),overlapDays:tidy((Math.min(end,w+week)-Math.max(start,w))/day)});
  }
  return rows;
}
const anchor=Date.parse('2026-11-02T04:00:00+08:00');
test('周一03:59:59属于旧周',localIso(weekStartUtc(anchor-1000)),'2026-10-26T04:00:00.000+08:00');
test('周一04:00属于新周',localIso(weekStartUtc(anchor)),'2026-11-02T04:00:00.000+08:00');
test('同周两赛季共用周键',weekStartUtc(anchor+2*day),weekStartUtc(anchor+5*day));
const seasonWindows=[30,42,60].map(days=>{
  const aligned=buckets(anchor,days),shifted=buckets(anchor+6*day,days);
  return {seasonDays:days,alignedWeekSlots:aligned.length,lateWeekStartSlots:shifted.length,
    alignedStart:localIso(anchor),alignedEndExclusive:localIso(anchor+days*day),
    maximumPlus5IfAllSlotsMintAndPool:Math.floor(aligned.length/3),
    partialSlotsShareQuotaWithAdjacentSeasons:true,alignedBuckets:aligned};
});
test('30/42/60天对齐周槽',[...seasonWindows.map(x=>x.alignedWeekSlots)],[5,6,9]);
test('接近周尾开始可触及更多周槽',seasonWindows.map(x=>x.lateWeekStartSlots),[6,7,10]);

function fillProbability(bossKills,boxes,eventGuaranteed=false){return eventGuaranteed?1:1-(1-.004)**bossKills*(1-.0008)**boxes;}
const hazardCases=[[0,0],[50,0],[100,0],[250,0],[500,0],[1000,0],[0,1250],[100,1250],[250,1250]].map(([bossKills,boxes])=>{
  const p=fillProbability(bossKills,boxes);
  return {bossKills,boxes,weeklyAtLeastOneMintProbability:p,expectedMintsInSixIndependentWeeks:6*p,
    note:'A server-wide aggregate; no individual guarantee; sources compete for the same one-item weekly cap'};
});
const guaranteedEvent={bossKills:100,boxes:0,eventIfUnusedAtWeekEnd:true,
  totalWeeklyMints:1,naturalWinProbability:fillProbability(100,0),
  eventWinProbability:1-fillProbability(100,0),newSupplyAboveWeeklyCap:0};

const choose=(n,k)=>{let v=1;for(let i=1;i<=k;i++)v=v*(n-i+1)/i;return v;};
function binomial(n,p){return Array.from({length:n+1},(_,k)=>({count:k,probability:choose(n,k)*p**k*(1-p)**(n-k)}));}
const availability=[
  {label:'每周必填且全部保住',mintChance:1,accountRecovery:1},
  {label:'每周必填、最终带出率70%',mintChance:1,accountRecovery:.7},
  {label:'250次Boss/周、最终带出率70%',mintChance:fillProbability(250,0),accountRecovery:.7},
  {label:'100次Boss/周、最终带出率70%',mintChance:fillProbability(100,0),accountRecovery:.7}
].map(x=>{
  const successful=x.mintChance*x.accountRecovery,distribution=binomial(6,successful);
  return {...x,slots:6,expectedAccountItems:6*successful,
    probabilityServerHasAtLeastThree:distribution.filter(r=>r.count>=3).reduce((s,r)=>s+r.probability,0),
    expectedMaximumPlus5AfterPerfectPooling:distribution.reduce((s,r)=>s+Math.floor(r.count/3)*r.probability,0),
    assumptions:'Independent weeks; no later losses; all recovered reds can be pooled and fragments ignored. An optimistic server capacity bound, not player completion time.'};
});
test('6枚红最多2件+5',Math.floor(6/3),2);
test('首次+5需要3枚本体和材料',1+1+1,3);
const targetSupply={baseSpecificSlotElementEffectProbability:1/75,
  chanceAnyOfSixMatches:1-(74/75)**6,
  expectedWeeksForOneSpecificSlotElementEffectWithOneMintPerWeek:75,
  note:'Original uniform 5 slots × 5 elements × 3 effects. Does not include unique trait or player competition.'};

function stockSeries({weeks=6,mintProbability=1,recovery=.7,weeklyExistingAttrition=0}){
  let stock=0;const rows=[];
  for(let i=1;i<=weeks;i++){
    const existingLoss=stock*weeklyExistingAttrition,arrivals=mintProbability*recovery;
    stock=stock-existingLoss+arrivals;
    rows.push({week:i,arrivals,existingLoss,endStock:stock});
  }return rows;
}
const stockScenarios=[0,.05,.10].map(attrition=>({weeklyExistingAttrition:attrition,rows:stockSeries({weeklyExistingAttrition:attrition})}));

const purple=model.equipment.find(x=>x.id==='purple'),orange=model.equipment.find(x=>x.id==='orange');
function stat(e,l,key){return e[`${key}Base`]+l*e[`${key}PerLevel`];}
function loadout(rare,l,unique=rare.id==='red'?'utility':'none'){
  const damage=stat(rare,l,'damage')+4*stat(purple,l,'damage')+(unique==='fire'?red.unique.fireBonus:0);
  const resistance=stat(rare,l,'resist')+4*stat(purple,l,'resist');
  const speed=stat(rare,l,'speed')+4*stat(purple,l,'speed')+(unique==='rapid'?red.unique.rapidExtraSpeed:0);
  const interval=Math.max(model.assumptions.drawFloor,4*(1-speed));
  const pierceCap=rare.id==='red'?.5:.45;
  const hand=[8,3,12].map(x=>x+l);
  const element=hand.reduce((s,x)=>s+floor(x*(1+damage)*1.4),0);
  const pierce=hand.reduce((s,x)=>s+floor(x*pierceCap),0);
  return {rare:rare.id,level:l,unique,damage:tidy(damage),resistanceRaw:tidy(resistance),resistanceEffective:Math.min(.6,tidy(resistance)),
    speedReduction:tidy(speed),interval:tidy(interval),pierceCap,elementalThreeCardDamage:element,pierceThreeCardDamage:pierce,
    threeCardTotal:element+pierce,notes:'Same-element five-piece armor, interval shoes, active full pierce set. Red utility means a mandatory unique trait without extra damage in this isolated hand, such as Escape on red shoes; it does not mean a traitless red. Fixed three cards only, not real DPS/TTK.'};
}
const combatComparisons=[0,3,5].flatMap(l=>[
  loadout(orange,l),loadout(red,l),loadout(red,l,'fire'),loadout(red,l,'rapid')]);
for(const row of combatComparisons){
  const base=combatComparisons.find(x=>x.level===row.level&&x.rare==='orange');
  row.fixedHandRatioToOrange=row.threeCardTotal/base.threeCardTotal;
  row.handTimesNaturalRateProxyToOrange=row.fixedHandRatioToOrange*base.interval/row.interval;
}
const max=loadout(red,5);
test('红+5新季总增伤',max.damage,1.62);
test('红+5新季原抗性',max.resistanceRaw,.71);
test('红+5新季自然间隔',max.interval,1.96);
test('疾抽不绕过1.8地板',loadout(red,5,'rapid').interval,1.8);
const oldRedLeak={oldRedSpeedAt5:.18+5*.025,fourNewPurpleSpeed:4*(.07+5*.004),
  oldNormalIntervalWithNewPurple:Math.max(1.8,4*(1-(.18+5*.025+4*(.07+5*.004)))),
  oldRapidIntervalWithNewPurple:Math.max(1.5,4*(1-(.18+5*.025+.25+4*(.07+5*.004)))),
  oldFireBonus:.35,newFireBonus:red.unique.fireBonus};
const costCases=[30,42,60].map(days=>{
  const denom=42,numerator=Math.min(days,42),scaleCosts=costs=>costs.map(x=>Math.ceil(x*numerator/denom));
  const rc=scaleCosts(red.costs),pc=scaleCosts(purple.costs),oc=scaleCosts(orange.costs),total=(a,n=5)=>a.slice(0,n).reduce((s,v)=>s+v,0);
  return {days,redSteps:rc,redPlus3:total(rc,3),redPlus5:total(rc),redPurpleFivePiecePlus3:total(rc,3)+4*total(pc,3),
    redPurpleFivePiecePlus5:total(rc)+4*total(pc),orangePurpleFivePiecePlus5:total(oc)+4*total(pc),
    redMaterialsRequiredForPlus4:1,additionalRedMaterialsRequiredForPlus5:1};
});
test('42天红强化费',[costCases[1].redPlus3,costCases[1].redPlus5],[30,390]);
const ledgerExample=[
 {event:'mint_week_1',minted:1,destroyed:0,live:1,quotaConsumedWeeks:1},
 {event:'death_to_relic_same_item_id',minted:1,destroyed:0,live:1,quotaConsumedWeeks:1},
 {event:'other_player_extracts_same_item_id',minted:1,destroyed:0,live:1,quotaConsumedWeeks:1},
 {event:'diamond_auction_same_item_id',minted:1,destroyed:0,live:1,quotaConsumedWeeks:1},
 {event:'mint_week_2',minted:2,destroyed:0,live:2,quotaConsumedWeeks:2},
 {event:'consume_one_red_for_plus4',minted:2,destroyed:1,live:1,quotaConsumedWeeks:2},
 {event:'mint_week_3',minted:3,destroyed:1,live:2,quotaConsumedWeeks:3},
 {event:'consume_one_red_for_plus5',minted:3,destroyed:2,live:1,quotaConsumedWeeks:3},
 {event:'unrecovered_terminal_loss',minted:3,destroyed:3,live:0,quotaConsumedWeeks:3}
];
for(const r of ledgerExample)test(`存量守恒 ${r.event}`,r.minted-r.destroyed,r.live);
const auctionExamples=[{currency:'gold',price:99999},{currency:'diamond',price:8000}].map(x=>({...x,fee:Math.max(1,Math.floor(x.price*.1)),sellerNet:x.price-Math.max(1,Math.floor(x.price*.1)),newRedItems:0,newCurrency:0}));
const result={meta:{purpose:'Red weekly quota, stock and candidate attributes arithmetic',modelVersion:model.meta.version,modelSha256:createHash('sha256').update(bytes).digest('hex'),
  source:'GDD v0.69 §3.4/4.5/4.7/6.4/6.5/6.8; SERVER_IMPLEMENTATION_STATUS_AND_PLAN §1 V015',
  overrides:'New user authorization opens red drops and currencies; old prototype disabled flags are historical, not this proposal.',
  productionCodeTested:false,databaseConcurrencyTested:false,fullCombatSimulation:false,networkAccess:false,
  scope:'No changes to the existing report/model/workbook; candidate red parameters are local to this independent script.'},
  candidateRed:red,seasonWindows,hazardCases,guaranteedEvent,availability,targetSupply,stockScenarios,combatComparisons,oldRedLeak,costCases,ledgerExample,auctionExamples,
  checks,summary:{total:checks.length,passed:checks.filter(x=>x.passed).length,failed:checks.filter(x=>!x.passed).length}};
await fs.writeFile(output,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({output,summary:result.summary,seasonWindows:seasonWindows.map(({alignedBuckets,...x})=>x),hazardCases,availability,
  combatComparisons:combatComparisons.filter(x=>x.level===5),costCases,targetSupply},null,2));
if(result.summary.failed)process.exitCode=1;
