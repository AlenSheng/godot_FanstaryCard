#!/usr/bin/env node
/**
 * Document arithmetic reference, not the production C# Resolver or a fight simulator.
 * Run: node verify_combat_math.mjs [season_model.json] [combat_math_checks.json]
 * Uses Node built-ins only. Fractions remain exact through every documented floor.
 * Combat scheduling, real hand/deck legality, RNG, class actions, replay, networking,
 * 500 ms action gates and sustained card-return behavior are NOT executed here.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const dir = path.dirname(fileURLToPath(import.meta.url));
const inputPath = path.resolve(process.argv[2] ?? path.join(dir, 'season_model.json'));
const outputPath = path.resolve(process.argv[3] ?? path.join(dir, 'combat_math_checks.json'));
const inputBytes = await fs.readFile(inputPath);
const model = JSON.parse(inputBytes.toString('utf8'));

const gcd = (a, b) => { a = a < 0n ? -a : a; while (b) [a, b] = [b, a % b]; return a; };
class Fraction {
  constructor(n, d = 1n) {
    if (d === 0n) throw new Error('Zero denominator');
    if (d < 0n) { n = -n; d = -d; }
    const g = gcd(n, d); this.n = n / g; this.d = d / g;
  }
  add(v) { const x = q(v); return new Fraction(this.n*x.d+x.n*this.d, this.d*x.d); }
  sub(v) { const x = q(v); return new Fraction(this.n*x.d-x.n*this.d, this.d*x.d); }
  mul(v) { const x = q(v); return new Fraction(this.n*x.n, this.d*x.d); }
  div(v) { const x = q(v); return new Fraction(this.n*x.d, this.d*x.n); }
  compare(v) { const x = q(v), t = this.n*x.d-x.n*this.d; return t < 0n ? -1 : t > 0n ? 1 : 0; }
  floor() { return Number(this.n >= 0n ? this.n/this.d : -((-this.n+this.d-1n)/this.d)); }
  value() { return Number(this.n)/Number(this.d); }
}
function q(v) {
  if (v instanceof Fraction) return v;
  if (typeof v === 'bigint') return new Fraction(v);
  if (typeof v === 'number' && !Number.isFinite(v)) throw new Error('Non-finite decimal');
  let text = String(v);
  if(text.startsWith('.'))text='0'+text;
  if(text.startsWith('-.'))text='-0'+text.slice(1);
  const m = text.match(/^(-?)(\d+)(?:\.(\d+))?(?:e([+-]?\d+))?$/i);
  if (!m) throw new Error(`Invalid decimal: ${text}`);
  const decimals = m[3] ?? '', exponent = Number(m[4] ?? 0) - decimals.length;
  let n = BigInt(m[2] + decimals) * (m[1] ? -1n : 1n), d = 1n;
  if (exponent >= 0) n *= 10n**BigInt(exponent); else d = 10n**BigInt(-exponent);
  return new Fraction(n, d);
}
const qmax = (a, b) => q(a).compare(b) >= 0 ? q(a) : q(b);
const qmin = (a, b) => q(a).compare(b) <= 0 ? q(a) : q(b);
const sum = values => values.reduce((s, v) => s.add(v), q(0));
const failures = [], checks = [];
function check(name, actual, expected, category = 'arithmetic') {
  const passed = JSON.stringify(actual) === JSON.stringify(expected);
  const record = { name, passed, actual, expected };
  checks.push({ category, ...record });
  if (!passed) failures.push({ category, ...record });
  return passed;
}
function checkReject(name, fn) {
  let rejected = false; try { fn(); } catch { rejected = true; }
  return check(name, rejected, true, 'legality');
}

const conflictPairs = new Set(['wood|earth','earth|water','water|fire','fire|metal','metal|wood']);
const conflicts = (a, b) => conflictPairs.has(`${a}|${b}`) || conflictPairs.has(`${b}|${a}`);
const card = (element, damage, extra = {}) => ({ element, damage, ...extra });
const fire = (damage, extra) => card('fire', damage, extra);
const water = (damage, extra) => card('water', damage, extra);
const neutral = extra => ({ element: null, damage: 0, ...extra });

function resolveDocumentCombo(cards, options = {}) {
  const attack = options.attack ?? {}, resist = options.resist ?? {};
  const prepared = cards.map((c, i) => ({ id: c.id ?? String(i), damage: 0,
    secondDamage: 0, direct: 0, fuel: 0, tune: false, ...c }));
  const candidates = prepared.filter(c => c.damage > 0 && c.element && c.secondDamage === 0);
  const core = candidates[0]?.element ?? null;
  const R = core ? candidates.filter(c => c.element === core).length : 0;
  const P = core ? candidates.filter(c => c.element !== core && conflicts(core,c.element) && !c.tune).length : 0;
  const B = cards.some(c => (c.resonanceBonus ?? 0) > 0) ? 1 : 0;
  const M = Math.max(0, R-1+B-P), K = q(1).add(q('.2').mul(M));
  const scaleFor = element => q(1).add(attack[element] ?? 0).mul(q(1).sub(resist[element] ?? 0));
  const S = core ? scaleFor(core) : null;
  const cancellation = Math.max(0, ...cards.map(c => c.cancellationBonus ?? 0));
  const D = P === 0 ? q(0) : qmin('.8',q('.2').mul(P).add(cancellation));
  const candidateIds = new Set(candidates.map(c => c.id));
  for (const c of prepared) {
    c.base = c.damage;
    if (candidateIds.has(c.id)) {
      const count = candidates.filter(x => x.element === c.element).length;
      c.base += c.fuel * Math.max(0, count-3);
    }
    c.secondBase = c.secondDamage;
    if (options.displayElement && c.element === options.displayElement) c.base = q(c.base).mul('1.3').floor();
    if (options.displayElement && c.secondElement === options.displayElement) c.secondBase = q(c.secondBase).mul('1.3').floor();
  }
  const elementalParts = [], directParts = [], pierceParts = [];
  for (const c of prepared) {
    if (candidateIds.has(c.id)) {
      const branch = c.element === core ? K : conflicts(core,c.element) && !c.tune ? q(1).sub(D) : q(1);
      elementalParts.push({ id:c.id, element:c.element, damage:Math.max(0,q(c.base).mul(S).mul(branch).floor()) });
    } else if (c.secondDamage > 0) {
      elementalParts.push({ id:c.id, element:c.element, damage:Math.max(0,q(c.base).mul(S ?? scaleFor(c.element)).floor()) });
      elementalParts.push({ id:c.id, element:c.secondElement, damage:Math.max(0,q(c.secondBase).mul(S ?? scaleFor(c.secondElement)).floor()) });
    }
    directParts.push(c.direct);
    pierceParts.push(q(c.base+c.secondBase+c.direct).mul(options.pierce ?? 0).floor());
  }
  const E0 = sum(prepared.filter(c => candidateIds.has(c.id) && c.element === core && !c.tune).map(c => c.base)).mul(S ?? 0).mul(K);
  const recoveryCoefficient = Math.max(.5,...cards.map(c => c.conflictRecovery ?? 0));
  const Hraw = P > 0 ? E0.mul(D).mul(recoveryCoefficient).floor()+2*P : 0;
  const recovery = q(Hraw).mul(q(1).add(options.vitalityRecovery ?? 0)).floor();
  const damage = elementalParts.reduce((s,p) => s+p.damage,0)+directParts.reduce((a,b)=>a+b,0)+pierceParts.reduce((a,b)=>a+b,0);
  return { core,R,P,B,M,K:K.value(),S:S?.value()??null,D:D.value(),
    elementalParts,directParts,pierceParts,damage,recovery };
}

const common = { attack:{fire:.14}, resist:{fire:-.30} };
const dual = () => card('fire',8,{secondElement:'metal',secondDamage:8});
const goldenVectors = [
  ['A', [fire(8),fire(3),fire(12,{fuel:2})],common,{damage:46,core:'fire',R:3,P:0}],
  ['A-F4',[fire(8),fire(3),fire(6),fire(12,{fuel:2})],common,{damage:72,R:4}],
  ['A-F5',[fire(8),fire(3),fire(6),fire(10),fire(12,{fuel:2})],common,{damage:113,R:5}],
  ['逐张取整',[fire(3),fire(3),fire(3)],{attack:{fire:.14}},{damage:12}],
  ['少数定核',[fire(8),water(7),water(7)],common,{damage:23,core:'fire',R:1,P:2}],
  ['顺序1',[fire(8),water(7)],{attack:{fire:.14},resist:{fire:-.30,water:.50}},{damage:19,core:'fire'}],
  ['顺序2',[water(7),fire(8)],{attack:{fire:.14},resist:{fire:-.30,water:.50}},{damage:6,core:'water'}],
  ['调节定核',[fire(4,{tune:true}),fire(8)],{},{damage:13,core:'fire',R:2}],
  ['非核调节',[fire(8),water(5,{tune:true})],{},{damage:13,P:0}],
  ['调节回复基数',[fire(8),fire(4,{tune:true}),water(7)],{},{damage:17,recovery:2}],
  ['第三元素',[fire(8),card('wood',7)],common,{damage:21,P:0}],
  ['两张共振加一',[fire(10),fire(10),neutral({resonanceBonus:1}),neutral({resonanceBonus:1})],{},{damage:28,B:1}],
  ['无核双元素',[dual()],{attack:{fire:.14},resist:{fire:-.30,metal:.60}},{damage:14,core:null,R:0,P:0}],
  ['有核双元素',[water(7),dual()],{attack:{fire:.14,water:.20},resist:{fire:-.30,metal:.60,water:.50}},{damage:12,core:'water',R:1,P:0}]
].map(([name,cards,options,expected]) => {
  const result=resolveDocumentCombo(cards,options);
  const actual=Object.fromEntries(Object.keys(expected).map(k=>[k,result[k]]));
  const passed=check(name,actual,expected,'golden-v0.70');
  return {name,passed,expected,result};
});
check('14个主卷黄金向量',goldenVectors.length,14,'golden-v0.70');
check('一次汇总取整确会误得14',q(9).mul('1.14').mul('1.4').floor(),14,'rounding');
check('直伤不吃主核S或共振',resolveDocumentCombo([fire(8),neutral({direct:7})],{attack:{fire:1},resist:{fire:.5}}).damage,15,'rounding');
check('破击逐牌取整',resolveDocumentCombo([fire(8),fire(3),fire(12)],{pierce:.24}).pierceParts,[1,0,2],'rounding');

function monsterDamage({raw=0,kind='element',elementBoost=0,resist=0,damageReduction=0,
  damageScale=1,charge=false,empower=0,cancelled=false,targetExists=true,pveMinimumOne=true}) {
  if (cancelled || !targetExists || !['element','direct'].includes(kind) || raw<=0) return {intentValue:0,scaledIntent:0,afterElement:0,afterReduction:0,damage:0};
  const intentValue=(charge?q(raw).mul('1.5').floor():raw)+empower;
  const scaledIntent=q(intentValue).mul(damageScale).floor();
  const afterElement=kind==='element' ? q(scaledIntent).mul(q(1).add(elementBoost)).mul(q(1).sub(resist)).floor() : scaledIntent;
  const afterReduction=q(afterElement).mul(q(1).sub(damageReduction)).floor();
  const damage=pveMinimumOne && scaledIntent>0 ? Math.max(1,afterReduction):afterReduction;
  return {intentValue,scaledIntent,afterElement,afterReduction,damage};
}
const boss=model.monsterGroups.find(g=>g.id==='B1').members[0];
const boss2=model.monsterGroups.find(g=>g.id==='B2').members[0];
const bat=model.monsterGroups.find(g=>g.id==='O1').members[0];
const guard=model.monsterGroups.find(g=>g.id==='E1').members[0];
check('Boss二期仍为同一实体生命基数',boss2.hp,boss.hp,'season-difficulty');
check('本次六档参数数量',model.difficulties.length,6,'season-difficulty');
const expectedDifficultyRows=[
  [78,200,280,140,2,3,8,9],[124,320,448,224,2,3,10,11],
  [202,520,728,364,3,4,12,13],[312,800,1120,560,3,5,14,16],
  [452,1160,1624,812,4,6,17,19],[624,1600,2240,1120,5,7,20,23]
];
const difficultyRows=model.difficulties.map((d,i)=>{
  const hp=q(boss.hp).mul(d.hpScale).floor();
  const phaseThreshold=q(hp).mul(model.validations.bossPhaseRatio).floor();
  const r={id:d.id,batHp:q(bat.hp).mul(d.hpScale).floor(),guardHp:q(guard.hp).mul(d.hpScale).floor(),
    bossHp:hp,bossInitialShield:q(boss.shield).mul(d.shieldScale).floor(),
    bossPhaseThreshold:phaseThreshold,guardRepeatedShield:q(12).mul(d.shieldScale).floor(),
    bossPhase1IntervalMs:q(boss.interval).mul(1000).mul(d.intervalScale).floor(),
    bossPhase2IntervalMs:q(boss2.interval).mul(1000).mul(d.intervalScale).floor(),
    smallIntent2:q(2).mul(d.damageScale).floor(),smallIntent3:q(3).mul(d.damageScale).floor(),
    bossDirect8:monsterDamage({raw:8,kind:'direct',damageScale:d.damageScale}).damage,
    chargedElite6:monsterDamage({raw:6,charge:true,damageScale:d.damageScale}).scaledIntent,
    empoweredElite4:monsterDamage({raw:4,empower:2,damageScale:d.damageScale}).scaledIntent,
    tankVsSmall3:monsterDamage({raw:3,elementBoost:.1,resist:.6,damageReduction:.4,damageScale:d.damageScale}),
    tankVsElite4:monsterDamage({raw:4,elementBoost:.15,resist:.6,damageReduction:.4,damageScale:d.damageScale}),
    tankVsBoss5:monsterDamage({raw:5,elementBoost:.2,resist:.6,damageReduction:.4,damageScale:d.damageScale})};
  check(`${d.id}六档独立预期`,[r.batHp,r.guardHp,r.bossHp,r.bossPhaseThreshold,r.smallIntent2,r.smallIntent3,r.bossDirect8,r.chargedElite6],expectedDifficultyRows[i],'season-difficulty');
  check(`${d.id}半血边界触发`,2*phaseThreshold<=hp,true,'phase-boundary');
  check(`${d.id}半血上一点不触发`,2*(phaseThreshold+1)<=hp,false,'phase-boundary');
  return r;
});
check('奇数Boss生命半血不向上取整',q(465).mul('.5').floor(),232,'phase-boundary');
check('奇数生命232触发且233不触发',[2*232<=465,2*233<=465],[true,false],'phase-boundary');
const minimumDamageCases=[
 ['元素伤减免后0变1',{raw:2,elementBoost:.1,resist:.6},1],
 ['盾减伤后0变1',{raw:3,elementBoost:.1,resist:.6,damageReduction:.4},1],
 ['关闭新PVE规则保持0',{raw:3,elementBoost:.1,resist:.6,damageReduction:.4,pveMinimumOne:false},0],
 ['直伤不吃元素抗性',{raw:8,kind:'direct',resist:.6,elementBoost:.2},8],
 ['原始0不产生保底伤害',{raw:0},0],
 ['上盾事件不打1',{raw:12,kind:'shield'},0],
 ['蓄力事件不打1',{raw:6,kind:'charge'},0],
 ['强化事件不打1',{raw:2,kind:'empower'},0],
 ['被取消不打1',{raw:6,cancelled:true},0],
 ['没有目标不打1',{raw:6,targetExists:false},0]
].map(([name,input,expected])=>({name,...monsterDamage(input),passed:check(name,monsterDamage(input).damage,expected,'minimum-damage')}));
check('先蓄力再倍率D1结果',monsterDamage({raw:6,charge:true,damageScale:1.25}).scaledIntent,11,'intent-order');
check('先倍率再蓄力会不同',q(q(6).mul('1.25').floor()).mul('1.5').floor(),10,'intent-order');
check('强化整体随D5缩放',monsterDamage({raw:4,empower:2,damageScale:2.6}).scaledIntent,15,'intent-order');

const qualities=new Map(model.equipment.map(e=>[e.id,e]));
const slots=['head','hands','chest','legs','feet'];
function validateGear(items) {
  if(items.length>model.validations.slotCount)throw new Error('Too many armor slots');
  if(new Set(items.map(x=>x.slot)).size!==items.length)throw new Error('Duplicate armor slot');
  if(items.filter(x=>x.quality==='orange'||x.quality==='red').length>model.validations.orangeWearCap)throw new Error('Orange/red wear cap');
  for(const it of items){
    if(!qualities.has(it.quality))throw new Error('Unavailable seasonal quality');
    if(!slots.includes(it.slot))throw new Error('Unknown armor slot');
    if(!Number.isInteger(it.level)||it.level<0||it.level>model.validations.equipmentMaxLevel)throw new Error('Illegal equipment level');
    if(it.effect&&!['purple','orange'].includes(it.quality))throw new Error('Affix on low quality');
    if(it.effect&&!['pierce','bulwark','vitality'].includes(it.effect))throw new Error('Unknown effect');
  }
}
const effectBase={purple:{pierce:6,reduction:3,shield:6,heal:6,over:4,increment:'.5'},orange:{pierce:14,reduction:7,shield:14,heal:14,over:10,increment:1}};
function effectSet(items,effect) {
  const selected=items.filter(x=>x.effect===effect), n=selected.length;
  const hasOrange=selected.some(x=>x.quality==='orange');
  const active=n>=(hasOrange?2:3), multiplier=active?({2:'1.35',3:'1.35',4:'1.55',5:'1.8'}[n]):0;
  const caps={pierce:hasOrange?45:40,reduction:hasOrange?40:35,shield:hasOrange?45:40,heal:50,over:40};
  const keys=effect==='pierce'?['pierce']:effect==='bulwark'?['reduction','shield']:['heal','over'];
  const output={count:n,active,hasOrange,multiplier:Number(multiplier),rawPercent:{},percent:{}};
  for(const key of keys){const raw=active?sum(selected.map(x=>q(effectBase[x.quality][key]).add(q(effectBase[x.quality].increment).mul(x.level)))).mul(multiplier).floor():0;
    output.rawPercent[key]=raw;output.percent[key]=Math.min(caps[key],raw);}
  return output;
}
function gearStats(items){
  validateGear(items);
  const addStat=(base,level)=>sum(items.map(x=>q(qualities.get(x.quality)[base]).add(q(qualities.get(x.quality)[level]).mul(x.level))));
  const attack=addStat('damageBase','damagePerLevel'),resistance=addStat('resistBase','resistPerLevel');
  const speed=sum(items.filter(x=>x.intervalAffix!==false).map(x=>q(qualities.get(x.quality).speedBase).add(q(qualities.get(x.quality).speedPerLevel).mul(x.level))));
  return {slots:items.length,orangeCount:items.filter(x=>x.quality==='orange').length,
    elementDamageBonus:attack.value(),rawResistance:resistance.value(),effectiveResistance:qmin(resistance,model.assumptions.resistCap).value(),
    intervalReduction:speed.value(),intervalSeconds:qmax(model.assumptions.drawFloor,q(model.assumptions.baseDrawInterval).mul(q(1).sub(speed))).value(),
    effects:{pierce:effectSet(items,'pierce'),bulwark:effectSet(items,'bulwark'),vitality:effectSet(items,'vitality')}};
}
const recipe={P0:{},P1:{},P2:{},P3:{purple:3},P4:{orange:1,purple:2},P5:{orange:1,purple:3}};
const modelBuilds=model.builds.map(b=>{
  const remaining={...recipe[b.id]},items=[];
  for(const g of b.gear)for(let i=0;i<g.count;i++){
    const effect=(remaining[g.quality]??0)>0?'pierce':null;
    if(effect)remaining[g.quality]--;
    items.push({slot:slots[items.length],quality:g.quality,level:g.level,intervalAffix:true,effect});
  }
  const stats=gearStats(items);
  const hand=model.assumptions.referenceCardValues.map(v=>fire(v+b.cardLevel));
  const base=resolveDocumentCombo(hand,{attack:{fire:stats.elementDamageBonus}});
  const withSet=resolveDocumentCombo(hand,{attack:{fire:stats.elementDamageBonus},pierce:q(stats.effects.pierce.percent.pierce).div(100).value()});
  return {id:b.id,name:b.name,fullDeckValidated:false,items,stats,threeCardDamageWithoutSet:base.damage,threeCardDamageWithSet:withSet.damage};
});
const expectedBuildStats={P0:[0,0,4,31,0],P1:[.43,.24,3.24,52,0],P2:[.65,.325,2.93,66,0],P3:[1,.51,2.44,88,28],P4:[1.21,.586,2.228,107,43],P5:[1.47,.65,2.06,129,45]};
for(const b of modelBuilds)check(`${b.id}属性/三卡/套装基线`,[b.stats.elementDamageBonus,b.stats.rawResistance,b.stats.intervalSeconds,b.threeCardDamageWithoutSet,b.stats.effects.pierce.percent.pierce],expectedBuildStats[b.id],'builds');
function loadout(qualitiesList,level,effects){return qualitiesList.map((quality,i)=>({slot:slots[i],quality,level,intervalAffix:true,effect:effects[i]??null}));}
const OP=['orange','purple','purple','purple','purple'];
const setExamples=[
 ['3紫+0破击',loadout(['purple','purple','purple'],0,['pierce','pierce','pierce']),{pierce:24}],
 ['2紫不激活',loadout(['purple','purple'],5,['pierce','pierce']),{pierce:0}],
 ['1橙单件不激活',loadout(['orange'],5,['pierce']),{pierce:0}],
 ['终局全破击',loadout(OP,5,Array(5).fill('pierce')),{pierce:45}],
 ['2破击3生息',loadout(OP,5,['pierce','pierce','vitality','vitality','vitality']),{pierce:37,heal:34,over:26}],
 ['终局全载壁',loadout(OP,5,Array(5).fill('bulwark')),{reduction:40,shield:45}],
 ['2载壁3生息',loadout(OP,5,['bulwark','bulwark','vitality','vitality','vitality']),{reduction:23,shield:37,heal:34,over:26}]
].map(([name,items,expected])=>{
  const stats=gearStats(items),merged={...stats.effects.pierce.percent,...stats.effects.bulwark.percent,...stats.effects.vitality.percent};
  const actual=Object.fromEntries(Object.keys(expected).map(k=>[k,merged[k]]));
  return {name,items,stats,passed:check(name,actual,expected,'effect-sets')};
});
check('2+3生息法生命上限',q(70).mul('1.26').floor(),88,'effect-sets');
check('2+3生息盾生命上限',q(100).mul('1.26').floor(),126,'effect-sets');
check('生息不抬盾上限',Math.floor(100/2),50,'effect-sets');
checkReject('拒绝6件防具',()=>gearStats(loadout(Array(6).fill('purple'),0,[])));
checkReject('拒绝2件橙',()=>gearStats(loadout(['orange','orange'],0,[])));
checkReject('拒绝低品质效果词缀',()=>gearStats(loadout(['white'],0,['pierce'])));
checkReject('拒绝装备+6',()=>gearStats(loadout(['purple'],6,[])));
checkReject('常规五色计算器拒绝未定义的红参数；红装使用单独预算表',()=>gearStats(loadout(['red'],0,[])));
checkReject('拒绝重复部位',()=>gearStats([{slot:'head',quality:'purple',level:0},{slot:'head',quality:'purple',level:0}]));
const exactBoundaries=[['floor(100×.29)',q(100).mul('.29').floor(),29],['floor(100×1.15)',q(100).mul('1.15').floor(),115]];
for(const [name,actual,expected] of exactBoundaries)check(name,actual,expected,'exact-decimals');

const counts={};for(const c of checks){counts[c.category]??={total:0,passed:0};counts[c.category].total++;counts[c.category].passed+=Number(c.passed);}
const result={
  meta:{purpose:'文档算术参考实现与候选参数校验',source:'GDD v0.70 §3.1–3.6; v0.69 §3.4、§4.7、§5.13',
    modelVersion:model.meta.version,modelSha256:createHash('sha256').update(inputBytes).digest('hex'),
    modelFile:path.basename(inputPath),arithmetic:'Exact BigInt rational arithmetic before each specified floor',
    productionResolverTested:false,fullCombatSimulation:false,networkOrSchedulerTested:false,
    cardReturnBehavior:'待真实领域与完整牌组验收，未在此执行或判定通过',
    limitations:['黄金向量含合成分支测试输入，不是合法完整20卡组或胜率证明。','构筑只校验五部位/橙唯一/等级/效果套数学合法性，不验证真实获取时间或账号资产。','Boss二期是同一实体，表内只给阶段参数，不重复计算另一条生命。','新增最低1与意图倍率顺序是候选新赛季规则，不是当前生产行为。']},
  referenceRules:{core:'first qualifying single-element card',rounding:'per card/segment floor',
    seasonalIntentOrder:'existing charge/empower → floor difficulty scaling → floor element boost and resistance → floor shield-class damage reduction → PVE positive-hit minimum 1',
    minimumOneScope:'uncancelled positive damage events with a valid target only; excludes PVP/legacy/zero/shield/charge/empower events',
    effectParametersSource:'Inherited GDD v0.69 §3.4.1 and §4.7; not all fields are serialized in season_model.json',
    noActionGateClaim:'500 ms gate is a design requirement only; no runtime action/scheduler test performed'},
  summary:{passed:failures.length===0,totalChecks:checks.length,failedChecks:failures.length,byCategory:counts},
  goldenVectors,difficultyRows,minimumDamageCases,modelBuilds,setExamples,failures
};
await fs.mkdir(path.dirname(outputPath),{recursive:true});
await fs.writeFile(outputPath,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({output:outputPath,...result.summary,failures},null,2));
if(failures.length)process.exitCode=1;
