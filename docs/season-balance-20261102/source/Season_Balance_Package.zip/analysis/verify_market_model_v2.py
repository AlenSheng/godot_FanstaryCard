"""Independent arithmetic and parameter-wiring audit of the unified market model.

This is an analytical ledger check, not a combat, demand, or price simulation.
It reads the published JSON and independently recomputes its quantities.  A
separate source-wiring check executes only the builder's read-only arithmetic
prefix, with selected inputs changed, and compares it against the independent
oracle. It never runs the builder's output-writing section or changes its files.
"""
from __future__ import annotations

import ast
import copy
import hashlib
import itertools
import json
import math
from decimal import Decimal, ROUND_FLOOR
from pathlib import Path

HERE = Path(__file__).resolve().parent
BUILDER = HERE / "build_market_model_v2.py"
BASE_BYTES = (HERE / "season_model.json").read_bytes()
MODEL_BYTES = (HERE / "market_model_v2.json").read_bytes()
B = json.loads(BASE_BYTES)
M = json.loads(MODEL_BYTES)
A, E, R, K = (M[k] for k in ("assumptions", "events", "red", "market"))
RESULT = M["results"]
CHECKS = []


def dec(x):
    return Decimal(str(x))


def floor_decimal(x):
    return int(x.to_integral_value(rounding=ROUND_FLOOR))


def close(actual, expected):
    return math.isclose(float(actual), float(expected), rel_tol=1e-10, abs_tol=1e-8)


def check(name, actual, expected=True):
    ok = close(actual, expected) if isinstance(actual, (float, int, Decimal)) and isinstance(expected, (float, int, Decimal)) else actual == expected
    CHECKS.append({"name": name, "passed": bool(ok), "actual": actual, "expected": expected})


def tax(price, rate, minimum=1):
    return max(minimum, floor_decimal(dec(price) * dec(rate)))


def oracle(a, event, market):
    d = B["difficulties"][a["difficultyIndex"]]
    counts = B["route"]["counts"]
    distributions = {(x["difficultyId"], x["layerId"]): x["weights"] for x in B["loot"]}
    income = {"gold": 0, "fragments": Decimal(0), "doubleFragments": Decimal(0)}
    candidates = [Decimal(0)] * 5
    components = []
    for count, layer in zip(counts, B["layers"]):
        outcomes = list(range(layer["fragmentMin"], layer["fragmentMax"] + 1))
        normal = [floor_decimal(dec(v) * dec(d["fragmentScale"])) for v in outcomes]
        doubled = [floor_decimal(dec(v) * dec(d["fragmentScale"]) * 2) for v in outcomes]
        income["gold"] += count * floor_decimal(dec(layer["gold"]) * dec(d["goldScale"]))
        income["fragments"] += count * dec(sum(normal)) / len(normal)
        income["doubleFragments"] += count * dec(sum(doubled)) / len(doubled)
        components.append({"layer": layer["id"], "count": count, "normalOutcomes": normal, "doubleOutcomes": doubled})
        for idx, weight in enumerate(distributions[(d["id"], layer["id"])]):
            candidates[idx] += count * dec(weight)
    p, q, n = map(dec, (a["extractionRate"], a["gearChoiceRate"], a["attemptsPerDay"]))
    days = dec(1000) / n
    fresh = {quality: dec(1000) * candidates[idx] * p * q for idx, quality in enumerate(("white", "green", "blue", "purple", "orange"))}
    bias = dec(a["doubleFragmentBiasRate"])
    extra = p * dec(a["fragmentChoiceRate"]) * ((1 - bias) * income["fragments"] + bias * income["doubleFragments"])
    frag_offer = next(x for x in event["branches"] if x["id"] == "fragment")
    complete = dec(event["participationRate"]) * dec(event["completionFraction"])
    coverage = complete * dec(event["redemptionRate"])
    frag_cap = (event["tokensPerEvent"] // frag_offer["tokenCost"]) * frag_offer["rewardCount"]
    event_frag_season = dec(event["count"]) * frag_cap * coverage
    event_frag_day = event_frag_season / dec(a["seasonDays"])
    shops = {x["id"]: x for x in M["shops"]}
    packs = {"fragment": a["fragmentPacksPerDay"], "warrior": a["warriorPacksPerDay"], "class": a["classPacksPerDay"], "card": a["cardPacksPerDay"]}
    shop_gold = days * sum(dec(packs[key]) * shops[key]["priceGold"] for key in packs)
    shop_frag_day = dec(a["fragmentPacksPerDay"]) * shops["fragment"]["units"]
    event_factor = days / dec(a["seasonDays"]) * event["count"] * complete
    event_gold = event_factor * event["directGoldPerCompletedEvent"]
    event_diamond = event_factor * event["directDiamondsPerCompletedEvent"]
    potion_gold = dec(1000) * dec(a["potionsPerAttempt"]) * shops["potion"]["priceGold"]
    refresh_gold = dec(1000) * sum(dec(a[key]) * price for key, price in (("refreshFirstRate", 60), ("refreshSecondRate", 180), ("refreshThirdRate", 450)))
    bag_gold = dec(1000) * (1 - p) * (dec(a["advancedBagUseRate"]) * 800 + dec(a["topBagUseRate"]) * 2200)
    gold_tax = dec(a["goldTradesPer1000Attempts"]) * tax(a["goldTradePrice"], market["taxRateGold"], market["minFee"])
    dia_tax = dec(a["diamondTradesPer1000Attempts"]) * tax(a["diamondTradePrice"], market["taxRateDiamond"], market["minFee"])
    currency = {
        "goldCreated": dec(1000) * p * income["gold"] + event_gold,
        "eventGoldCreated": event_gold, "eventDiamondCreated": event_diamond,
        "goldShopSink": shop_gold, "goldPotionSink": potion_gold,
        "goldRefreshSink": refresh_gold, "goldBagReplacementSink": bag_gold, "goldTaxSink": gold_tax,
        "diamondTurnover": a["diamondTradesPer1000Attempts"] * a["diamondTradePrice"], "diamondTaxSink": dia_tax,
        "diamondNet": dec(a["diamondSystemGrantPer1000Attempts"]) + dec(a["diamondTopupsPer1000Attempts"]) + event_diamond - dia_tax - dec(a["diamondCosmeticsSinkPer1000Attempts"]),
    }
    currency["goldNet"] = currency["goldCreated"] - shop_gold - potion_gold - refresh_gold - bag_gold - gold_tax
    currency["goldNetPerActiveDay"] = currency["goldNet"] / days
    quality_cfg = {x["id"]: x for x in B["equipment"]}
    upgrade_frag = sum(dec(a[f"upgrade{quality.title()}From3To5Per1000Attempts"]) * sum(quality_cfg[quality]["costs"][3:]) for quality in ("purple", "orange"))
    fragment = {"base": dec(1000) * p * income["fragments"], "choice": dec(1000) * extra, "shop": days * shop_frag_day,
                "event": days * event_frag_day, "rebuild": dec(1000) * (1 - p) * a["rebuildFragmentCost"], "optionalUpgradeSpend": upgrade_frag}
    fragment["netBeforeOptionalUpgrade"] = sum(fragment[k] for k in ("base", "choice", "shop", "event")) - fragment["rebuild"]
    fragment["netAfterOptionalUpgrade"] = fragment["netBeforeOptionalUpgrade"] - upgrade_frag
    materials = {}
    for quality, worn in (("purple", 4), ("orange", 1)):
        upgrades = dec(a[f"upgrade{quality.title()}From3To5Per1000Attempts"])
        gift = event_factor * event[f"direct{quality.title()}BodiesPerCompletedEvent"]
        materials[f"{quality}ForOptionalUpgrades"] = 2 * upgrades
        materials[f"event{quality.title()}Bodies"] = gift
        materials[f"{quality}NetAfterOptionalUpgrades"] = fresh[quality] + gift - dec(1000) * (1 - p) * worn * (1 - dec(a["deadGearRecoveredRate"])) - 2 * upgrades
    return {"income": income, "components": components, "fresh": fresh, "choicePerAttempt": extra,
            "eventCap": frag_cap, "eventCoverage": coverage, "eventFragmentsSeason": event_frag_season,
            "eventFragmentsDay": event_frag_day, "currencies": currency, "fragments": fragment,
            "materials": materials, "playerDays": days}


O = oracle(A, E, K)
check("base source hash", M["meta"]["baseModelSha256"], hashlib.sha256(BASE_BYTES).hexdigest())
check("mutually exclusive node choice", sum(dec(A[k]) for k in ("gearChoiceRate", "fragmentChoiceRate", "healChoiceRate")), 1)
check("strict completed runs per day", A["attemptsPerDay"], A["dailyMinutes"] // A["minutesPerAttempt"])
for output, key in (("successGold", "gold"), ("successBaseFragments", "fragments"), ("successDoubleChoiceFragments", "doubleFragments")):
    check(f"successful route/{key}", RESULT["sources"][output], O["income"][key])
check("extra fragment choice", RESULT["sources"]["additionalChoiceFragmentsPerAttempt"], O["choicePerAttempt"])
for quality, quantity in O["fresh"].items():
    check(f"fresh {quality} export", RESULT["sources"]["newGearPerAttempt"][quality], quantity / 1000)
for group in ("currencies", "fragments", "materials"):
    target = RESULT[{"currencies": "globalCurrencies", "fragments": "globalFragments", "materials": "globalMaterials"}[group]]
    for key, value in O[group].items():
        check(f"global {group}/{key}", target[key], value)
check("daily fragment aggregation", RESULT["dailyFragments"]["netAll"], O["fragments"]["netBeforeOptionalUpgrade"] / O["playerDays"])
check("event cap", RESULT["event"]["maxFragmentsPerEvent"], O["eventCap"])
check("event full-completion coverage", RESULT["event"]["coverage"], O["eventCoverage"])
check("event season mean", RESULT["event"]["meanFragmentsPerActiveSeason"], O["eventFragmentsSeason"])
shop_input = {"fragment": "fragmentPacksPerDay", "warrior": "warriorPacksPerDay", "class": "classPacksPerDay", "card": "cardPacksPerDay"}
for item in M["shops"]:
    if item["id"] in shop_input:
        check(f"shop source input/{item['id']}", item["defaultPacksPerDay"], A[shop_input[item["id"]]])
    if item["dailyLimit"] is not None:
        check(f"shop purchase limit/{item['id']}", 0 <= item["defaultPacksPerDay"] <= item["dailyLimit"])

# Exhaust every legal exchange vector: one shared budget, never four independent maxima.
branches = E["branches"]
limits = [min(E["tokensPerEvent"] // b["tokenCost"], b.get("limitPerEvent", 10**6)) for b in branches]
legal = []
for quantities in itertools.product(*(range(limit + 1) for limit in limits)):
    spent = sum(q * b["tokenCost"] for q, b in zip(quantities, branches))
    if spent <= E["tokensPerEvent"]:
        legal.append({b["id"]: q * b["rewardCount"] for q, b in zip(quantities, branches)})
check("event maximum fragments under shared budget", max(x["fragment"] for x in legal), O["eventCap"])
check("event one potion leaves at most 20 fragments", max(x["fragment"] for x in legal if x["potion"] == 1), 20)
check("cannot take all branch maxima together", sum(l * b["tokenCost"] for l, b in zip(limits, branches)) > E["tokensPerEvent"])

# Global transfers cancel. Only room-final loss and consumed extra material bodies reduce stock.
for row in RESULT["globalStock"]:
    rho = dec(row["deadRecovery"])
    for quality, worn in (("orange", 1), ("purple", 4)):
        detail = row[quality]
        lost = dec(1000) * (1 - dec(A["extractionRate"])) * worn
        check(f"death conservation/{rho}/{quality}", detail["transferredFromDeaths"] + detail["finallyDestroyed"], lost)
        check(f"stock net/{rho}/{quality}", detail["netBeforeCraftUpgrade"], O["fresh"][quality] - lost * (1 - rho))

for example in RESULT["taxExamples"]:
    rate = K["taxRateGold"] if example["currency"] == "gold" else K["taxRateDiamond"]
    f = tax(example["price"], rate, K["minFee"])
    check(f"tax/{example['currency']}/{example['price']}", example["fee"], f)
    check(f"transaction conservation/{example['currency']}/{example['price']}", -example["price"] + example["sellerNet"] + f, 0)

# Small-server weekly cap: independent Bernoulli weekly opportunities, not a guaranteed drop.
for row in RESULT["redWeekly"]:
    prob = 1 - (1 - R["bossChance"]) ** row["bossKills"]
    keep = prob * R["finalRetainedFraction"]
    pmf = [1.0]
    for _ in range(R["alignedSeasonWeeks"]):
        nxt = [0.0] * (len(pmf) + 1)
        for k, weight in enumerate(pmf):
            nxt[k] += weight * (1 - keep)
            nxt[k + 1] += weight * keep
        pmf = nxt
    check(f"red probability/{row['bossKills']}", row["weeklyAnyGenerated"], prob)
    check(f"red retained count/{row['bossKills']}", row["sixWeeksExpectedRetained"], R["alignedSeasonWeeks"] * keep)
    check(f"red at least three/{row['bossKills']}", row["probRetainedAtLeast3"], sum(pmf[3:]))
    check(f"red maximum plus5/{row['bossKills']}", row["expectedMaxPlus5IfPerfectlyConcentrated"], sum((k // 3) * weight for k, weight in enumerate(pmf)))
check("red 42-day aligned quota", RESULT["redQuota"]["aligned42MaximumItems"], 6)
check("red material cap does not refund quota", RESULT["redQuota"]["aligned42MaximumPlus5Items"], 2)
for row in RESULT["redQuota"]["alignedDays"]:
    # A half-open interval starting just before a weekly boundary touches at most ceil(D/7)+1 week keys.
    check(f"partial week bound/{row['days']}", row["maxTouchedWeekKeys"], math.ceil(row["days"] / 7) + 1)

for row in RESULT["marketDepth"]:
    propensity = A.get("marketListedFraction", A.get("marketEligibleFraction"))
    lam = row["activePlayers"] * A["attemptsPerDay"] * float(O["fresh"]["orange"] / 1000) * A["targetElementWeight"] * A["targetEffectWeight"] * A["targetSlotWeight"] * propensity
    check(f"new listing arrival/{row['activePlayers']}", row["targetOrangeListingsPerDay"], lam)
    check(f"new listing probability/{row['activePlayers']}", row["probAnyTargetListing48h"], 1 - math.exp(-2 * lam))
    check(f"unused listing probability/{row['activePlayers']}", row["probAnyUnusedSample48h"], 1 - math.exp(-2 * lam * A["recipeSampleUnusedFraction"]))
    check(f"listing probability is not sale claim/{row['activePlayers']}", "非买家成交率" in row["meaning"])

# Verify the actual arithmetic prefix responds to input changes. No output writes are executed.
tree = ast.parse(BUILDER.read_text())
prefix = []
for node in tree.body:
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "checks" for t in node.targets):
        break
    prefix.append(node)
assert prefix and len(prefix) < len(tree.body)
assert not any(isinstance(node, ast.Attribute) and node.attr in ("write_text", "write_bytes", "mkdir", "unlink", "remove") for node in ast.walk(ast.Module(body=prefix, type_ignores=[])))


def builder_prefix(overrides):
    nodes = []
    for node in copy.deepcopy(prefix):
        nodes.append(node)
        if isinstance(node, ast.Assign):
            names = [t.id for t in node.targets if isinstance(t, ast.Name)]
            for name in names:
                if name in overrides:
                    update = ast.parse(f"{name}.update({overrides[name]!r})").body[0]
                    nodes.append(update)
    mod = ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[]))
    scope = {"__file__": str(BUILDER)}
    exec(compile(mod, str(BUILDER) + ":read_only_prefix", "exec"), scope)
    return scope


wiring = []
scenarios = [
    ("fragment pack doubled", {"assumptions": {"fragmentPacksPerDay": 2}}, "globalCurrencies", "goldShopSink", "currencies"),
    ("card pack doubled", {"assumptions": {"cardPacksPerDay": 1}}, "globalCurrencies", "goldShopSink", "currencies"),
    ("recovery reduced to 25 percent orange", {"assumptions": {"deadGearRecoveredRate": .25}}, "globalMaterials", "orangeNetAfterOptionalUpgrades", "materials"),
    ("recovery reduced to 25 percent purple", {"assumptions": {"deadGearRecoveredRate": .25}}, "globalMaterials", "purpleNetAfterOptionalUpgrades", "materials"),
    ("event direct gold", {"event": {"directGoldPerCompletedEvent": 100}}, "globalCurrencies", "eventGoldCreated", "currencies"),
    ("event direct diamond", {"event": {"directDiamondsPerCompletedEvent": 10}}, "globalCurrencies", "eventDiamondCreated", "currencies"),
    ("event direct orange", {"event": {"directOrangeBodiesPerCompletedEvent": 1}}, "globalMaterials", "orangeNetAfterOptionalUpgrades", "materials"),
    ("event direct purple", {"event": {"directPurpleBodiesPerCompletedEvent": 1}}, "globalMaterials", "purpleNetAfterOptionalUpgrades", "materials"),
    ("candidate diamond tax 15 percent", {"market": {"taxRateDiamond": .15}}, "globalCurrencies", "diamondTaxSink", "currencies"),
]
for label, overrides, output, field, group in scenarios:
    aa, ee, kk = copy.deepcopy(A), copy.deepcopy(E), copy.deepcopy(K)
    aa.update(overrides.get("assumptions", {})); ee.update(overrides.get("event", {})); kk.update(overrides.get("market", {}))
    independent = oracle(aa, ee, kk)
    source_result = builder_prefix(overrides)["results"][output][field]
    expected = independent[group][field]
    wiring.append({"name": label, "passed": close(source_result, expected), "actual": source_result, "expected": expected,
                   "note": "Hypothetical source-input sensitivity; not a change to recommended default values."})

processing = builder_prefix({"assumptions": {"exampleOrangeBodyPriceGold": 800}})["results"]["processingExamples"]
processing_orange = next(x for x in processing if x["quality"] == "orange")
wiring.append({"name": "example orange purchase price input", "passed": close(processing_orange["assumedBodyPriceGold"], 800),
               "actual": processing_orange["assumedBodyPriceGold"], "expected": 800})

semantics = [
    {"topic": "activity completion", "requiredInterpretation": "completionFraction is the fraction of participating accounts receiving the entire 12-token budget; others contribute zero in this simplified scenario.",
     "counterexample": "If it is mean token-progress instead, 60% receive10 and40% receive9 tokens: E[T]=9.6, both redeem3 fragment packs, so season expectation is32.4 not34.56.",
     "meanProgress80PercentAlternative": 2 * .6 * .9 * 30},
    {"topic": "listing propensity", "requiredInterpretation": "marketEligibleFraction must be the combined probability of an exported original item actually being listed, including tradability and seller intent; mere eligibility is insufficient.",
     "notEstablished": "Poisson chance of a new matching listing cannot establish a buyer fill rate, attainable price, or buyer competition."},
    {"topic": "red retention", "requiredInterpretation": "finalRetainedFraction is the chance a newly minted red item is exported into economic stock before optional +4/+5 consumption; it must not already include the same enhancement material sink."},
    {"topic": "crafting and recipe learning", "requiredInterpretation": "Each normal mark craft creates one original body; credit that body against replacement shortages even when its effect misses. Market transfers do not mint bodies. Reforge transforms one body into one unteachable body, consuming an unused teaching right if the input had one."},
]

OUTPUT = {"meta": {"purpose": "independent ledger and input-wiring audit; no combat/demand simulation", "modelSha256": hashlib.sha256(MODEL_BYTES).hexdigest(),
                   "builderSha256": hashlib.sha256(BUILDER.read_bytes()).hexdigest(), "baseSha256": hashlib.sha256(BASE_BYTES).hexdigest(),
                   "outputsWrittenByThisScript": ["verify_market_model_v2_results.json"], "rootBuilderWritingSectionExecuted": False},
          "checks": CHECKS, "baselinePassed": sum(x["passed"] for x in CHECKS), "baselineTotal": len(CHECKS),
          "independent": O, "activityLegalExchangeVectorCount": len(legal), "inputWiring": wiring,
          "inputWiringPassed": sum(x["passed"] for x in wiring), "inputWiringTotal": len(wiring), "semantics": semantics}


def encode(value):
    if isinstance(value, Decimal):
        return float(value)
    raise TypeError(type(value).__name__)


(HERE / "verify_market_model_v2_results.json").write_text(json.dumps(OUTPUT, ensure_ascii=False, indent=2, default=encode) + "\n")
print(json.dumps({"baselinePassed": OUTPUT["baselinePassed"], "baselineTotal": OUTPUT["baselineTotal"],
                  "inputWiringPassed": OUTPUT["inputWiringPassed"], "inputWiringTotal": OUTPUT["inputWiringTotal"],
                  "failedBaseline": [x for x in CHECKS if not x["passed"]], "failedWiring": [x for x in wiring if not x["passed"]],
                  "keyResults": {"currencies": O["currencies"], "fragments": O["fragments"], "materials": O["materials"]}}, ensure_ascii=False, indent=2, default=encode))
if not all(x["passed"] for x in CHECKS):
    raise SystemExit(1)
