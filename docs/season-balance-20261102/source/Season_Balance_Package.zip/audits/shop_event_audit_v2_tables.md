# 商店与活动预算复算表

以下均为现行商店参数叠加候选 D2 R1 的条件预算，非真实对局结果。

## 每日金币可负担性

| 分钟 | 口径 | 日局数 | 金币/日 | 3碎片包+1药后余额 | 3碎片包+2药后余额 | 买满三种资源包后余额 |
| --- | --- | --- | --- | --- | --- | --- |
| 30 | continuous | 1.6667 | 260.1667 | -199.8333 | -299.8333 | -1039.8333 |
| 30 | whole_daily | 1 | 156.1 | -303.9 | -403.9 | -1143.9 |
| 60 | continuous | 3.3333 | 520.3333 | 60.3333 | -39.6667 | -779.6667 |
| 60 | whole_daily | 3 | 468.3 | 8.3 | -91.7 | -831.7 |
| 120 | continuous | 6.6667 | 1040.6667 | 580.6667 | 480.6667 | -259.3333 |
| 120 | whole_daily | 6 | 936.6 | 476.6 | 376.6 | -363.4 |
| 150 | continuous | 8.3333 | 1300.8333 | 840.8333 | 740.8333 | 0.8333 |
| 150 | whole_daily | 8 | 1248.8 | 788.8 | 688.8 | -51.2 |
| 180 | continuous | 10 | 1561 | 1101 | 1001 | 261 |
| 180 | whole_daily | 10 | 1561 | 1101 | 1001 | 261 |

## 42 日有余额结转的碎片购买

| 分钟 | 口径 | 药/日 | 卡包/日 | 另留金/日 | 购碎包数 | 商店碎片 | 剩余可动金 | 季末净碎片 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 30 | whole_daily | 0 | 0 | 0 | 54 | 1080 | 76.2 | 1424.4 |
| 30 | whole_daily | 1 | 0 | 0 | 19 | 380 | 76.2 | 724.4 |
| 60 | continuous | 0 | 0 | 0 | 126 | 2520 | 6734 | 3668 |
| 60 | whole_daily | 0 | 0 | 0 | 126 | 2520 | 4548.6 | 3553.2 |
| 60 | whole_daily | 1 | 0 | 0 | 126 | 2520 | 348.6 | 3553.2 |
| 60 | whole_daily | 2 | 0 | 0 | 93 | 1860 | 108.6 | 2893.2 |
| 60 | whole_daily | 1 | 0 | 100 | 93 | 1860 | 108.6 | 2893.2 |
| 60 | whole_daily | 1 | 1 | 0 | 41 | 820 | 48.6 | 1853.2 |
| 120 | whole_daily | 1 | 1 | 0 | 126 | 2520 | 9517.2 | 4586.4 |

## 价格与限购约束

| 季长 | 目标 | 碎片 | 按6金/碎估值 | 零碎库存购买包数 | 实际购包金币 | 至少日切窗口数 |
| --- | --- | --- | --- | --- | --- | --- |
| 30 | regular_plus3 | 52 | 312 | 3 | 360 | 1 |
| 30 | regular_plus3_reforge | 58 | 348 | 3 | 360 | 1 |
| 30 | max_plus5 | 573 | 3438 | 29 | 3480 | 10 |
| 30 | weapon_plus5 | 248 | 1488 | 13 | 1560 | 5 |
| 42 | regular_plus3 | 60 | 360 | 3 | 360 | 1 |
| 42 | regular_plus3_reforge | 66 | 396 | 4 | 480 | 2 |
| 42 | max_plus5 | 780 | 4680 | 39 | 4680 | 13 |
| 42 | weapon_plus5 | 248 | 1488 | 13 | 1560 | 5 |
| 60 | regular_plus3 | 60 | 360 | 3 | 360 | 1 |
| 60 | regular_plus3_reforge | 66 | 396 | 4 | 480 | 2 |
| 60 | max_plus5 | 780 | 4680 | 39 | 4680 | 13 |
| 60 | weapon_plus5 | 248 | 1488 | 13 | 1560 | 5 |

## 继续穿 +3 时，储蓄全套 +4/+5 的 720 碎增量

| 口径 | 商店碎/日 | 穿+3净碎/日 | 储蓄720所需条件均值天 | 穿上+5后净碎/日 | +5片账平衡撤离率 |
| --- | --- | --- | --- | --- | --- |
| continuous | 0 | 27.3333 | 26.3415 | -692.6667 | 0.9516 |
| continuous | 40 | 67.3333 | 10.6931 | -652.6667 | 0.937 |
| continuous | 60 | 87.3333 | 8.2443 | -632.6667 | 0.9298 |
| whole_daily | 0 | 24.6 | 29.2683 | -623.4 | 0.9516 |
| whole_daily | 40 | 64.6 | 11.1455 | -583.4 | 0.9354 |
| whole_daily | 60 | 84.6 | 8.5106 | -563.4 | 0.9274 |

## 活动兑换分支（互斥预算，不可整行叠加）

| 分支 | 每期碎/勇魂/职魂/药 | 两期满额 | 全服每名符合资格账号季期望 |
| --- | --- | --- | --- |
| all_fragments | {'fragments': 40, 'warrior_souls': 0, 'class_souls': 0, 'potions': 0} | {'fragments': 80, 'warrior_souls': 0, 'class_souls': 0, 'potions': 0} | {'fragments': 34.56, 'warrior_souls': 0, 'class_souls': 0, 'potions': 0} |
| all_warrior_souls | {'fragments': 0, 'warrior_souls': 24, 'class_souls': 0, 'potions': 0} | {'fragments': 0, 'warrior_souls': 48, 'class_souls': 0, 'potions': 0} | {'fragments': 0, 'warrior_souls': 20.736, 'class_souls': 0, 'potions': 0} |
| all_class_souls | {'fragments': 0, 'warrior_souls': 0, 'class_souls': 8, 'potions': 0} | {'fragments': 0, 'warrior_souls': 0, 'class_souls': 16, 'potions': 0} | {'fragments': 0, 'warrior_souls': 0, 'class_souls': 6.912, 'potions': 0} |
| mixed_resources | {'fragments': 20, 'warrior_souls': 6, 'class_souls': 2, 'potions': 0} | {'fragments': 40, 'warrior_souls': 12, 'class_souls': 4, 'potions': 0} | {'fragments': 17.28, 'warrior_souls': 5.184, 'class_souls': 1.728, 'potions': 0} |
| potion_and_fragments | {'fragments': 20, 'warrior_souls': 0, 'class_souls': 0, 'potions': 1} | {'fragments': 40, 'warrior_souls': 0, 'class_souls': 0, 'potions': 2} | {'fragments': 17.28, 'warrior_souls': 0, 'class_souls': 0, 'potions': 0.864} |

## 活动集中发放

| 指标 | 数值 |
| --- | --- |
| effective_fraction | 0.432 |
| max_fragment_claim_single_event | 40 |
| max_fragments_per_full_participant_season | 80 |
| expected_fragments_per_eligible_account_season | 34.56 |
| season_average_fragments_per_eligible_account_day | 0.8229 |
| event_uniform_three_day_average | 5.76 |
| event_concentrated_one_day_peak | 17.28 |
| 1000_eligible_season_fragments | 34560 |
| 1000_eligible_single_claim_day_fragments | 17280 |
| 1000_eligible_season_shop_gold_sink_reduction_upper_bound | 207360 |

## 统一v2基础+三选一+商店+活动片账

| 指标 | 数值 |
| --- | --- |
| mode | whole_daily |
| minutes | 60 |
| attempts | 3 |
| shop_fragment_packs_per_day | 1 |
| base_route_fragments | 40 |
| double_choice_route_fragments | 86.5 |
| choice_fragments_per_attempt | 6.6413 |
| choice_fragments_per_day | 19.9237 |
| base_fragments_net_after_plus3_rebuild_per_day | 24.6 |
| shop_fragments_per_day | 20 |
| activity_fragments_per_day | 0.8229 |
| full_fragment_net_per_day | 65.3466 |
| gold_after_one_fragment_pack_one_potion_per_day | 248.3 |

注意：商店金币被回收；市场买卖是转移，只有手续费回收。活动商店影子金价不是真金币投放或回收。
