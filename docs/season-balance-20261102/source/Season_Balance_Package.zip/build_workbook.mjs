import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SpreadsheetFile, Workbook } from '@oai/artifact-tool';

// Run with the managed primary Node runtime. All balance inputs come from the
// root-authored JSON. This file never reads game credentials or a live service.
const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const inputFile = process.argv[2] || path.join(scriptDir, 'season_model_inputs.json');
const outputDir = process.argv[3] || path.join(scriptDir, 'rebuilt');
const data = JSON.parse(await fs.readFile(inputFile, 'utf8'));
const marketInputFile=process.argv[5] || path.join(path.dirname(inputFile),'market_model_v2.json');
const v2=JSON.parse(await fs.readFile(marketInputFile,'utf8'));
await fs.mkdir(outputDir, {recursive: true});
const qaDir=path.join(outputDir,'qa');
await fs.mkdir(qaDir,{recursive:true});
const workbook = Workbook.create();
const sheetNames = ['总览', '参数', '成长与装备', '难度与怪物', '怪物展开', '掉落概率', '路线经济', '赛季进度', '配置字段', '红装周投放', '双币市场', '商店与活动', '全服资源账'];
const sheets = Object.fromEntries(sheetNames.map(name => [name, workbook.worksheets.add(name)]));
const C = {ink: '#223247', muted: '#64748B', accent: '#274765', lighter: '#456989', line: '#CBD5E1', input: '#FFF1C2', band: '#EDF2F7', white: '#FFFFFF', error: '#FDE9E7', red: '#9D2520'};
const font = 'Noto Sans CJK SC';
const validationResults = [];
const refs = {};

function col(n) {
  let out = ''; for (let k=n+1;k>0;k=Math.floor((k-1)/26)) out=String.fromCharCode(65+(k-1)%26)+out;
  return out;
}
function val(name, cell, value) { sheets[name].getRange(cell).values=[[value]]; }
function fx(name, cell, formula) { sheets[name].getRange(cell).formulas=[[formula]]; }
function ref(name, cell) { return `'${name}'!${cell}`; }
function input(name, cell, value, numberFormat='0.00') {
  val(name, cell, value); const r=sheets[name].getRange(cell); r.format.fill=C.input; r.setNumberFormat(numberFormat);
}
function block(name, row, headers, values, options={}) {
  const s=sheets[name]; const last=col(headers.length-1); const header=s.getRange(`A${row}:${last}${row}`);
  header.values=[headers]; header.format={fill:C.accent,font:{name:font,size:10,bold:true,color:C.white},verticalAlignment:'center',horizontalAlignment:'center',wrapText:true};
  header.format.rowHeight=32;
  if(values.length) s.getRange(`A${row+1}:${last}${row+values.length}`).values=values;
  if(values.length) {
    const body=s.getRange(`A${row+1}:${last}${row+values.length}`); body.format.rowHeight=25;
    body.format.borders={bottom:{style:'thin',color:C.line}};
  }
  return {first:row+1,last:row+values.length,header:row,cols:headers.length};
}
function title(name, heading, width, rows=100) {
  const s=sheets[name]; const all=s.getRange(`A1:${col(width-1)}${rows}`);
  all.format.font={name:font,size:10,color:C.ink}; all.format.verticalAlignment='center'; all.format.rowHeight=23;
  s.showGridLines=false; s.getRange(`A1:${col(width-1)}1`).format.rowHeight=10;
  val(name,'A2',heading); s.getRange('A2').format.font={name:font,size:16,bold:true,color:C.ink};
  s.getRange(`A3:${col(width-1)}3`).format.borders={bottom:{style:'thin',color:C.line}};
  s.getRange(`A1:${col(width-1)}${rows}`).format.columnWidth=15;
  s.getRange(`A1:A${rows}`).format.columnWidth=24;
  if(name!=='总览') s.freezePanes.freezeRows(5);
}
function note(name, cell, text, span=1) {
  val(name,cell,text); sheets[name].getRange(cell).format.font={name:font,size:10,color:C.muted,italic:true};
}
function formulaColumn(name, first, last, column, formula, numberFormat='0.00') {
  fx(name,`${column}${first}`,formula);
  if(last>first) sheets[name].getRange(`${column}${first}:${column}${last}`).fillDown();
  sheets[name].getRange(`${column}${first}:${column}${last}`).setNumberFormat(numberFormat);
}
function check(label, condition, detail) {
  validationResults.push({label,passed:!!condition,detail});
  if(!condition) throw new Error(`${label}: ${detail}`);
}
function near(actual, expected, tol=1e-8) { return typeof actual==='number' && Math.abs(actual-expected)<=tol*Math.max(1,Math.abs(expected)); }
function read(name,cell) { return sheets[name].getRange(cell).values[0][0]; }
function chart(name, type, ranges, start, end, heading, numberFormat='0.0') {
  const s=sheets[name]; const ch=s.charts.add(type,ranges.map(r=>s.getRange(r)));
  ch.setPosition(start,end); ch.title=heading; ch.titleTextStyle.fontSize=14; ch.titleTextStyle.typeface=font;
  ch.legend={position:'top',textStyle:{typeface:font,fontSize:11}};
  ch.xAxis={axisType:'textAxis',textStyle:{typeface:font,fontSize:11}};
  ch.yAxis={numberFormatCode:numberFormat,numberFormatSourceLinked:false,textStyle:{typeface:font,fontSize:11}};
  const colors=['#2B5F8A','#B78125','#63845A','#8972A3'];
  ch.series.items.forEach((s,i)=>{s.fill=colors[i%colors.length];if(type==='line')s.line={fill:colors[i%colors.length],style:'solid',width:2};});
  return ch;
}

const p = {};
const eqRows = {};
const diffRows = {};
const layerRows = {};
const costRows = {};
const lootRows = {};
const baseMonsterRows = [];
const buildRows = {};
const stats = {};

// The workbook is a proposed balance calculator, not a live game simulator.
title('参数','输入参数与文档基线',14,110);
note('参数','A4','淡黄色单元格可调整。当前值为候选方案或文档基线，来源列区分两者。');
const assumptions = [
 ['seasonDays','赛季自然日',data.assumptions.seasonDays,'天','仅30至60；默认42','本次数值方案'],
 ['dailyMinutes','每日游玩时间',data.assumptions.dailyMinutes,'分钟','均摊与整局两种口径并列','测算假设'],
 ['minutesPerAttempt','每次尝试耗时',data.assumptions.minutesPerAttempt,'分钟','包含失败尝试的平均时间，待实测','测算假设'],
 ['extractionRate','成功撤离率',data.assumptions.extractionRate,'比例','选择与撤离未做条件联合模拟','测算假设'],
 ['selectedDifficultyIndex','当前难度索引',data.assumptions.selectedDifficultyIndex,'0至5','0=D0，5=D5','本次数值方案'],
 ['gearChoiceRate','装备选择率',data.assumptions.gearChoiceRate,'比例','三选一选择装备的条件假设','测算假设'],
 ['targetElementWeight','偏好元素权重',data.assumptions.targetElementWeight,'比例','进图自选元素；其余四系各15%','本次数值方案'],
 ['targetEffectWeight','目标效果词缀率',data.assumptions.targetEffectWeight,'比例','随机三种效果之一','本次数值方案'],
 ['targetSlotWeight','指定部位概率',data.assumptions.targetSlotWeight,'比例','五部位均匀示例','测算假设'],
 ['baseDrawInterval','基础抽牌间隔',data.assumptions.baseDrawInterval,'秒','样本不含即时抽牌/本命反馈','GDD_BASE_v0.69 §3.4'],
 ['drawFloor','普通抽牌间隔下限',data.assumptions.drawFloor,'秒','疾抽特殊下限未纳入样本','GDD_BASE_v0.69 §3.4'],
 ['resistCap','同元素抗性上限',data.assumptions.resistCap,'比例','样本为同一元素五件','GDD_BASE_v0.69 §3.4'],
 ['defenseReduction','防守方载壁减伤示例',data.assumptions.defenseReduction,'比例','仅盾职业激活时可用；默认0','GDD v0.70 §3.2.e'],
 ['referenceTargetResist','目标主核抗性示例',data.assumptions.referenceTargetResist,'比例','仅用作伤害算术样本','测算假设'],
 ['cardValue1','样本第1张元素基础',data.assumptions.referenceCardValues[0],'点','三张同核元素，不含效果套伤害','GDD现行样本'],
 ['cardValue2','样本第2张元素基础',data.assumptions.referenceCardValues[1],'点','等级按每级+1取样','GDD现行样本'],
 ['cardValue3','样本第3张元素基础',data.assumptions.referenceCardValues[2],'点','不是完整20张合法卡组','GDD现行样本'],
 ['gearRebuildLevel','重建装备强化级',data.assumptions.gearRebuildLevel,'级','1橙4紫同强化档，仅比较碎片投入','本次数值方案'],
 ['returnKitGrant','每次死亡返还碎片',data.assumptions.returnKitGrant,'碎片','默认0；未自动发放返还包','测算假设'],
 ['levels','赛季轨道等级数',data.progression.levels,'级','工作簿展开30级','本次数值方案'],
 ['firstLevelXp','第1级所需XP',data.progression.firstLevelXp,'XP','基准42日费用','本次数值方案'],
 ['stepXp','后续每级增加XP',data.progression.stepXp,'XP','线性级差，逐级向上取整','本次数值方案'],
 ['extractXp','成功撤离额外XP',data.progression.extractXp,'XP','清怪XP另加','本次数值方案'],
 ['failedAttemptXp','失败前有效清怪XP',data.progression.failedAttemptXp,'XP',data.progression.failedXpMeaning,'测算假设'],
 ['weeklyContractCount','每周契约数量',data.progression.weeklyContractCount,'个','采用每周均摊近似','本次数值方案'],
 ['weeklyContractXp','每份周契约XP',data.progression.weeklyContractXp,'XP','不模拟实际完成日期','本次数值方案'],
 ['contractCompletionFraction','契约完成比例',data.progression.contractCompletionFraction,'比例','默认全部完成，不是保证','测算假设'],
 ['purpleTokenCost','紫装定向打造价格',data.progression.purpleTokenCost,'印记','指定部位与元素；效果随机','本次数值方案'],
 ['orangeTokenCost','橙装定向打造价格',data.progression.orangeTokenCost,'印记','同品质/部位/元素心愿3次保底','本次数值方案'],
 ['eliteTokens','精英格印记',data.progression.eliteTokens,'枚','成功撤离时结算','本次数值方案'],
 ['bossTokens','Boss格印记',data.progression.bossTokens,'枚','成功撤离时结算','本次数值方案'],
 ['tokenCapPerRun','每局印记上限',data.progression.tokenCapPerRun,'枚','D1蓝图章，D2及以上橙图章','本次数值方案'],
 ['bossPhaseRatio','Boss转阶段血量比例',data.validations.bossPhaseRatio,'比例','阈值随同一实体最大生命缩放','本次数值方案'],
 ['orangeWearCap','橙红合计穿戴上限',data.validations.orangeWearCap,'件','红走每服每周最多1件独立配额','GDD_BASE_v0.69 §3.4 / 用户本轮要求'],
 ['slotCount','防具槽位数',data.validations.slotCount,'件','专武不计入五防具','GDD_BASE_v0.69 §3.4'],
 ['cardMaxLevel','卡牌强化上限',data.validations.cardMaxLevel,'级','永久卡牌魂价保持原表','GDD_BASE_v0.69 §4.6'],
 ['equipmentMaxLevel','防具强化上限',data.validations.equipmentMaxLevel,'级','+4/+5仍有同品质材料消耗','GDD_BASE_v0.69 §4.8'],
 ['resonanceStep','同核后续牌共振增幅',0.2,'比例','三张同核为1.4倍；无向反/额外共振','GDD v0.70 §3.2.a'],
 ['baseSeasonDays','费用缩放基准',42,'天','min(1,赛季日数/42)','本次数值方案'],
 ['fullSetReforgeCost','全套已学模板重铸费',data.rebuild.fullSetReforgeCost,'碎片','消耗真实同品质本体，结果+0；4紫1橙','本次数值方案'],
 ['craftWishPity','心愿词缀打造保底',data.progression.craftWishPity,'次','相同品质/部位/元素心愿，最多3次','本次数值方案'],
];
block('参数',5,['参数','数值','单位','口径','来源'],assumptions.map(a=>[a[1],a[2],a[3],a[4],a[5]]));
assumptions.forEach((a,i)=>{p[a[0]]=ref('参数',`$B$${6+i}`);input('参数',`B${6+i}`,a[2],a[3]==='比例'?'0.0%':(a[3]==='秒'?'0.00':'0.0'));});
// Fixed dimensions and rule references are documented, but are not adjustable
// calculator controls; changing them requires rebuilding the corresponding tables.
for(const key of ['levels','purpleTokenCost','orangeWearCap','slotCount','cardMaxLevel','equipmentMaxLevel']){
 const addr=p[key].split('!')[1].replaceAll('$','');sheets['参数'].getRange(addr).format.fill=C.band;
}
sheets['参数'].getRange('A1:A110').format.columnWidth=28;
sheets['参数'].getRange('B1:B110').format.columnWidth=14;
sheets['参数'].getRange('C1:C110').format.columnWidth=13;
sheets['参数'].getRange('D6:D46').format.columnWidth=58;
sheets['参数'].getRange('E6:E46').format.columnWidth=36;
sheets['参数'].getRange('B6').dataValidation={rule:{type:'whole',operator:'between',formula1:30,formula2:60}};
sheets['参数'].getRange('B10').dataValidation={rule:{type:'whole',operator:'between',formula1:0,formula2:5}};
sheets['参数'].getRange('B23').dataValidation={rule:{type:'whole',operator:'between',formula1:0,formula2:5}};
for(const key of ['extractionRate','gearChoiceRate','targetElementWeight','targetEffectWeight','targetSlotWeight','contractCompletionFraction','resistCap','defenseReduction','referenceTargetResist']){
 const addr=p[key].split('!')[1].replaceAll('$','');sheets['参数'].getRange(addr).dataValidation={rule:{type:'decimal',operator:'between',formula1:0,formula2:1}};
}
block('参数',48,['文档','章节','用途'],data.sourceReferences.map(s=>[s.file,s.section,s.use]));
sheets['参数'].getRange('A49:C52').format.wrapText=true;sheets['参数'].getRange('A49:C52').format.rowHeight=64;
block('参数',55,['品质ID','品质','增伤基础','每级增伤','抗性基础','每级抗性','间隔减免','每级间隔减免'],data.equipment.map(e=>[e.id,e.name,e.damageBase,e.damagePerLevel,e.resistBase,e.resistPerLevel,e.speedBase,e.speedPerLevel]));
data.equipment.forEach((e,i)=>eqRows[e.id]=56+i);
sheets['参数'].getRange('C56:H60').format.fill=C.input;sheets['参数'].getRange('C56:H60').setNumberFormat('0.00%');
block('参数',64,['难度ID','名称','HP倍率','盾倍率','伤害倍率','间隔倍率','金币倍率','魂倍率','碎片倍率','常规掉落品质帽','紫装有效果率','卡牌等级帽','专武等级帽','入场品质帽'],data.difficulties.map(d=>[d.id,d.name,d.hpScale,d.shieldScale,d.damageScale,d.intervalScale,d.goldScale,d.soulScale,d.fragmentScale,d.qualityCap,d.purpleAffixChance,d.cardEffectiveLevelCap,d.weaponEffectiveLevelCap,d.entryQualityCap]));
data.difficulties.forEach((d,i)=>diffRows[d.id]=65+i);
sheets['参数'].getRange('C65:K70').format.fill=C.input;sheets['参数'].getRange('C65:I70').setNumberFormat('0.00');sheets['参数'].getRange('K65:K70').setNumberFormat('0%');
block('参数',74,['来源ID','名称','金币','勇士魂最小','勇士魂最大','职业魂','碎片最小','碎片最大','清怪XP','R1格数'],data.layers.map((l,i)=>[l.id,l.name,l.gold,l.soulMin,l.soulMax,l.classSoul,l.fragmentMin,l.fragmentMax,data.progression.clearXp[i],data.route.counts[i]]));
data.layers.forEach((l,i)=>layerRows[l.id]=75+i);
sheets['参数'].getRange('C75:J78').format.fill=C.input;sheets['参数'].getRange('C75:J78').setNumberFormat('0');
note('参数','A81','品质索引：白0、绿1、蓝2、紫3、橙4、红5。D2起可带红；普通五色掉落仍最多橙，红独立配额。');
note('参数','A83',data.route.note);
note('参数','A85','样本属性取自现有规则；难度倍率、掉落表、新强化价、赛季XP与印记为本次候选方案。');
note('参数','A87','专武累计强化248碎片保持原规则，不使用防具白品质的新价格。');
sheets['参数'].tabColor=C.lighter;

// Equipment costs remain inspectable beside their cumulative build.
title('成长与装备','玩家成长与装备重建',14,75);
note('成长与装备','A4','P0为已拥有三卡的裸装算术锚，非新号初始卡组；同核三卡不含效果套伤害、本命反馈或即时抽牌。');
block('成长与装备',5,['阶段','卡牌等级','元素增伤','原始抗性','有效抗性','间隔减免','间隔秒','三卡伤害','吞吐代理','已投碎片','全+3碎片','全+5碎片','建议难度','效果说明'],data.builds.map(b=>[b.id,b.cardLevel,null,null,null,null,null,null,null,null,null,null,b.difficulty,b.effect]));
data.builds.forEach((b,i)=>buildRows[b.id]=6+i);
const components=[];data.builds.forEach(b=>b.gear.forEach(g=>components.push({build:b.id,...g})));
block('成长与装备',16,['阶段','品质ID','件数','强化级','单件增伤','单件抗性','单件间隔减免','合计增伤','合计抗性','合计间隔减免','已投碎片','全+3碎片','全+5碎片'],components.map(g=>[g.build,g.quality,g.count,g.level,null,null,null,null,null,null,null,null,null]));
const compStart=17,compEnd=16+components.length;
const costData=[];data.equipment.forEach(e=>e.costs.forEach((v,i)=>costData.push([e.id,i+1,e.oldCosts[i],v,null,null,null])));
block('成长与装备',32,['品质ID','升至等级','旧逐级碎片','新42日逐级碎片','当季逐级碎片','当季累计','旧累计'],costData);
const costStart=33,costEnd=32+costData.length;
data.equipment.forEach((e,i)=>costRows[e.id]=33+i*5);
for(let r=costStart;r<=costEnd;r++){
 fx('成长与装备',`E${r}`,`=ROUNDUP(D${r}*MIN(1,${p.seasonDays}/${p.baseSeasonDays}),0)`);
 fx('成长与装备',`F${r}`,`=SUMIFS($E$${costStart}:$E$${costEnd},$A$${costStart}:$A$${costEnd},A${r},$B$${costStart}:$B$${costEnd},"<="&B${r})`);
 fx('成长与装备',`G${r}`,`=SUMIFS($C$${costStart}:$C$${costEnd},$A$${costStart}:$A$${costEnd},A${r},$B$${costStart}:$B$${costEnd},"<="&B${r})`);
}
sheets['成长与装备'].getRange(`D${costStart}:D${costEnd}`).format.fill=C.input;sheets['成长与装备'].getRange(`B${costStart}:G${costEnd}`).setNumberFormat('0');
components.forEach((g,i)=>{
 const r=compStart+i;const er=eqRows[g.quality];
 fx('成长与装备',`E${r}`,`='参数'!C${er}+D${r}*'参数'!D${er}`);
 fx('成长与装备',`F${r}`,`='参数'!E${er}+D${r}*'参数'!F${er}`);
 fx('成长与装备',`G${r}`,`='参数'!G${er}+D${r}*'参数'!H${er}`);
 for(const [target,source] of [['H','E'],['I','F'],['J','G']])fx('成长与装备',`${target}${r}`,`=C${r}*${source}${r}`);
 for(const [target,level] of [['K',`D${r}`],['L','3'],['M','5']])fx('成长与装备',`${target}${r}`,`=C${r}*SUMIFS($E$${costStart}:$E$${costEnd},$A$${costStart}:$A$${costEnd},B${r},$B$${costStart}:$B$${costEnd},"<="&${level})`);
});
sheets['成长与装备'].getRange(`C${compStart}:D${compEnd}`).format.fill=C.input;
sheets['成长与装备'].getRange(`E${compStart}:J${compEnd}`).setNumberFormat('0.0%');
data.builds.forEach((b,i)=>{
 const r=6+i;input('成长与装备',`B${r}`,b.cardLevel,'0');
 for(const [dst,src] of [['C','H'],['D','I'],['F','J'],['J','K'],['K','L'],['L','M']])fx('成长与装备',`${dst}${r}`,`=SUMIFS($${src}$${compStart}:$${src}$${compEnd},$A$${compStart}:$A$${compEnd},A${r})`);
 fx('成长与装备',`E${r}`,`=MIN(${p.resistCap},D${r})`);
 fx('成长与装备',`G${r}`,`=MAX(${p.drawFloor},${p.baseDrawInterval}*(1-F${r}))`);
 const k=`(1+${p.resonanceStep}*(3-1))`;
 const s=`(1+C${r})*(1-${p.referenceTargetResist})`;
 const terms=['cardValue1','cardValue2','cardValue3'].map(q=>`MAX(0,ROUNDDOWN(ROUND((${p[q]}+B${r})*${s}*${k},10),0))`);
 fx('成长与装备',`H${r}`,`=ROUNDDOWN(ROUND((${terms.join('+')})*(1-${p.defenseReduction}),10),0)`);
 fx('成长与装备',`I${r}`,`=IF(OR($H$6=0,G${r}=0),"不可计算",H${r}/$H$6*${p.baseDrawInterval}/G${r})`);
});
sheets['成长与装备'].getRange('C6:F11').setNumberFormat('0.0%');sheets['成长与装备'].getRange('G6:G11').setNumberFormat('0.000');sheets['成长与装备'].getRange('H6:H11').setNumberFormat('0');sheets['成长与装备'].getRange('I6:I11').setNumberFormat('0.00"x"');sheets['成长与装备'].getRange('J6:L11').setNumberFormat('0');
block('成长与装备',25,['重建对象','强化档','件数','当季碎片','旧规则碎片','降幅'],[['常规1橙4紫强化',null,5,null,null,null],['极限1橙4紫全+5',5,5,null,null,null],['常规强化加模板重铸',null,5,null,null,null]]);
fx('成长与装备','B26',`=${p.gearRebuildLevel}`);
for(const r of [26,27]){
 for(const [dst,costcol] of [['D','E'],['E','C']])fx('成长与装备',`${dst}${r}`,`=4*SUMIFS($${costcol}$${costStart}:$${costcol}$${costEnd},$A$${costStart}:$A$${costEnd},"purple",$B$${costStart}:$B$${costEnd},"<="&B${r})+SUMIFS($${costcol}$${costStart}:$${costcol}$${costEnd},$A$${costStart}:$A$${costEnd},"orange",$B$${costStart}:$B$${costEnd},"<="&B${r})`);
 fx('成长与装备',`F${r}`,`=IF(E${r}=0,0,1-D${r}/E${r})`);
}
sheets['成长与装备'].getRange('F26:F27').setNumberFormat('0.0%');refs.rebuild=ref('成长与装备','$D$26');refs.full5=ref('成长与装备','$D$27');
fx('成长与装备','B28','=B26');fx('成长与装备','D28',`=D26+${p.fullSetReforgeCost}`);refs.rebuildWithReforge=ref('成长与装备','$D$28');
note('成长与装备','A29','+4/+5同品质材料未折算碎片价值；表内不含装备本体、药剂、付费包和其他成本。');
note('成长与装备','A60','五件同一元素且均有间隔词条；鞋若选择逃脱词条，则实际抽牌间隔更慢。');
note('成长与装备','A62','新价格是可死亡掉落防具的候选重建预算；专武累计248碎片仍独立保留。');
note('成长与装备','A64','吞吐代理 = 三卡伤害相对裸装 × 基础抽牌间隔/当前间隔；不能解释为DPS、TTK或胜率。');
sheets['成长与装备'].getRange('A1:A75').format.columnWidth=23;sheets['成长与装备'].getRange('B1:M75').format.columnWidth=15;sheets['成长与装备'].getRange('N1:N75').format.columnWidth=52;

// Difficulty matrix and source monster templates.
title('难度与怪物','难度倍率与怪物基准',17,90);
note('难度与怪物','A4','倍率是候选值。怪物HP/盾按floor缩放；Boss转阶段阈值随最大HP，不重复增加二期HP。');
block('难度与怪物',5,['难度','名称','HP倍率','盾倍率','伤害倍率','间隔倍率','金币倍率','魂倍率','碎片倍率','常规掉落品质帽','紫装效果率','卡牌有效级帽','专武有效级帽','Boss最大HP','阶段阈值HP','入场品质帽','独立红判定'],data.difficulties.map(d=>[d.id,d.name,null,null,null,null,null,null,null,null,null,null,null,null,null,null,d.redDropEligible?'允许':'不允许']));
for(let i=0;i<data.difficulties.length;i++){
 const r=6+i,dr=65+i;for(const c of ['C','D','E','F','G','H','I','J','K','L','M'])fx('难度与怪物',`${c}${r}`,`='参数'!${c}${dr}`);fx('难度与怪物',`P${r}`,`='参数'!N${dr}`);
}
const monsterFlat=[];data.monsterGroups.forEach(g=>g.members.forEach((m,i)=>monsterFlat.push({group:g.id,groupName:g.name,layer:g.layerId,weight:g.weight,member:i+1,...m})));
block('难度与怪物',29,['组ID','名称','组权重','成员序','成员名称','基础HP','初始盾','间隔秒','首元素基础','自身元素增幅','意图循环','类型'],monsterFlat.map(m=>[m.group,m.groupName,m.weight,m.member,m.name,m.hp,m.shield,m.interval,m.firstDamage,m.elementBoost,m.intents,m.layer]));
monsterFlat.forEach((m,i)=>baseMonsterRows.push({row:30+i,...m}));
sheets['难度与怪物'].getRange(`F30:J${29+monsterFlat.length}`).format.fill=C.input;sheets['难度与怪物'].getRange(`J30:J${29+monsterFlat.length}`).setNumberFormat('0%');sheets['难度与怪物'].getRange(`H30:H${29+monsterFlat.length}`).setNumberFormat('0.0');
const bossBaseRow=baseMonsterRows.find(m=>m.group==='B1').row;
for(let i=0;i<data.difficulties.length;i++){
 const r=6+i;fx('难度与怪物',`N${r}`,`=MAX(1,ROUNDDOWN(ROUND($F$${bossBaseRow}*C${r},10),0))`);fx('难度与怪物',`O${r}`,`=ROUNDDOWN(N${r}*${p.bossPhaseRatio},0)`);
}
sheets['难度与怪物'].getRange('C6:I11').setNumberFormat('0.00"x"');sheets['难度与怪物'].getRange('K6:K11').setNumberFormat('0%');
chart('难度与怪物','line',['A5:A11','C5:C11','E5:E11'],'A14','G27','HP与基础意图伤害倍率','0.0"x"');
sheets['难度与怪物'].getRange('A1:B90').format.columnWidth=16;sheets['难度与怪物'].getRange('E1:E90').format.columnWidth=22;sheets['难度与怪物'].getRange('K1:K90').format.columnWidth=38;
note('难度与怪物','H15','二期仍是同一个Boss实体。');note('难度与怪物','H17','名义间隔未模拟10Hz调度与前摇。');note('难度与怪物','H19','首击示例不包含蓄力或强化。');note('难度与怪物','H21','循环上盾同样使用盾倍率。');
note('难度与怪物','H23','季赛PVE/PVP等级=min(实际,档位帽)。');note('难度与怪物','H25','新手可借该档模板；借用不写永久资产。');
title('怪物展开','所有难度的怪物展开',14,220);
note('怪物展开','A4','首击按普通元素意图：基础倍率floor、增抗floor、载壁floor、正命中至少1。取消/蓄力/上盾不触发最低伤害。');
const monsterRows=[];data.difficulties.forEach(d=>baseMonsterRows.forEach(m=>monsterRows.push([d.id,m.group,m.member,m.name,null,null,null,null,null,null,null,m.group==='B2'?'同一Boss阶段':'独立成员',m.intents])));
block('怪物展开',5,['难度','组ID','成员序','成员','缩放HP','初始盾','首意图基础','增抗后','减伤后示例','名义间隔秒','Boss阈值','实体说明','循环意图'],monsterRows);
let mr=6;for(const d of data.difficulties){const dr=diffRows[d.id];for(const m of baseMonsterRows){const r=mr++,br=m.row;
 fx('怪物展开',`E${r}`,`=MAX(1,ROUNDDOWN(ROUND('难度与怪物'!F${br}*'参数'!C${dr},10),0))`);
 fx('怪物展开',`F${r}`,`=MAX(0,ROUNDDOWN(ROUND('难度与怪物'!G${br}*'参数'!D${dr},10),0))`);
 fx('怪物展开',`G${r}`,`=MAX(0,ROUNDDOWN(ROUND('难度与怪物'!I${br}*'参数'!E${dr},10),0))`);
 fx('怪物展开',`H${r}`,`=MAX(0,ROUNDDOWN(ROUND(G${r}*(1+'难度与怪物'!J${br})*(1-${p.referenceTargetResist}),10),0))`);
 fx('怪物展开',`I${r}`,`=IF('难度与怪物'!I${br}>0,MAX(1,ROUNDDOWN(ROUND(H${r}*(1-${p.defenseReduction}),10),0)),0)`);
 fx('怪物展开',`J${r}`,`='难度与怪物'!H${br}*'参数'!F${dr}`);
 fx('怪物展开',`K${r}`,m.group.startsWith('B')?`=ROUNDDOWN(E${r}*${p.bossPhaseRatio},0)`:'=""');
}}
sheets['怪物展开'].getRange(`E6:I${mr-1}`).setNumberFormat('0');sheets['怪物展开'].getRange(`J6:J${mr-1}`).setNumberFormat('0.000');sheets['怪物展开'].getRange('A1:C220').format.columnWidth=11;sheets['怪物展开'].getRange('D1:D220').format.columnWidth=19;sheets['怪物展开'].getRange('L1:L220').format.columnWidth=22;sheets['怪物展开'].getRange('M1:M220').format.columnWidth=38;

// Loot probabilities are candidates before health/treasure promotions.
title('掉落概率','难度掉落与定向获取',13,62);
note('掉落概率','A4','基础装备候选概率。健康偏置/匣灵仅一次升档且最多升到紫；自然橙不降级，最终服从难度及来源品质帽。');
block('掉落概率',5,['ID','难度','来源','白','绿','蓝','紫','橙','概率和','品质帽','升档帽','输入状态'],data.loot.map(l=>[l.id,l.difficultyId,data.layers.find(x=>x.id===l.layerId).name,...l.weights,null,l.qualityCap,l.promotionCap,null]));
data.loot.forEach((l,i)=>{const r=6+i;lootRows[l.id]=r;fx('掉落概率',`J${r}`,`=MIN('参数'!J${diffRows[l.difficultyId]},${l.layerId==='outer'?3:4})`);fx('掉落概率',`I${r}`,`=SUM(D${r}:H${r})`);const above=['D','E','F','G','H'].map((c,j)=>`IF(${j}>J${r},${c}${r},0)`).join('+');fx('掉落概率',`L${r}`,`=IF(AND(ABS(I${r}-1)<0.000000001,MIN(D${r}:H${r})>=0,MAX(D${r}:H${r})<=1,(${above})=0),"有效","检查概率/品质帽")`);});
sheets['掉落概率'].getRange('D6:H29').format.fill=C.input;sheets['掉落概率'].getRange('D6:I29').setNumberFormat('0.0%');sheets['掉落概率'].getRange('L6:L29').conditionalFormats.add('containsText',{text:'检查',format:{fill:C.error,font:{color:C.red,bold:true}}});
block('掉落概率',33,['获取指标','当前值','单位'],[
 ['当前难度Boss自然橙率',null,'概率'],
 ['指定部位/元素/效果带出率',null,'每次尝试'],
 ['指定橙平均等待',null,'次尝试'],
 ['指定橙P50等待',null,'次尝试'],
 ['指定橙P90等待',null,'次尝试'],
 ['条件路线每次成功印记',null,'枚'],
 ['心愿橙最多打造次数',null,'次'],
 ['指定效果橙最多印记',null,'枚'],
 ['指定效果橙最多成功撤离',null,'次'],
]);
fx('掉落概率','B34',`=INDEX($H$6:$H$29,${p.selectedDifficultyIndex}*4+4)`);
fx('掉落概率','B35',`=B34*${p.gearChoiceRate}*${p.extractionRate}*${p.targetElementWeight}*${p.targetEffectWeight}*${p.targetSlotWeight}`);
fx('掉落概率','B36','=IF(B35=0,"不可获得",1/B35)');
fx('掉落概率','B37','=IF(B35=0,"不可获得",IF(B35=1,1,ROUNDUP(LN(0.5)/LN(1-B35),0)))');
fx('掉落概率','B38','=IF(B35=0,"不可获得",IF(B35=1,1,ROUNDUP(LN(0.1)/LN(1-B35),0)))');
fx('掉落概率','B39',`=MIN(${p.tokenCapPerRun},'参数'!J${layerRows.elite}*${p.eliteTokens}+'参数'!J${layerRows.boss}*${p.bossTokens})`);
fx('掉落概率','B40',`=${p.craftWishPity}`);
fx('掉落概率','B41',`=B40*${p.orangeTokenCost}`);
fx('掉落概率','B42',`=IF(${p.selectedDifficultyIndex}<2,"D2起可用",IF(B39=0,"无印记",ROUNDUP(B41/B39,0)))`);
sheets['掉落概率'].getRange('B34:B35').setNumberFormat('0.00%');sheets['掉落概率'].getRange('B36:B36').setNumberFormat('0.0');
note('掉落概率','A45','偏好元素由玩家进图自选，默认主题元素。所选40%，其他四元素各15%；不是整个赛季强制只养一个元素。');
note('掉落概率','A47',data.progression.tokenScope);
note('掉落概率','A49','概率等待不含中层/精英的其他橙候选；品质会影响选择和撤离决策，须用真实联合分布再校准。');
note('掉落概率','A51','红不进普通五色表，走每服自然周最多1件独立渠道；D5无需红。市场/遗物不增加印记或打造保底。');
sheets['掉落概率'].getRange('A1:A62').format.columnWidth=34;sheets['掉落概率'].getRange('B1:B62').format.columnWidth=18;sheets['掉落概率'].getRange('C1:C62').format.columnWidth=20;sheets['掉落概率'].getRange('D1:K62').format.columnWidth=14;sheets['掉落概率'].getRange('L1:L62').format.columnWidth=25;

// Per-integer rounding is explicitly expanded before expectations.
title('路线经济','条件路线收益与死亡重建',18,185);
note('路线经济','A4','给定坐标R1的基础格掉分项账；三选一额外碎片、普通商店和活动见扩展页，不能重复相加。');
block('路线经济',5,['难度','成功金币','成功勇士魂','成功职业魂','成功碎片','橙候选数','带出橙/尝试','均摊日毛碎','均摊日强化重建','仅强化均摊日净','仅强化平衡率','全+5平衡率','仅强化整局日净','仅强化每次净','含重铸每次净','含重铸均摊日净','含重铸整局日净','配装有效性'],data.difficulties.map((d,i)=>[d.id,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,i<2?'参考压力，不可带入':'允许带入；未计本体']));
note('路线经济','N14','仅碎片账；装备本体和金币须另验。');
block('路线经济',18,['ID','难度','来源','格数','单格金币','单格勇士魂期望','单格职业魂','单格碎片期望','自然橙率','橙候选期望'],data.loot.map(l=>[l.id,l.difficultyId,l.layerId,null,null,null,null,null,null,null]));
const rewardStart=19,rewardEnd=18+data.loot.length;
val('路线经济','A45','金币与职业魂：逐格向下取整。勇士魂与碎片：逐个可能整数先取整，再求均值。');
val('路线经济','A47','死亡按整套1橙4紫重建做压力比较，D0/D1不产且不能带橙；本表不含装备本体、药剂、付费包、刷新与市场。');
val('路线经济','A49','失败当次没有安全格带出，返还碎片默认0；死亡转遗物不等于全服销毁。');
block('路线经济',53,['每日期望口径','连续均摊','每日整局'],[['尝试次数',null,null],['成功撤离次数',null,null],['失败次数',null,null],['每死重建碎片',null,null]]);
fx('路线经济','B54',`=IF(OR(NOT(ISNUMBER(${p.dailyMinutes})),NOT(ISNUMBER(${p.minutesPerAttempt})),${p.dailyMinutes}<0,${p.minutesPerAttempt}<=0),"缺少有效时长",${p.dailyMinutes}/${p.minutesPerAttempt})`);
fx('路线经济','C54','=IF(ISNUMBER(B54),ROUNDDOWN(B54,0),"缺少有效时长")');
for(const c of ['B','C']){fx('路线经济',`${c}55`,`=IF(ISNUMBER(${c}54),${c}54*${p.extractionRate},"缺少有效时长")`);fx('路线经济',`${c}56`,`=IF(ISNUMBER(${c}54),${c}54*(1-${p.extractionRate}),"缺少有效时长")`);fx('路线经济',`${c}57`,`=MAX(0,${refs.rebuild}-${p.returnKitGrant})`);}
refs.attempts=ref('路线经济','$B$54');refs.wholeAttempts=ref('路线经济','$C$54');refs.netLoss=ref('路线经济','$B$57');
const enumStart=64,enumEnd=164;
block('路线经济',63,['基础整数','D0魂','D1魂','D2魂','D3魂','D4魂','D5魂','','D0碎片','D1碎片','D2碎片','D3碎片','D4碎片','D5碎片'],Array.from({length:101},(_,i)=>[i,...Array(13).fill(null)]));
sheets['路线经济'].getRange('H63:H164').format.fill=C.white;
for(let r=enumStart;r<=enumEnd;r++)for(let di=0;di<6;di++){
 const dr=65+di;fx('路线经济',`${col(1+di)}${r}`,`=ROUNDDOWN(ROUND($A${r}*'参数'!$H$${dr},10),0)`);fx('路线经济',`${col(8+di)}${r}`,`=ROUNDDOWN(ROUND($A${r}*'参数'!$I$${dr},10),0)`);
}
data.loot.forEach((l,i)=>{
 const r=rewardStart+i,dr=diffRows[l.difficultyId],lr=layerRows[l.layerId],li=lootRows[l.id],di=data.difficulties.findIndex(d=>d.id===l.difficultyId),sCol=col(1+di),fCol=col(8+di);
 fx('路线经济',`D${r}`,`='参数'!J${lr}`);fx('路线经济',`E${r}`,`=ROUNDDOWN(ROUND('参数'!C${lr}*'参数'!G${dr},10),0)`);
 for(const [dst,outcol,mincol,maxcol] of [['F',sCol,'D','E'],['H',fCol,'G','H']]){
  const mn=`'参数'!${mincol}${lr}`,mx=`'参数'!${maxcol}${lr}`;
  fx('路线经济',`${dst}${r}`,`=IF(OR(NOT(ISNUMBER(${mn})),NOT(ISNUMBER(${mx})),${mn}<0,${mx}>100,${mn}>${mx}),"区间无效",SUMIFS($${outcol}$${enumStart}:$${outcol}$${enumEnd},$A$${enumStart}:$A$${enumEnd},">="&${mn},$A$${enumStart}:$A$${enumEnd},"<="&${mx})/(${mx}-${mn}+1))`);
 }
 fx('路线经济',`G${r}`,`=ROUNDDOWN(ROUND('参数'!F${lr}*'参数'!H${dr},10),0)`);fx('路线经济',`I${r}`,`='掉落概率'!H${li}`);fx('路线经济',`J${r}`,`=D${r}*I${r}`);
});
data.difficulties.forEach((d,i)=>{
 const r=6+i,a=rewardStart+i*4,b=a+3;
 for(const [dst,src] of [['B','E'],['C','F'],['D','G'],['E','H']])fx('路线经济',`${dst}${r}`,`=IF(COUNT(${src}${a}:${src}${b})<4,"区间无效",SUMPRODUCT($D$${a}:$D$${b},${src}${a}:${src}${b}))`);
 fx('路线经济',`F${r}`,`=SUM(J${a}:J${b})`);fx('路线经济',`G${r}`,`=F${r}*${p.gearChoiceRate}*${p.extractionRate}`);
 fx('路线经济',`H${r}`,`=IF(AND(ISNUMBER(E${r}),ISNUMBER($B$54)),E${r}*$B$55,"输入无效")`);fx('路线经济',`I${r}`,`=IF(ISNUMBER($B$56),$B$56*$B$57,"输入无效")`);fx('路线经济',`J${r}`,`=IF(AND(ISNUMBER(H${r}),ISNUMBER(I${r})),H${r}-I${r},"输入无效")`);
 fx('路线经济',`K${r}`,`=IF(ISNUMBER(E${r}),IF($B$57+E${r}=0,0,$B$57/($B$57+E${r})),"输入无效")`);fx('路线经济',`L${r}`,`=IF(ISNUMBER(E${r}),IF(${refs.full5}+E${r}=0,0,${refs.full5}/(${refs.full5}+E${r})),"输入无效")`);
 fx('路线经济',`M${r}`,`=IF(AND(ISNUMBER(E${r}),ISNUMBER($C$54)),E${r}*$C$55-$C$56*$C$57,"输入无效")`);
 fx('路线经济',`N${r}`,`=IF(ISNUMBER(E${r}),${p.extractionRate}*E${r}-(1-${p.extractionRate})*$B$57,"输入无效")`);
 fx('路线经济',`O${r}`,`=IF(ISNUMBER(N${r}),N${r}-(1-${p.extractionRate})*${p.fullSetReforgeCost},"输入无效")`);
 fx('路线经济',`P${r}`,`=IF(AND(ISNUMBER(O${r}),ISNUMBER($B$54)),O${r}*$B$54,"输入无效")`);
 fx('路线经济',`Q${r}`,`=IF(AND(ISNUMBER(O${r}),ISNUMBER($C$54)),O${r}*$C$54,"输入无效")`);
});
sheets['路线经济'].getRange('B6:J11').setNumberFormat('0.00');sheets['路线经济'].getRange('K6:L11').setNumberFormat('0.0%');sheets['路线经济'].getRange('M6:M11').setNumberFormat('0.00');sheets['路线经济'].getRange('J6:J11').conditionalFormats.add('cellIs',{operator:'lessThan',formula:0,format:{fill:C.error,font:{color:C.red}}});sheets['路线经济'].getRange('M6:M11').conditionalFormats.add('cellIs',{operator:'lessThan',formula:0,format:{fill:C.error,font:{color:C.red}}});
sheets['路线经济'].getRange(`E19:H${rewardEnd}`).setNumberFormat('0.000');sheets['路线经济'].getRange(`I19:I${rewardEnd}`).setNumberFormat('0.0%');sheets['路线经济'].getRange('B54:C57').setNumberFormat('0.00');sheets['路线经济'].getRange('A1:A185').format.columnWidth=25;sheets['路线经济'].getRange('B1:N185').format.columnWidth=17;
sheets['路线经济'].getRange('N6:Q11').setNumberFormat('0.00');sheets['路线经济'].getRange('O1:Q185').format.columnWidth=19;sheets['路线经济'].getRange('R1:R185').format.columnWidth=31;

// Seasonal XP track: both time-averaged and integer attempts per day.
title('赛季进度','赛季等级与游玩预算',13,130);
note('赛季进度','A4','周契约均摊且按输入完成率计算。日数是条件期望，不是保证；真实胜率与地图时间待实测。');
block('赛季进度',5,['项目','连续均摊','每日整局','单位'],[
 ['每次完整R1成功XP',null,null,'XP'],['失败前有效清怪XP',null,null,'XP'],['每日尝试次数',null,null,'次'],['每日对局XP期望',null,null,'XP'],['每日契约XP均摊',null,null,'XP'],['每日总XP期望',null,null,'XP'],['当季30级总XP',null,null,'XP'],['达到30级期望天数',null,null,'天'],['季内30级可达性',null,null,'条件均值判断']
]);
fx('赛季进度','B6',`=SUMPRODUCT('参数'!$I$75:$I$78,'参数'!$J$75:$J$78)+${p.extractXp}`);fx('赛季进度','C6','=B6');fx('赛季进度','B7',`=${p.failedAttemptXp}`);fx('赛季进度','C7','=B7');fx('赛季进度','B8',`=${refs.attempts}`);fx('赛季进度','C8',`=${refs.wholeAttempts}`);
for(const c of ['B','C']){
 fx('赛季进度',`${c}9`,`=IF(ISNUMBER(${c}8),${c}8*(${p.extractionRate}*${c}6+(1-${p.extractionRate})*${c}7),"缺少有效时长")`);
 fx('赛季进度',`${c}10`,`=${p.weeklyContractCount}*${p.weeklyContractXp}*${p.contractCompletionFraction}/7`);
 fx('赛季进度',`${c}11`,`=IF(ISNUMBER(${c}9),${c}9+${c}10,"缺少有效时长")`);
 fx('赛季进度',`${c}12`,'=SUM($D$20:$D$49)');fx('赛季进度',`${c}13`,`=IF(ISNUMBER(${c}11),IF(${c}11=0,"无法达到",${c}12/${c}11),"缺少有效时长")`);
 fx('赛季进度',`${c}14`,`=IF(ISNUMBER(${c}13),IF(${c}13<=${p.seasonDays},"均值季内可达","均值季内不足"),"无法判断")`);
}
block('赛季进度',19,['目标等级','42日基础XP','季长费用系数','当季逐级XP','累计XP','均摊期望日','整局期望日'],Array.from({length:30},(_,i)=>[i+1,null,null,null,null,null,null]));
for(let r=20;r<=49;r++){
 fx('赛季进度',`B${r}`,`=${p.firstLevelXp}+(A${r}-1)*${p.stepXp}`);fx('赛季进度',`C${r}`,`=MIN(1,${p.seasonDays}/${p.baseSeasonDays})`);fx('赛季进度',`D${r}`,`=ROUNDUP(B${r}*C${r},0)`);fx('赛季进度',`E${r}`,`=SUM($D$20:D${r})`);
 for(const [dst,dc] of [['F','B'],['G','C']])fx('赛季进度',`${dst}${r}`,`=IF(ISNUMBER($${dc}$11),IF($${dc}$11=0,"无法达到",E${r}/$${dc}$11),"缺少有效时长")`);
}
block('赛季进度',54,['自然日','均摊累计XP','整局累计XP','30级目标XP','均摊等级','整局等级'],Array.from({length:60},(_,i)=>[i+1,null,null,null,null,null]));
for(let r=55;r<=114;r++){
 for(const [dst,dc] of [['B','B'],['C','C']])fx('赛季进度',`${dst}${r}`,`=IF(A${r}>${p.seasonDays},"",IF(ISNUMBER($${dc}$11),MIN($B$12,A${r}*$${dc}$11),"缺少有效时长"))`);
 fx('赛季进度',`D${r}`,`=IF(A${r}>${p.seasonDays},"",$B$12)`);
 for(const [dst,dc] of [['E','B'],['F','C']])fx('赛季进度',`${dst}${r}`,`=IF(A${r}>${p.seasonDays},"",IF(ISNUMBER(${dc}${r}),COUNTIFS($E$20:$E$49,"<="&${dc}${r}),"缺少有效时长"))`);
}
sheets['赛季进度'].getRange('B6:C13').setNumberFormat('0.00');sheets['赛季进度'].getRange('C20:C49').setNumberFormat('0.0%');sheets['赛季进度'].getRange('F20:G49').setNumberFormat('0.00');sheets['赛季进度'].getRange('B55:D114').setNumberFormat('#,##0');
sheets['赛季进度'].getRange('B14:C14').conditionalFormats.add('containsText',{text:'不足',format:{fill:C.error,font:{color:C.red,bold:true}}});
chart('赛季进度','line',['A54:A114','B54:B114','C54:C114','D54:D114'],'I6','N20','赛季XP条件期望','#,##0');
sheets['赛季进度'].getRange('A1:A130').format.columnWidth=29;sheets['赛季进度'].getRange('B1:G130').format.columnWidth=19;
note('赛季进度','I23','60日不增加强化或XP费用。');note('赛季进度','I25','30日按30/42逐级ceil。');note('赛季进度','I27','失败假设清完4外层；死亡本身不发XP。');note('赛季进度','I29','周契约时点未离散模拟。');

// Implementation handoff fields; CSV source tables are delivered separately.
title('配置字段','赛季配置与实现字段',5,50);
note('配置字段','A4','延用五行元数据与Protobuf发布链。这里列字段职责，不代表接口或迁移已实现。');
block('配置字段',5,['表或对象','关键字段','使用时机','约束','状态'],[
 ['SeasonDefinitions','season_id, starts_at, ends_at, timezone, ruleset_id, config_version','大厅/准备/开房','自然日统一服务端时间，旧房绑定入房版本','新增提案'],
 ['DifficultyRules','difficulty_id, hp_scale, shield_scale, damage_scale, interval_scale, reward_scales, entry_quality_cap, card_effective_level_cap, weapon_effective_level_cap','开房锁定','HP/盾floor，阶段比例随HP；PVE/PVP等级取实际与档位帽较小值，借用不入永久','新增提案'],
 ['LootRules扩展','difficulty_id, layer_id, quality_weights, quality_cap, promotion_cap','清格生成候选','概率和1；健康/匣灵升档不叠加；自然橙不降级','扩展提案'],
 ['SeasonThemes','theme_id, element_weights, encounter_profile_id, pvp_policy_id','开房/奖励','元素偏好玩家可选；主题不能无限乘伤','新增提案'],
 ['EquipmentCosts','quality_id, level, fragment_cost, same_quality_item_cost','强化报价与事务','+4/+5同品质材料保留，专武价格独立','调整提案'],
 ['PlayerSeasonState','player_id, season_id, xp, level, highest_difficulty, version','进度/难度解锁','同玩家同赛季唯一，幂等结算','新增提案'],
 ['CraftPityCounters','player_id, season_id, quality, slot, element, wish_affix, attempts','定向打造','同组最多3次保证心愿词缀；刷新/交易/遗物不推进','新增提案'],
 ['SeasonTokenRules','source, difficulty_id, tokens, per_run_cap, target_cost','撤离结算','D1蓝图章、D2起橙图章；只可向低级抵扣','新增提案'],
 ['资产与市场扩展','origin_season_id, asset_scope, source_match_id, loot_rule_id','准备/市场/强化/结算','旧季资金或装备不可经市场流入新季','新增提案'],
 ['SeasonArchiveJobs','season_id, asset_id, from_scope, to_scope, state, request_id','季末归档','先处理资产托管与旧房结算，再幂等归档','新增提案'],
 ['遥测事件','season_id, difficulty_id, class, build_bucket, human_or_bot, result','战斗/掉落/结算','区分候选/选择/带出/转移/销毁；低基数指标标签','扩展提案'],
 ['配置发布','field, type, required, target, description','Excel前五行，第六行数据','首列稳定主键；两端同字节Protobuf与SHA-256','现有链路'],
]);
sheets['配置字段'].getRange('A1:A50').format.columnWidth=27;sheets['配置字段'].getRange('B1:B50').format.columnWidth=64;sheets['配置字段'].getRange('C1:C50').format.columnWidth=22;sheets['配置字段'].getRange('D1:D50').format.columnWidth=62;sheets['配置字段'].getRange('E1:E50').format.columnWidth=17;sheets['配置字段'].getRange('A6:E17').format.wrapText=true;sheets['配置字段'].getRange('A6:E17').format.rowHeight=58;
note('配置字段','A20','真实战斗回归：三职业、流派、阶段、难度、怪组矩阵；机器人简化PVE不能代替CombatService模拟。');
note('配置字段','A22','季末边界：旧房跨季撤离、重复归档、满仓托管、市场退回、结算Pending重试、冷启动恢复。');
note('配置字段','A24','本工作簿仅完成文档与算术校验。尚未运行游戏代码、负载测试或完整真实战斗模拟。');

// Overview links only to owning builds.
title('总览','遗境行者赛季数值测算',13,56);sheets['总览'].tabColor=C.accent;
note('总览','A4','v2候选基线 2026-11-02。新增红周配额、双币市场、商店活动与全服账；真实对局未验证。');
block('总览',5,['核心指标','当前结果','单位','范围'],[
 ['赛季长度',null,'自然日','30至60日，默认42'],
 ['选中难度',null,'档','难度与地图层级分别配置'],
 ['常规1橙4紫强化重建',null,'碎片','未含重铸与本体，目标等级见参数'],
 ['极限1橙4紫全+5',null,'碎片','未计同品质材料与装备本体'],
 ['选中难度每成功路线碎片',null,'碎片','给定R1坐标条件路线'],
 ['仅强化均摊每日净碎片',null,'碎片/日','扣死亡整套强化重建的片段模型'],
 ['仅强化整局每日净碎片',null,'碎片/日','每日尝试数向下取整'],
 ['当季30级总XP',null,'XP','基准200起，每级+15'],
 ['达到30级均摊期望',null,'天','周契约按输入完成率均摊'],
 ['达到30级整局期望',null,'天','不保证实际季内完成'],
 ['指定效果橙保底上限',null,'次成功撤离','D2起；同品质/部位/元素3次打造'],
 ['顶配三卡伤害',null,'点','只含基础增伤，不含效果套'],
 ['顶配吞吐代理',null,'倍','不是DPS或胜率'],
 ['含模板重铸均摊每日净碎片',null,'碎片/日','仅碎片账；装备本体和金币须另验'],
 ['常规强化加模板重铸',null,'碎片','需消耗真实同品质本体，结果+0'],
 ]);
const overviewFormulas=[`=${p.seasonDays}`,`=INDEX('参数'!$A$65:$A$70,${p.selectedDifficultyIndex}+1)`,`=${refs.rebuild}`,`=${refs.full5}`,`=INDEX('路线经济'!$E$6:$E$11,${p.selectedDifficultyIndex}+1)`,`=INDEX('路线经济'!$J$6:$J$11,${p.selectedDifficultyIndex}+1)`,`=INDEX('路线经济'!$M$6:$M$11,${p.selectedDifficultyIndex}+1)`,"='赛季进度'!B12","='赛季进度'!B13","='赛季进度'!C13","='掉落概率'!B42","='成长与装备'!H11","='成长与装备'!I11",`=INDEX('路线经济'!$P$6:$P$11,${p.selectedDifficultyIndex}+1)`,`=${refs.rebuildWithReforge}`];
overviewFormulas.forEach((f,i)=>fx('总览',`B${6+i}`,f));sheets['总览'].getRange('B6:B20').setNumberFormat('0.00');
block('总览',22,['阶段与难度','吞吐代理','怪物HP倍率'],data.builds.map((b,i)=>[`${b.id} / ${b.difficulty}`,null,null]));
for(let i=0;i<6;i++){fx('总览',`B${23+i}`,`='成长与装备'!I${6+i}`);fx('总览',`C${23+i}`,`='难度与怪物'!C${6+i}`);}sheets['总览'].getRange('B23:C28').setNumberFormat('0.00"x"');
chart('总览','line',['A22:A28','B22:B28','C22:C28'],'F6','M22','成长代理与怪物HP倍率','0.0"x"');
note('总览','F25','属性倍率匹配不证明战斗平衡。');note('总览','F27','PVE/PVP、控制、回血与返牌仍需实战模拟。');note('总览','F29','D0/D1不产橙；同套重建仅做压力比较。');note('总览','F31','每服自然周最多1红；D5无红装硬门槛。');
note('总览','A33','掉落到养成之间还包含选择、撤离、死亡损失、交易和强化材料消耗。');
note('总览','A35','固定R1为5外层、1中层、1精英、1Boss；18分钟和70%撤离率都是待测假设。');
sheets['总览'].getRange('A1:A43').format.columnWidth=36;sheets['总览'].getRange('B1:B43').format.columnWidth=18;sheets['总览'].getRange('C1:C43').format.columnWidth=15;sheets['总览'].getRange('D1:D43').format.columnWidth=49;

// v2 expansion. All four new sheets use editable source controls and formulas.
const vr={}; const sp={}; const ev={}; const mk={}; const rr={}; const gr={};
function probability(name,cell){sheets[name].getRange(cell).dataValidation={rule:{type:'decimal',operator:'between',formula1:0,formula2:1}};}
function warning(name,range){sheets[name].getRange(range).conditionalFormats.add('containsText',{text:'检查',format:{fill:C.error,font:{color:C.red,bold:true}}});}
function simpleInputs(name,row,rows,registry){
 block(name,row,['项目','当前值','单位','口径'],rows.map(x=>[x[1],x[2],x[3],x[4]]));
 rows.forEach((x,i)=>{const r=row+i+1;registry[x[0]]=ref(name,`$B$${r}`);input(name,`B${r}`,x[2],x[3]==='比例'?'0.0%':'0.00');if(x[3]==='比例')probability(name,`B${r}`);});
}

title('商店与活动','普通商店、活动与三选一补充',10,195);
note('商店与活动','A4','普通商店价格沿用GDD；购买频率、活动与选择率为候选假设。资源和金币必须同时入账。');
simpleInputs('商店与活动',5,[
 ['gearChoice','装备选择率',v2.assumptions.gearChoiceRate,'比例','链接原参数；三选一总和必须为1'],
 ['fragmentChoice','碎片选择率',v2.assumptions.fragmentChoiceRate,'比例','不能把未选装备的25%全部算碎片'],
 ['healChoice','回血选择率',v2.assumptions.healChoiceRate,'比例','与装备、碎片互斥'],
 ['doubleBias','选碎时2倍条件率',v2.assumptions.doubleFragmentBiasRate,'比例','健康且高价值；与成功率独立仅为近似'],
 ['potions','购药/每尝试',v2.assumptions.potionsPerAttempt,'瓶','玩家群平均频率；不是单局必用数量'],
 ['refreshFirst','使用第1次刷新率',v2.assumptions.refreshFirstRate,'比例','第1次≥第2次≥第3次'],
 ['refreshSecond','使用第2次刷新率',v2.assumptions.refreshSecondRate,'比例','次数为嵌套事件，分别付60/180/450'],
 ['refreshThird','使用第3次刷新率',v2.assumptions.refreshThirdRate,'比例','所有刷新仍受每人每局3次限制'],
 ['advancedUse','高级包使用率',v2.assumptions.advancedBagUseRate,'比例','稳态替换成本；初始购买另需资金'],
 ['topUse','顶级包使用率',v2.assumptions.topBagUseRate,'比例','高级与顶级使用率之和≤1'],
 ['recovery','死亡旧装最终回收率',v2.assumptions.deadGearRecoveredRate,'比例','被任何人成功带出都算回收，不能当销毁'],
],sp);
fx('商店与活动','B6',`=${p.gearChoiceRate}`);sheets['商店与活动'].getRange('B6').format.fill=C.band;
val('商店与活动','A18','分支与频率检查');fx('商店与活动','B18',`=IF(AND(ABS(B6+B7+B8-1)<0.000000001,MIN(B6:B16)>=0,MAX(B6:B9)<=1,MAX(B11:B16)<=1,B11>=B12,B12>=B13,B14+B15<=1),"有效","检查输入")`);warning('商店与活动','B18');sp.status=ref('商店与活动','$B$18');
val('商店与活动','A19','每日完整尝试');fx('商店与活动','B19',`=IF(ISNUMBER(${refs.wholeAttempts}),${refs.wholeAttempts},0)`);sp.attempts=ref('商店与活动','$B$19');
note('商店与活动','A21','金币商店UTC+8 04:00日切。日均0.5卡包表示群体频率；药剂仓库8、带入2，付费包库存合计3。');
block('商店与活动',23,['商品ID','商品','金币单价','单包单位','每日限购','日均购买','资源/日','金币回收/日','资源性质','输入检查'],v2.shops.map(x=>[x.id,x.name,x.priceGold,x.units,x.dailyLimit,x.defaultPacksPerDay,null,null,x.resource,null]));
const shopRows={};v2.shops.forEach((x,i)=>{const r=24+i;shopRows[x.id]=r;['C','D','F'].forEach(c=>sheets['商店与活动'].getRange(`${c}${r}`).format.fill=C.input);if(x.dailyLimit!==null)sheets['商店与活动'].getRange(`E${r}`).format.fill=C.input;fx('商店与活动',`G${r}`,`=D${r}*F${r}`);fx('商店与活动',`H${r}`,`=C${r}*F${r}`);fx('商店与活动',`J${r}`,`=IF(AND(C${r}>0,D${r}>0,F${r}>=0,IF(ISNUMBER(E${r}),AND(E${r}>=0,F${r}<=E${r}),TRUE)),"有效","检查限购")`);});
fx('商店与活动','F28',`=${sp.attempts}*${sp.potions}`);
fx('商店与活动','F29',`=${sp.attempts}*(1-${p.extractionRate})*${sp.advancedUse}`);
fx('商店与活动','F30',`=${sp.attempts}*(1-${p.extractionRate})*${sp.topUse}`);
sheets['商店与活动'].getRange('F28:F30').format.fill=C.white;
val('商店与活动','G31','合计回收');fx('商店与活动','H31','=SUM(H24:H30)');
sheets['商店与活动'].getRange('C24:H31').setNumberFormat('0.00');warning('商店与活动','J24:J30');
sp.fragmentDaily=ref('商店与活动','$G$24');sp.fragmentPrice=ref('商店与活动','$C$24');sp.fragmentUnits=ref('商店与活动','$D$24');sp.shopResourceGold="SUM('商店与活动'!$H$24:$H$27)";sp.potionGold=ref('商店与活动','$H$28');sp.bagGold="SUM('商店与活动'!$H$29:$H$30)";
note('商店与活动','A33','碎片120金买20个=6金/碎购买成本；不可卖回金币。卡包250金3张，白/绿/蓝/紫=50/30/15/5。');
note('商店与活动','A35','新增普通商店资源不再乘撤离率；买包扣金必须同步，市场卖装款属于玩家间转移。');
simpleInputs('商店与活动',39,[
 ['count','赛季活动次数',v2.events.count,'次','默认42天两期，不按每日常驻福利计'],
 ['duration','每期活动天数',v2.events.durationDays,'天','用来比较均摊与集中领取峰值'],
 ['tokens','每期徽记上限',v2.events.tokensPerEvent,'枚','账号+赛季+活动；不可交易与跨期滚存'],
 ['participation','符合资格账号参与率',v2.events.participationRate,'比例','假设，必须用实际资格分母'],
 ['completion','参与者拿满12章比例',v2.events.completionFraction,'比例','余者本例不兑换；不是人人平均进度80%'],
 ['redemption','完成者兑换比例',v2.events.redemptionRate,'比例','只作用于兑换奖励'],
 ['coverage','兑换覆盖比例',0,'比例','参与×完成×兑换，计算值'],
 ['directGold','每完成活动直接金币',v2.events.directGoldPerCompletedEvent,'金','压力输入；默认0，不是现有活动承诺'],
 ['directDiamond','每完成活动直接钻石',v2.events.directDiamondsPerCompletedEvent,'钻','压力输入；默认0'],
 ['directPurple','每完成活动直接紫本体',v2.events.directPurpleBodiesPerCompletedEvent,'件','压力输入；默认0，不可学模板'],
 ['directOrange','每完成活动直接橙本体',v2.events.directOrangeBodiesPerCompletedEvent,'件','压力输入；默认0，不可学模板'],
 ['directRed','每完成活动直接红本体',v2.events.directRedBodiesPerCompletedEvent,'件','保持0；任何红发放必须单独占同周配额'],
],ev);
fx('商店与活动','B46','=B43*B44*B45');sheets['商店与活动'].getRange('B46').format.fill=C.white;sheets['商店与活动'].getRange('B51').format.fill=C.band;
block('商店与活动',55,['选项ID','兑换资源','单次耗章','单次奖励','单期次数帽','选择次数','合计耗章','本期实得','选项检查'],v2.events.branches.map(b=>[b.id,b.reward,b.tokenCost,b.rewardCount,b.limitPerEvent??null,b.id===v2.events.defaultBranch?Math.floor(v2.events.tokensPerEvent/b.tokenCost):0,null,null,null]));
v2.events.branches.forEach((b,i)=>{const r=56+i;sheets['商店与活动'].getRange(`C${r}:D${r}`).format.fill=C.input;sheets['商店与活动'].getRange(`F${r}`).format.fill=C.input;fx('商店与活动',`G${r}`,`=C${r}*F${r}`);fx('商店与活动',`H${r}`,`=D${r}*F${r}`);fx('商店与活动',`I${r}`,`=IF(AND(C${r}>0,D${r}>=0,F${r}>=0,F${r}=INT(F${r}),IF(ISNUMBER(E${r}),F${r}<=E${r},TRUE)),"有效","检查兑换")`);});
val('商店与活动','A61','徽记预算检查');fx('商店与活动','B61','=SUM(G56:G59)');fx('商店与活动','C61','=B42-B61');fx('商店与活动','D61','=IF(AND(B61<=B42,COUNTIF(I56:I59,"检查兑换")=0,MIN(B43:B45)>=0,MAX(B43:B45)<=1,MIN(B47:B51)>=0,B51=0,B40>=0,B41>0,B42>=0),"有效","检查活动预算")');warning('商店与活动','D61');warning('商店与活动','I56:I59');ev.status=ref('商店与活动','$D$61');
block('商店与活动',64,['资源','每期满额实得','整季满额','每资格账号季期望','季均摊/日','单期集中日峰值','活动日均摊'],v2.events.branches.map(b=>[b.reward,null,null,null,null,null,null]));
for(let i=0;i<4;i++){const r=65+i,br=56+i;fx('商店与活动',`B${r}`,`=H${br}`);fx('商店与活动',`C${r}`,`=B${r}*B$40`);fx('商店与活动',`D${r}`,`=C${r}*B$46`);fx('商店与活动',`E${r}`,`=D${r}/${p.seasonDays}`);fx('商店与活动',`F${r}`,`=B${r}*B$46`);fx('商店与活动',`G${r}`,`=F${r}/B$41`);}
sheets['商店与活动'].getRange('B65:G68').setNumberFormat('0.0000');ev.fragmentDay=ref('商店与活动','$E$65');ev.fragmentSeason=ref('商店与活动','$D$65');
note('商店与活动','A70','四兑换选项共用12章，不能叠满。绑定碎片可加工进可交易成品；不把所有强化装备自动绑定。');
block('商店与活动',72,['层级','路线格数','基础单格碎片','2倍单格碎片','按条件率混合'],data.layers.map(l=>[l.name,null,null,null,null]));
block('商店与活动',84,['基础整数','选中难度2倍后floor'],Array.from({length:101},(_,i)=>[i,null]));
for(let r=85;r<=185;r++)fx('商店与活动',`B${r}`,`=ROUNDDOWN(ROUND(A${r}*INDEX('参数'!$I$65:$I$70,${p.selectedDifficultyIndex}+1)*2,10),0)`);
data.layers.forEach((l,i)=>{const r=73+i,lr=75+i;fx('商店与活动',`B${r}`,`='参数'!J${lr}`);fx('商店与活动',`C${r}`,`=INDEX('路线经济'!$H$19:$H$42,${p.selectedDifficultyIndex}*4+${i+1})`);fx('商店与活动',`D${r}`,`=SUMIFS($B$85:$B$185,$A$85:$A$185,">="&'参数'!G${lr},$A$85:$A$185,"<="&'参数'!H${lr})/('参数'!H${lr}-'参数'!G${lr}+1)`);fx('商店与活动',`E${r}`,`=(1-${sp.doubleBias})*C${r}+${sp.doubleBias}*D${r}`);});
val('商店与活动','A77','整条条件路线');for(const c of ['C','D','E'])fx('商店与活动',`${c}77`,`=SUMPRODUCT($B$73:$B$76,${c}73:${c}76)`);
val('商店与活动','A79','额外碎片/每尝试');fx('商店与活动','B79',`=${p.extractionRate}*${sp.fragmentChoice}*E77`);
val('商店与活动','A80','额外碎片/每日整局');fx('商店与活动','B80',`=B79*${sp.attempts}`);sp.choicePerAttempt=ref('商店与活动','$B$79');sp.choicePerDay=ref('商店与活动','$B$80');
sheets['商店与活动'].getRange('C73:E77').setNumberFormat('0.0000');sheets['商店与活动'].getRange('B79:B80').setNumberFormat('0.00000');
note('商店与活动','A82','基础与三选一独立掷整数；先raw×难度倍率×1或2，最后floor。D2两倍期望86.5，不是40×2。');
sheets['商店与活动'].getRange('A1:A195').format.columnWidth=31;sheets['商店与活动'].getRange('B1:B195').format.columnWidth=24;sheets['商店与活动'].getRange('C1:H195').format.columnWidth=21;sheets['商店与活动'].getRange('I1:I195').format.columnWidth=36;sheets['商店与活动'].getRange('J1:J195').format.columnWidth=20;

title('红装周投放','独立红装周配额与候选成长',13,165);
note('红装周投放','A4','每逻辑服自然周最多生成1件，不保证必出。普通五色候选不含红，跨季/重启/死亡不退配额。');
simpleInputs('红装周投放',5,[
 ['quota','全渠道每服周配额',v2.red.weeklyQuota,'件','用户保留约束，固定1'],
 ['bossChance','合格Boss独立红判定',v2.red.bossChance,'比例','D2起；额外掉落，不替代三选一'],
 ['retention','红最终被任何人带出率',v2.red.finalRetainedFraction,'比例','生成不等于最终持有，待测'],
 ['weeks','对齐的完整自然周数',v2.red.alignedSeasonWeeks,'周','按floor(季长/7)；实际首尾周另枚举'],
 ['body4','红+4额外同品质本体',v2.red.extraBodiesFor4,'件','不可用橙装或活动万能材料'],
 ['body5','红+5额外同品质本体',v2.red.extraBodiesFor5,'件','本体1+材料2=共需3红'],
 ['chestChance','未来装备箱红概率',v2.red.chestChance,'比例','仅压力分支，默认不上架'],
 ['chestEnabled','装备箱压力分支开关',v2.red.chestEnabled?1:0,'0/1','0为关闭，不计入当前默认投放'],
 ['chestsPerWeek','若开启每周开箱数',v2.results.chestStress.weeklyChests,'箱','开箱先后影响唯一红的归属'],
 ['minimumDifficulty','Boss红判定最低难度',v2.red.minimumDifficulty,'D索引','新六档映射D2起'],
],rr);
sheets['红装周投放'].getRange('B6').format.fill=C.band;fx('红装周投放','B9',`=ROUNDDOWN(${p.seasonDays}/7,0)`);sheets['红装周投放'].getRange('B9').format.fill=C.white;
val('红装周投放','A18','配额与概率检查');fx('红装周投放','B18','=IF(AND(B6=1,MIN(B7:B8)>=0,MAX(B7:B8)<=1,B12>=0,B12<=1,OR(B13=0,B13=1),B9>=0,B9<=10,B9=INT(B9),B10>=0,B11>=0,B14>=0),"有效","检查红规则")');warning('红装周投放','B18');rr.status=ref('红装周投放','$B$18');
sheets['红装周投放'].getRange('B12').setNumberFormat('0.00%');
block('红装周投放',22,['每周合格Boss次数','每周生成概率','每周未生成','整季生成期望','整季最终带出期望','至少够1件+5概率','集中材料时+5期望上限','满产+5硬上限'],v2.red.bossKillsPerWeekCases.map(k=>[k,null,null,null,null,null,null,null]));
for(let i=0;i<v2.red.bossKillsPerWeekCases.length;i++){
 const r=23+i;input('红装周投放',`A${r}`,v2.red.bossKillsPerWeekCases[i],'0');
 fx('红装周投放',`B${r}`,`=1-(1-${rr.bossChance})^A${r}*(1-${rr.chestChance})^(${rr.chestEnabled}*${rr.chestsPerWeek})`);
 fx('红装周投放',`C${r}`,`=1-B${r}`);fx('红装周投放',`D${r}`,`=B${r}*${rr.weeks}`);fx('红装周投放',`E${r}`,`=D${r}*${rr.retention}`);
 fx('红装周投放',`F${r}`,`=SUMIFS($D$81:$D$157,$A$81:$A$157,${i+1},$C$81:$C$157,">="&(1+${rr.body4}+${rr.body5}))`);
 fx('红装周投放',`G${r}`,`=SUMIF($A$81:$A$157,${i+1},$F$81:$F$157)`);
 fx('红装周投放',`H${r}`,`=ROUNDDOWN(${rr.weeks}*${rr.quota}/(1+${rr.body4}+${rr.body5}),0)`);
}
sheets['红装周投放'].getRange('B23:C29').setNumberFormat('0.00%');sheets['红装周投放'].getRange('D23:E29').setNumberFormat('0.000');sheets['红装周投放'].getRange('F23:F29').setNumberFormat('0.00%');sheets['红装周投放'].getRange('G23:G29').setNumberFormat('0.0000');
chart('红装周投放','line',['A22:A29','B22:B29','C22:C29'],'F6','M20','每服每周：生成与未生成','0%');
block('红装周投放',33,['强化级','旧逐级碎片','候选42日逐级','当前季逐级','当前季累计','本级消耗红材料','累计物理红件','单件增伤','单件抗性','单件间隔减免'],Array.from({length:6},(_,i)=>[i,i?v2.red.legacyCosts[i-1]:0,i?v2.red.candidateCosts[i-1]:0,null,null,null,null,null,null,null]));
for(let r=34;r<=39;r++){
 fx('红装周投放',`D${r}`,`=ROUNDUP(C${r}*MIN(1,${p.seasonDays}/${p.baseSeasonDays}),0)`);fx('红装周投放',`E${r}`,`=SUM($D$34:D${r})`);fx('红装周投放',`F${r}`,`=IF(A${r}=4,${rr.body4},IF(A${r}=5,${rr.body5},0))`);fx('红装周投放',`G${r}`,`=1+SUM($F$34:F${r})`);
 fx('红装周投放',`H${r}`,`=$B$44+A${r}*$B$45`);fx('红装周投放',`I${r}`,`=$B$46+A${r}*$B$47`);fx('红装周投放',`J${r}`,`=$B$48+A${r}*$B$49`);
}
sheets['红装周投放'].getRange('C35:C39').format.fill=C.input;sheets['红装周投放'].getRange('H34:J39').setNumberFormat('0.0%');rr.redCost=ref('红装周投放','$E$39');
const redAttr=[
 ['damageBase','红+0元素增伤','比例'],['damagePerLevel','每级元素增伤','比例'],['resistBase','红+0抗性','比例'],['resistPerLevel','每级抗性','比例'],['speedBase','红+0间隔减免','比例'],['speedPerLevel','每级间隔减免','比例'],['fenYuanBonus','焚元额外增幅','比例'],['jiChouBonus','疾抽额外间隔减免','比例'],['drawFloor','疾抽最低间隔','秒'],['lianZhuChance','连珠概率','比例'],['shiYiExtraOpeningCard','拾遗开场额外牌','张'],['jinChanEscapeBonus','金蝉额外逃脱','比例'],
];
block('红装周投放',43,['候选属性/词缀','候选输入','旧独有词缀对照','口径'],redAttr.map(x=>[x[1],v2.red.candidate[x[0]],v2.red.legacyUnique[x[0]]??(x[0]==='drawFloor'?v2.red.legacyUnique.jiChouFloor:null),'候选，不代表已验证实战']));
redAttr.forEach((x,i)=>{input('红装周投放',`B${44+i}`,v2.red.candidate[x[0]],x[2]==='比例'?'0.0%':'0.00');if(x[2]==='比例')sheets['红装周投放'].getRange(`C${44+i}`).setNumberFormat('0.0%');});
note('红装周投放','A58','候选累计390碎只是碎片费；+5须本体加两材料共3红，不能用红配方重铸或材料券复制。');
note('红装周投放','A60','对齐6个自然周满产最多6红，全部集中为强化材料最多2件+5；概率表是全服供给，不是单人获得保证。');
note('红装周投放','A62','30/42/60日最多可触及6/7/10个周键；首尾与相邻赛季共享，按真实起止枚举，不是独立新增额度。');
note('红装周投放','A64','周一服务器时区04:00，配额不滚存。红进入临时背包/托管；死亡、遗物、交易与材料消耗均不返周额度。');
note('红装周投放','A66','所有红属性、独有词缀与390价均为本轮候选，尚未通过真实PVP仿真；普通成长样本未含红独有触发。');
const redDist=[];for(let i=0;i<7;i++)for(let k=0;k<=10;k++)redDist.push([i+1,null,k,null,null,null]);
block('红装周投放',80,['情景序','每周Boss','季内带出件数k','二项分布概率','可组成+5数','概率加权+5'],redDist);
let rd=81;for(let i=0;i<7;i++)for(let k=0;k<=10;k++){
 const r=rd++,sr=23+i;fx('红装周投放',`B${r}`,`=A${sr}`);fx('红装周投放',`D${r}`,`=IF(C${r}>${rr.weeks},0,COMBIN(${rr.weeks},C${r})*(B${sr}*${rr.retention})^C${r}*(1-B${sr}*${rr.retention})^(${rr.weeks}-C${r}))`);fx('红装周投放',`E${r}`,`=ROUNDDOWN(C${r}/(1+${rr.body4}+${rr.body5}),0)`);fx('红装周投放',`F${r}`,`=D${r}*E${r}`);
}
sheets['红装周投放'].getRange('A1:A165').format.columnWidth=32;sheets['红装周投放'].getRange('B1:J165').format.columnWidth=23;sheets['红装周投放'].getRange('D1:D165').format.columnWidth=38;

title('双币市场','金币/钻石市场与材料流通',14,90);
note('双币市场','A4','两种货币分账；永久钻石可买本季橙红，季金币/装备/订单隔离。同件仅一个币种一个挂单。');
simpleInputs('双币市场',5,[
 ['goldTax','金币卖家税率',v2.market.taxRateGold,'比例','逐笔floor，最低手续费另列'],
 ['diamondTax','钻石卖家税率',v2.market.taxRateDiamond,'比例','买家付标价，卖家得税后同币种'],
 ['minFee','最低手续费',v2.market.minFee,'单位','每种币各自整数单位'],
 ['slots','两币共享挂单栏',v2.market.listingSlotsShared,'个','挂单是托管，不是销毁'],
 ['hours','挂单有效时间',v2.market.listingDurationHours,'小时','到期返还同一件'],
 ['goldCap','金币标价上限',v2.market.goldPriceCap,'金','白至红均适用'],
 ['orangeDiamondCap','橙装钻石标价上限',v2.market.orangeDiamondCap,'钻','白绿蓝紫不得钻价'],
 ['redDiamondCap','红装钻石标价上限',v2.market.redDiamondCap,'钻','红交易不生成新物品'],
 ['goldTrades','每千尝试金币成交数',v2.assumptions.goldTradesPer1000Attempts,'笔','群体压力输入，不是实测'],
 ['goldPrice','金币平均成交价',v2.assumptions.goldTradePrice,'金','用于全服税收；个体售价另有示例'],
 ['diamondTrades','每千尝试钻石成交数',v2.assumptions.diamondTradesPer1000Attempts,'笔','成交依赖既有钻石余额'],
 ['diamondPrice','钻石平均成交价',v2.assumptions.diamondTradePrice,'钻','不把成交额当钻石新增'],
 ['marketEligible','新带出装备进入挂单率',v2.assumptions.marketEligibleFraction,'比例','同时符合交易资格且实际挂牌的综合比例'],
 ['unusedRecipe','挂单样本仍未提取率',v2.assumptions.recipeSampleUnusedFraction,'比例','同一原始item只可学一次'],
 ['population','当前逻辑服活跃人数',v2.assumptions.activePlayers,'人','不是自动跨服务器合池'],
 ['fxEnabled','NPC钻兑金开关',v2.market.npcFxEnabled?1:0,'0/1','默认0；启用需独立经济评审'],
],mk);
sheets['双币市场'].getRange('B21').format.fill=C.band;
val('双币市场','A23','市场参数检查');fx('双币市场','B23','=IF(AND(MIN(B6:B7)>=0,MAX(B6:B7)<=1,B8>=1,MIN(B9:B17)>=0,B15=INT(B15),B17=INT(B17),B15>=B8,B17>=B8,B15<=B11,B17<=B13,B18>=0,B18<=1,B19>=0,B19<=1,B21=0),"有效","检查市场参数")');warning('双币市场','B23');mk.status=ref('双币市场','$B$23');
block('双币市场',25,['品质','金币允许','金币上限','钻石允许','钻石上限'],['white','green','blue','purple','orange','red'].map(x=>[x,1,null,v2.market.allowed[x].includes('diamond')?1:0,null]));
for(let r=26;r<=31;r++){fx('双币市场',`C${r}`,`=${mk.goldCap}`);fx('双币市场',`E${r}`,r===30?`=${mk.orangeDiamondCap}`:r===31?`=${mk.redDiamondCap}`:'=0');}
block('双币市场',34,['装备品质','标价币种','买家标价','税率','手续费','卖家实得','合法性'],[['white','gold',9,null,null,null,null],['purple','gold',1000,null,null,null,null],['orange','diamond',2000,null,null,null,null],['red','diamond',8000,null,null,null,null]]);
for(let r=35;r<=38;r++){
 sheets['双币市场'].getRange(`A${r}:C${r}`).format.fill=C.input;
 fx('双币市场',`G${r}`,`=IF(AND(COUNTIF($A$26:$A$31,A${r})=1,OR(B${r}="gold",B${r}="diamond"),ISNUMBER(C${r}),C${r}=INT(C${r}),C${r}>=${mk.minFee},IF(B${r}="gold",C${r}<=${mk.goldCap},IF(A${r}="orange",C${r}<=${mk.orangeDiamondCap},IF(A${r}="red",C${r}<=${mk.redDiamondCap},FALSE)))),"有效","检查币种/价格")`);
 fx('双币市场',`D${r}`,`=IF(B${r}="gold",${mk.goldTax},${mk.diamondTax})`);
 fx('双币市场',`E${r}`,`=IF(G${r}="有效",MAX(${mk.minFee},ROUNDDOWN(ROUND(C${r}*D${r},10),0)),"输入无效")`);
 fx('双币市场',`F${r}`,`=IF(ISNUMBER(E${r}),C${r}-E${r},"输入无效")`);
}
sheets['双币市场'].getRange('D35:D38').setNumberFormat('0%');warning('双币市场','G35:G38');
block('双币市场',42,['品质','假设本体价','强化至+3碎片','模板重铸碎片','合计绑定碎片','购碎单位金币','成本合计','至少卖价回本'],[['purple',v2.assumptions.examplePurpleBodyPriceGold,null,data.rebuild.reforgePurpleCost,null,null,null,null],['orange',v2.assumptions.exampleOrangeBodyPriceGold,null,data.rebuild.reforgeOrangeCost,null,null,null,null]]);
for(const r of [43,44]){
 sheets['双币市场'].getRange(`B${r}`).format.fill=C.input;sheets['双币市场'].getRange(`D${r}`).format.fill=C.input;
 fx('双币市场',`C${r}`,`=SUMIFS('成长与装备'!$E$33:$E$57,'成长与装备'!$A$33:$A$57,A${r},'成长与装备'!$B$33:$B$57,"<=3")`);
 fx('双币市场',`E${r}`,`=C${r}+D${r}`);fx('双币市场',`F${r}`,`=${sp.fragmentPrice}/${sp.fragmentUnits}`);fx('双币市场',`G${r}`,`=B${r}+E${r}*F${r}`);
 fx('双币市场',`H${r}`,`=IF(${mk.goldTax}>=1,"无有限回本价",MAX(1,ROUNDUP(G${r},0)+${mk.minFee},ROUNDDOWN((ROUNDUP(G${r},0)-1)/(1-${mk.goldTax}),0)+1))`);
}
fx('参数','B45',"=4*'双币市场'!D43+'双币市场'!D44");sheets['参数'].getRange('B45').format.fill=C.white;val('参数','D45','由双币市场紫/橙重铸分项计算，消耗真实本体');
note('双币市场','A46','6金/碎是限购商店替代成本，非回购价；示例加工费不保证市场接受，实际售价须看成交。');
block('双币市场',48,['逻辑服活跃数','目标橙新挂单/日','48h至少一新挂单','未提取样本/日','48h至少一新样本'],v2.results.marketDepth.map(d=>[d.activePlayers,null,null,null,null]));
for(let i=0;i<v2.results.marketDepth.length;i++){
 const r=49+i;input('双币市场',`A${r}`,v2.results.marketDepth[i].activePlayers,'0');
 fx('双币市场',`B${r}`,`=A${r}*${sp.attempts}*INDEX('路线经济'!$F$6:$F$11,${p.selectedDifficultyIndex}+1)*${p.gearChoiceRate}*${p.extractionRate}*${p.targetElementWeight}*${p.targetEffectWeight}*${p.targetSlotWeight}*${mk.marketEligible}`);
 fx('双币市场',`C${r}`,`=1-EXP(-B${r}*${mk.hours}/24)`);fx('双币市场',`D${r}`,`=B${r}*${mk.unusedRecipe}`);fx('双币市场',`E${r}`,`=1-EXP(-D${r}*${mk.hours}/24)`);
}
sheets['双币市场'].getRange('B49:B53').setNumberFormat('0.0000');sheets['双币市场'].getRange('D49:D53').setNumberFormat('0.0000');sheets['双币市场'].getRange('C49:C53').setNumberFormat('0.0%');sheets['双币市场'].getRange('E49:E53').setNumberFormat('0.0%');
chart('双币市场','line',['A48:A53','C48:C53','E48:E53'],'G48','N64','新挂单到达概率（非成交率）','0%');
note('双币市场','A56','Poisson到达近似；不含价格、竞争、已有库存或卖方惜售，不保证买得到。');
note('双币市场','A58','不可上架：魂、碎片、印记、活动章、卡、专武、包、药、借用与绑定装备。真实装备可当材料。');
note('双币市场','A60','仅原始自然掉落/正常打造且未提取的紫橙可登记一次；交易继承标记，重铸、红、活动材料/Bot不可学。');
note('双币市场','A70','重铸继承本体绑定与季限制；借用、Bot投影、活动纯材料不能当可穿戴重铸本体，不能洗掉禁交易。');
note('双币市场','A62','绑定碎片加工成合法可交易装备是有成本加工，不是碎片可直接转账；不自动把所有强化成品绑定。');
note('双币市场','A66','NPC兑金默认关闭。旧1钻=20金×每日5000钻=10万金，只作风险对照，不自动进入全服来源。');
note('双币市场','A68','钻石交易依赖永久余额；两次跨币转售各扣税，没有系统承诺固定汇率或保价。');
sheets['双币市场'].getRange('A1:A90').format.columnWidth=33;sheets['双币市场'].getRange('B1:C90').format.columnWidth=23;sheets['双币市场'].getRange('D1:D90').format.columnWidth=39;sheets['双币市场'].getRange('E1:H90').format.columnWidth=24;

title('全服资源账','全服资源：新增、转移与真实销毁',15,95);
note('全服资源账','A4','默认每1000次尝试；自然新装仅计带出，死亡旧装回收是转移。新增打造默认0，片账和本体账分别核对。');
simpleInputs('全服资源账',5,[
 ['batch','尝试批次',v2.results.globalCurrencies.attempts,'次','同一逻辑服与当前赛季'],
 ['playerDays','等效活跃人日',0,'人日','批次/每日完整局数，计算值'],
 ['attempts','每人每日完整局数',v2.assumptions.attemptsPerDay,'次','链接时长，不用60/18均摊'],
 ['difficulty','当前难度',v2.assumptions.difficultyIndex,'D索引','此1橙4紫负荷仅D2起合法'],
 ['recovery','旧装最终回收率',v2.assumptions.deadGearRecoveredRate,'比例','链接商店与活动输入'],
 ['purpleUpgrades','每千尝试紫+3升+5数',v2.assumptions.upgradePurpleFrom3To5Per1000Attempts,'件','每件另外吞2个紫材料、120碎（42日）'],
 ['orangeUpgrades','每千尝试橙+3升+5数',v2.assumptions.upgradeOrangeFrom3To5Per1000Attempts,'件','每件另外吞2个橙材料、240碎（42日）'],
 ['diamondGrant','每千尝试系统赠钻',v2.assumptions.diamondSystemGrantPer1000Attempts,'钻','默认0，无数据不能称钻石供应健康'],
 ['diamondTopup','每千尝试充值钻石',v2.assumptions.diamondTopupsPer1000Attempts,'钻','默认0，仅预算输入'],
 ['diamondCosmetics','每千尝试外观耗钻',v2.assumptions.diamondCosmeticsSinkPer1000Attempts,'钻','默认0，不自动开放新商城'],
 ['purpleCraft','每千尝试新增打造紫',0,'件','真实新物品，须扣4印记；重铸不计此行'],
 ['orangeCraft','每千尝试新增打造橙',0,'件','真实新物品，须扣14印记'],
],gr);
fx('全服资源账','B7',`=IF(${sp.attempts}>0,B6/${sp.attempts},0)`);fx('全服资源账','B8',`=${sp.attempts}`);fx('全服资源账','B9',`=${p.selectedDifficultyIndex}`);fx('全服资源账','B10',`=${sp.recovery}`);sheets['全服资源账'].getRange('B7:B10').format.fill=C.white;
val('全服资源账','A19','合账输入检查');fx('全服资源账','B19',`=IF(AND(${sp.status}="有效",${ev.status}="有效",${mk.status}="有效",${rr.status}="有效",COUNTIF('商店与活动'!$J$24:$J$30,"检查限购")=0,B6>0,B8>0,B9>=2,MIN(B11:B17)>=0),"有效","检查输入/配装")`);warning('全服资源账','B19');gr.status=ref('全服资源账','$B$19');
block('全服资源账',22,['货币项目','金币/批次','钻石/批次','经济含义'],[
 ['PVE直接带出新增',null,0,'只计当前候选路线成功带出'],
 ['活动直接奖励',null,null,'参与×完成；兑换资源另记'],
 ['卡/魂/碎片商店回收',null,0,'真实NPC扣金，不把资源当免费'],
 ['药剂购买回收',null,0,'不是每次喝药再扣金币'],
 ['三选一刷新回收',null,0,'嵌套频率分别付60/180/450'],
 ['付费包死亡替换回收',null,0,'长期平均；初始采购另需本金'],
 ['玩家市场税回收',null,null,'成交额本身只是玩家间转移'],
 ['系统赠钻',0,null,'默认0，情景输入'],
 ['充值钻石',0,null,'默认0，情景输入'],
 ['外观钻石回收',0,null,'默认0，情景输入'],
 ['净变化',null,null,'净值不等于所有玩家可持续'],
 ['每活跃人日净变化',null,null,'分母为等效活跃人日'],
]);
const successGold=`INDEX('路线经济'!$B$6:$B$11,${p.selectedDifficultyIndex}+1)`;
const successFragments=`INDEX('路线经济'!$E$6:$E$11,${p.selectedDifficultyIndex}+1)`;
const directFactor=`${ev.count}*${ev.participation}*${ev.completion}/${p.seasonDays}*${gr.playerDays}`;
fx('全服资源账','B23',`=${gr.batch}*${p.extractionRate}*${successGold}`);
fx('全服资源账','B24',`=${ev.directGold}*${directFactor}`);fx('全服资源账','C24',`=${ev.directDiamond}*${directFactor}`);
fx('全服资源账','B25',`=-${gr.playerDays}*${sp.shopResourceGold}`);fx('全服资源账','B26',`=-${gr.playerDays}*${sp.potionGold}`);
fx('全服资源账','B27',`=-${gr.batch}*(60*${sp.refreshFirst}+180*${sp.refreshSecond}+450*${sp.refreshThird})`);
fx('全服资源账','B28',`=-${gr.playerDays}*${sp.bagGold}`);
fx('全服资源账','B29',`=-${gr.batch}/1000*${mk.goldTrades}*MAX(${mk.minFee},ROUNDDOWN(ROUND(${mk.goldPrice}*${mk.goldTax},10),0))`);
fx('全服资源账','C29',`=-${gr.batch}/1000*${mk.diamondTrades}*MAX(${mk.minFee},ROUNDDOWN(ROUND(${mk.diamondPrice}*${mk.diamondTax},10),0))`);
fx('全服资源账','C30',`=${gr.batch}/1000*${gr.diamondGrant}`);fx('全服资源账','C31',`=${gr.batch}/1000*${gr.diamondTopup}`);fx('全服资源账','C32',`=-${gr.batch}/1000*${gr.diamondCosmetics}`);
for(const c of ['B','C']){fx('全服资源账',`${c}33`,`=SUM(${c}23:${c}32)`);fx('全服资源账',`${c}34`,`=IF(B7>0,${c}33/B7,0)`);}
note('全服资源账','A36','默认新增钻石0，净−250/千次是消耗既有存量；没有余额/充值数据，不能据成交就宣称供应健康。');
block('全服资源账',39,['碎片项目','碎片/批次','碎片/每尝试','碎片/每人日','口径'],[
 ['基础格掉带出',null,null,null,'p×逐整数取整均值'],['三选一额外带出',null,null,null,'选碎15%，2倍条件50%'],['金币商店发放',null,null,null,'购包已在金币账扣款'],['活动兑换碎片',null,null,null,'共享章预算，资格账号均值'],['常规死亡重建',null,null,null,'每次失败按66，实际应看消费流水'],['可选+3升+5强化',null,null,null,'升100紫/25橙：18000碎/千次'],['可选升级前净片',null,null,null,'对应日常65.346607'],['可选升级后净片',null,null,null,'仍不表示每个个体流动性足够'],
]);
fx('全服资源账','B40',`=${gr.batch}*${p.extractionRate}*${successFragments}`);fx('全服资源账','B41',`=${gr.batch}*${sp.choicePerAttempt}`);fx('全服资源账','B42',`=${gr.playerDays}*${sp.fragmentDaily}`);fx('全服资源账','B43',`=${gr.playerDays}*${ev.fragmentDay}`);fx('全服资源账','B44',`=-${gr.batch}*(1-${p.extractionRate})*${refs.rebuildWithReforge}`);
const costAbove3=quality=>`SUMIFS('成长与装备'!$E$33:$E$57,'成长与装备'!$A$33:$A$57,"${quality}",'成长与装备'!$B$33:$B$57,">3")`;
fx('全服资源账','B45',`=-${gr.batch}/1000*(${gr.purpleUpgrades}*${costAbove3('purple')}+${gr.orangeUpgrades}*${costAbove3('orange')})`);fx('全服资源账','B46','=SUM(B40:B44)');fx('全服资源账','B47','=SUM(B40:B45)');
for(let r=40;r<=47;r++){fx('全服资源账',`C${r}`,`=B${r}/$B$6`);fx('全服资源账',`D${r}`,`=IF($B$7>0,B${r}/$B$7,0)`);}
vr.dailyFullFragments=ref('全服资源账','$D$46');vr.goldNetDay=ref('全服资源账','$B$34');vr.diamondNet=ref('全服资源账','$C$33');
block('全服资源账',52,['常规品质','自然新增','个人死亡丢失','被他人带出转移','最终真实销毁','正常打造新增','活动直接新增','额外升级吞材料','自然减真毁','加打造/活动减升级','打造耗印记','说明'],[['purple',null,null,null,null,null,null,null,null,null,null,'重铸1入1出不净增'],['orange',null,null,null,null,null,null,null,null,null,null,'本体已持有，升5另吞2']]);
for(const [r,quality,lootCol,wear,upgrade,craft,eventBody,tokenPrice] of [[53,'purple','G',4,gr.purpleUpgrades,gr.purpleCraft,ev.directPurple,p.purpleTokenCost],[54,'orange','H',1,gr.orangeUpgrades,gr.orangeCraft,ev.directOrange,p.orangeTokenCost]]){
 const candidates=data.layers.map((l,i)=>`'参数'!J${75+i}*INDEX('掉落概率'!$${lootCol}$6:$${lootCol}$29,${p.selectedDifficultyIndex}*4+${i+1})`).join('+');
 fx('全服资源账',`B${r}`,`=${gr.batch}*${p.gearChoiceRate}*${p.extractionRate}*(${candidates})`);fx('全服资源账',`C${r}`,`=${gr.batch}*(1-${p.extractionRate})*${wear}`);fx('全服资源账',`D${r}`,`=C${r}*${gr.recovery}`);fx('全服资源账',`E${r}`,`=C${r}-D${r}`);fx('全服资源账',`F${r}`,`=${gr.batch}/1000*${craft}`);fx('全服资源账',`G${r}`,`=${eventBody}*${directFactor}`);fx('全服资源账',`H${r}`,`=${gr.batch}/1000*${upgrade}*2`);fx('全服资源账',`I${r}`,`=B${r}-E${r}`);fx('全服资源账',`J${r}`,`=B${r}-E${r}+F${r}+G${r}-H${r}`);fx('全服资源账',`K${r}`,`=F${r}*${tokenPrice}`);
}
val('全服资源账','A57','本批次印记收入');fx('全服资源账','B57',`=${gr.batch}*${p.extractionRate}*'掉落概率'!B39`);val('全服资源账','C57','打造扣章');fx('全服资源账','D57','=SUM(K53:K54)');val('全服资源账','E57','剩余章');fx('全服资源账','F57','=B57-D57');fx('全服资源账','G57','=IF(F57>=0,"有效","检查印记余额")');warning('全服资源账','G57');
block('全服资源账',60,['常规装备库存压力','数值','单位','说明'],[['日均自然新装',null,'件/人日','五色全部计入，不仅橙紫'],['死亡回收后净新增',null,'件/人日','未扣升级材料、丢弃和换装回收'],['养成仓库容量',v2.results.warehousePressure.warehouseSlots,'格','挂单栏8不是销毁口，不能据流量直接预测满仓日']]);
fx('全服资源账','B61',`=SUM('参数'!$J$75:$J$78)*${p.gearChoiceRate}*${p.extractionRate}*${sp.attempts}`);fx('全服资源账','B62',`=B61-(1-${p.extractionRate})*5*(1-${gr.recovery})*${sp.attempts}`);
block('全服资源账',66,['最终回收率','橙真实销毁','橙升级后净库存','紫真实销毁','紫升级后净库存'],[0,.25,.5,.75,1].map(x=>[x,null,null,null,null]));
for(let r=67;r<=71;r++){input('全服资源账',`A${r}`,[0,.25,.5,.75,1][r-67],'0%');fx('全服资源账',`B${r}`,`=$C$54*(1-A${r})`);fx('全服资源账',`C${r}`,`=$B$54-B${r}+$F$54+$G$54-$H$54`);fx('全服资源账',`D${r}`,`=$C$53*(1-A${r})`);fx('全服资源账',`E${r}`,`=$B$53-D${r}+$F$53+$G$53-$H$53`);}
chart('全服资源账','line',['A66:A71','C66:C71','E66:E71'],'F6','N20','回收率改变真实材料余量','0');
note('全服资源账','A74','ρ=25%时仍按25橙/100紫升5，会净缺54.5橙、34.25紫；ρ=50%时净余20.5橙、265.75紫。');
note('全服资源账','A76','本表失败者新掉落被其他人拾取的额外来源默认0；死亡旧装回收另记，避免同件重复生成。');
note('全服资源账','A78','市场成交是库存转移；只靠交易无法回收全服过剩。打造增加唯一新件，强化材料才销毁真实件。');
note('全服资源账','A80','全服正库存仍可能个人缺货或现金不足；价格、挂牌率、材料需求和资金集中需实测联合校准。');
sheets['全服资源账'].getRange('B23:C34').setNumberFormat('#,##0.00;[Red](#,##0.00)');sheets['全服资源账'].getRange('B40:D47').setNumberFormat('#,##0.0000;[Red](#,##0.0000)');sheets['全服资源账'].getRange('B53:K54').setNumberFormat('#,##0.00;[Red](#,##0.00)');sheets['全服资源账'].getRange('B67:E71').setNumberFormat('0.00;[Red](0.00)');sheets['全服资源账'].getRange('B61:B62').setNumberFormat('0.00');
sheets['全服资源账'].getRange('A1:A95').format.columnWidth=34;sheets['全服资源账'].getRange('B1:C95').format.columnWidth=22;sheets['全服资源账'].getRange('D1:D95').format.columnWidth=40;sheets['全服资源账'].getRange('E1:K95').format.columnWidth=23;sheets['全服资源账'].getRange('L1:L95').format.columnWidth=34;

block('总览',38,['v2补充指标','当前结果','单位','范围'],[
 ['含三选一/店/活动常规净片',null,'碎片/人日','每日整局，未扣可选高阶升级'],
 ['全服金币净变化',null,'金/人日','含所有默认商店/药剂/刷新/市场税'],
 ['全服钻石净变化',null,'钻/千尝试','默认新增0，依赖存量；不能称健康'],
 ['可选高阶升级后净片',null,'碎片/千尝试','100紫+25橙升5另耗18000'],
 ['可选升级后橙/紫库存',null,'橙/千尝试','紫结果在全服资源账，ρ=.5'],
 ['红+5候选累计碎片',null,'碎片','仍需3件真实红，不能重铸'],
 ['活动全选碎的季期望',null,'碎片/资格账号','两期×满额40×覆盖.432'],
]);
const coverV2=[`=${vr.dailyFullFragments}`,`=${vr.goldNetDay}`,`=${vr.diamondNet}`,"='全服资源账'!B47","='全服资源账'!J54",`=${rr.redCost}`,`=${ev.fragmentSeason}`];coverV2.forEach((f,i)=>fx('总览',`B${39+i}`,f));sheets['总览'].getRange('B39:B45').setNumberFormat('0.0000');
block('配置字段',28,['v2对象','关键字段','使用时机','约束','状态'],[
 ['RedWeeklyQuota','logical_server_id, natural_week_key, item_id, channel, transaction_id','所有红生成','同服所有季/地图/渠道共享1，不返额；生成与占额同事务','保留约束'],
 ['MarketCurrencyRules','currency, price_cap, min_fee, tax_rate, season_id, shared_slot_limit','挂单/成交','同件单币单挂；钻永久、季金币/装备隔离；两币不串账','扩展提案'],
 ['ActivityRewards','event_id, season_id, account_id, objective_id, grant_id, shared_tokens','活动发放/兑换','同12章预算择项，直接奖励默认0，原季奖励不流入新季','新增提案'],
 ['RecipeExtraction','original_item_id, recipe_extracted, recipe_source, no_recipe_sample','学配方/重铸/交易','一次提取；交易保留；重铸产物永不再学，红不可学/重铸','修正提案'],
 ['EconomyFlow','source_kind, currency, resource, origin_id, transfer_or_generate, sink_reason','来源/转移/销毁','商店扣币发资源同时记账；遗物和市场不重复创造','扩展提案'],
]);
sheets['配置字段'].getRange('A29:E33').format.wrapText=true;sheets['配置字段'].getRange('A29:E33').format.rowHeight=68;

// Final verification, meaningful input/boundary mutations, and restoration.

// Final verification, meaningful input/boundary mutations, and restoration.
workbook.recalculate();
const independentFile=process.argv[4] || path.join(path.dirname(inputFile),'arithmetic_results.json');
const independent=JSON.parse(await fs.readFile(independentFile,'utf8'));
for(let i=0;i<6;i++){
 const r=6+i,expected=independent.builds[i];
 check(`成长${expected.id}伤害`,read('成长与装备',`H${r}`)===expected.hit,read('成长与装备',`H${r}`));
 check(`成长${expected.id}间隔`,near(read('成长与装备',`G${r}`),expected.interval),read('成长与装备',`G${r}`));
 check(`成长${expected.id}吞吐`,near(read('成长与装备',`I${r}`),expected.drawThroughputProxy),read('成长与装备',`I${r}`));
 const e=independent.economy[i];
 for(const [cell,key] of [['B','gold'],['C','soul'],['D','classSoul'],['E','fragments'],['H','fragmentsPerDay'],['J','fragmentNetPerDay'],['K','breakEven']])check(`路线${e.difficulty}${key}`,near(read('路线经济',`${cell}${r}`),e[key]),read('路线经济',`${cell}${r}`));
}
check('常规重建60',read('成长与装备','D26')===60,read('成长与装备','D26'));
check('全+5重建780',read('成长与装备','D27')===780,read('成长与装备','D27'));
check('含模板重铸成本66',read('成长与装备','D28')===66,read('成长与装备','D28'));
check('D2强化净10每次',near(read('路线经济','N8'),10),read('路线经济','N8'));
check('D2含重铸净8.2每次',near(read('路线经济','O8'),8.2),read('路线经济','O8'));
check('默认30级XP12525',read('赛季进度','B12')===12525,read('赛季进度','B12'));
check('目标橙单次0.0042',near(read('掉落概率','B35'),independent.lootRisk.p),read('掉落概率','B35'));
check('目标橙P90为548',read('掉落概率','B38')===548,read('掉落概率','B38'));
check('定向橙最多14成功局',read('掉落概率','B42')===14,read('掉落概率','B42'));
for(const [label,name,cell,expected] of [
 ['D2基础碎片40','商店与活动','C77',v2.results.sources.successBaseFragments],
 ['D2独立2倍碎片86.5','商店与活动','D77',v2.results.sources.successDoubleChoiceFragments],
 ['额外选择碎片每尝试','商店与活动','B79',v2.results.sources.additionalChoiceFragmentsPerAttempt],
 ['活动季人均34.56','商店与活动','D65',v2.results.event.meanFragmentsPerActiveSeason],
 ['活动集中峰值17.28','商店与活动','F65',v2.results.event.meanFragmentsOnOneEventBurstDay],
 ['全来源常规净片65.346607','全服资源账','D46',v2.results.dailyFragments.netAll],
 ['金币全服净额','全服资源账','B33',v2.results.globalCurrencies.goldNet],
 ['金币人日净额32.75','全服资源账','B34',v2.results.globalCurrencies.goldNetPerActiveDay],
 ['钻石依赖存量净250','全服资源账','C33',v2.results.globalCurrencies.diamondNet],
 ['全服额外强化18000碎','全服资源账','B45',-v2.results.globalFragments.optionalUpgradeSpend],
 ['全服可选升级后净碎','全服资源账','B47',v2.results.globalFragments.netAfterOptionalUpgrade],
 ['天然橙本体220.5','全服资源账','B54',v2.results.globalStock[2].orange.naturalNew],
 ['天然紫本体1065.75','全服资源账','B53',v2.results.globalStock[2].purple.naturalNew],
 ['真实销毁橙150','全服资源账','E54',v2.results.globalStock[2].orange.finallyDestroyed],
 ['真实销毁紫600','全服资源账','E53',v2.results.globalStock[2].purple.finallyDestroyed],
 ['升级后橙20.5','全服资源账','J54',v2.results.globalMaterials.orangeNetAfterOptionalUpgrades],
 ['升级后紫265.75','全服资源账','J53',v2.results.globalMaterials.purpleNetAfterOptionalUpgrades],
 ['自然新装日12.6','全服资源账','B61',v2.results.warehousePressure.newGearPerActiveDay],
 ['真毁后日新增10.35','全服资源账','B62',v2.results.warehousePressure.netNewBeforeUpgradeAndDiscardPerActiveDay],
 ['红候选累计390','红装周投放','E39',v2.red.candidateCosts.reduce((a,b)=>a+b,0)],
 ['红强化物理三件','红装周投放','G39',1+v2.red.extraBodiesFor4+v2.red.extraBodiesFor5],
 ['紫加工回本价184','双币市场','H43',v2.results.processingExamples[0].minimumSaleToRecoverCostGold],
 ['橙加工回本价591','双币市场','H44',v2.results.processingExamples[1].minimumSaleToRecoverCostGold],
 ])check(label,near(read(name,cell),expected),read(name,cell));
v2.results.redWeekly.forEach((e,i)=>{const r=23+i;for(const [c,k] of [['B','weeklyAnyGenerated'],['E','sixWeeksExpectedRetained'],['F','probRetainedAtLeast3'],['G','expectedMaxPlus5IfPerfectlyConcentrated']])check(`红周${e.bossKills}_${k}`,near(read('红装周投放',`${c}${r}`),e[k]),read('红装周投放',`${c}${r}`));});
v2.results.marketDepth.forEach((e,i)=>{const r=49+i;check(`样本市场${e.activePlayers}`,near(read('双币市场',`E${r}`),e.probAnyUnusedSample48h),read('双币市场',`E${r}`));});
check('总账默认输入有效',read('全服资源账','B19')==='有效',read('全服资源账','B19'));
check('D2常规橙帽与红带入帽分离',read('参数','J67')===4 && read('参数','N67')===5,[read('参数','J67'),read('参数','N67')]);
val('商店与活动','F24',2);workbook.recalculate();check('增购碎片包同步加片',near(read('全服资源账','D46'),v2.results.dailyFragments.netAll+20),read('全服资源账','D46'));check('增购碎片包同步扣金币',near(read('全服资源账','B34'),v2.results.globalCurrencies.goldNetPerActiveDay-120),read('全服资源账','B34'));val('商店与活动','F24',v2.shops[0].defaultPacksPerDay);
val('商店与活动','B16',.25);workbook.recalculate();check('回收25%同步橙缺口',near(read('全服资源账','J54'),-54.5),read('全服资源账','J54'));check('回收25%同步紫缺口',near(read('全服资源账','J53'),-34.25),read('全服资源账','J53'));val('商店与活动','B16',v2.assumptions.deadGearRecoveredRate);
val('商店与活动','B7',.2);workbook.recalculate();check('三选一和异常可见',read('商店与活动','B18')==='检查输入',read('商店与活动','B18'));val('商店与活动','B7',v2.assumptions.fragmentChoiceRate);
val('商店与活动','B12',.2);workbook.recalculate();check('刷新频率递减校验',read('商店与活动','B18')==='检查输入',read('商店与活动','B18'));val('商店与活动','B12',v2.assumptions.refreshSecondRate);
val('商店与活动','B9',1.1);workbook.recalculate();check('概率上界校验',read('商店与活动','B18')==='检查输入',read('商店与活动','B18'));val('商店与活动','B9',v2.assumptions.doubleFragmentBiasRate);
val('双币市场','C37',2001);workbook.recalculate();check('橙钻石限价校验',read('双币市场','G37')==='检查币种/价格',read('双币市场','G37'));val('双币市场','C37',2000);
val('双币市场','B35','diamond');workbook.recalculate();check('白装钻币禁价校验',read('双币市场','G35')==='检查币种/价格',read('双币市场','G35'));val('双币市场','B35','gold');
val('商店与活动','F57',1);workbook.recalculate();check('活动共享预算不可叠满',read('商店与活动','D61')==='检查活动预算',read('商店与活动','D61'));val('商店与活动','F57',0);
for(const days of [30,60]){
 val('参数','B6',days);workbook.recalculate();const e=independent.season.find(s=>s.days===days);
 check(`${days}天XP费用`,read('赛季进度','B12')===e.xpTotal,read('赛季进度','B12'));
 check(`${days}天常规重建`,read('成长与装备','D26')===e.cost3,read('成长与装备','D26'));
 check(`${days}天全+5重建`,read('成长与装备','D27')===e.cost5,read('成长与装备','D27'));
}
val('参数','B6',data.assumptions.seasonDays);
val('参数','B7',30);workbook.recalculate();check('30分钟每日仅一整局',read('路线经济','C54')===1,read('路线经济','C54'));check('30分钟整局季内不足',read('赛季进度','C14')==='均值季内不足',read('赛季进度','C14'));
val('参数','B7',data.assumptions.dailyMinutes);
val('参数','B9',0);workbook.recalculate();check('零撤离无毛收益',read('路线经济','H8')===0,read('路线经济','H8'));check('零撤离显示不可获取',read('掉落概率','B36')==='不可获得',read('掉落概率','B36'));
val('参数','B9',1);workbook.recalculate();check('全部撤离无死亡重建',read('路线经济','I8')===0,read('路线经济','I8'));
val('参数','B9',data.assumptions.extractionRate);
val('参数','B8',null);workbook.recalculate();check('局时缺失显式不可计算',read('路线经济','B54')==='缺少有效时长',read('路线经济','B54'));
val('参数','B8',0);workbook.recalculate();check('零局时显式不可计算',read('路线经济','B54')==='缺少有效时长',read('路线经济','B54'));
val('参数','B8',data.assumptions.minutesPerAttempt);
val('参数','B10',0);workbook.recalculate();check('D0天然橙不可获得',read('掉落概率','B36')==='不可获得',read('掉落概率','B36'));
val('参数','B10',data.assumptions.selectedDifficultyIndex);
const editedLootRow=lootRows['2_3'];val('掉落概率',`H${editedLootRow}`,0.4);workbook.recalculate();check('概率和异常可见',read('掉落概率',`L${editedLootRow}`)==='检查概率/品质帽',read('掉落概率',`L${editedLootRow}`));val('掉落概率',`H${editedLootRow}`,data.loot.find(l=>l.id==='2_3').weights[4]);
workbook.recalculate();
const errors=await workbook.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:300},maxChars:6000,summary:'Final formula error scan'});
await fs.writeFile(path.join(qaDir,'Workbook_Formula_Inspection_v2.txt'),errors.ndjson);
console.log(errors.ndjson);
const summary=await workbook.inspect({kind:'table',range:'总览!A38:D45',include:'values,formulas',tableMaxRows:8,tableMaxCols:4,maxChars:8000});
await fs.writeFile(path.join(qaDir,'Workbook_Summary_Inspection_v2.txt'),summary.ndjson);
await fs.writeFile(path.join(qaDir,'Workbook_Validation_v2.json'),JSON.stringify({version:v2.meta.version,engine:'@oai/artifact-tool',nativeExcelTested:false,fullCombatSimulation:false,checks:validationResults,restoredInputs:true},null,2));
const previewRanges={
 '总览':['A1:M46'],
 '参数':['A1:E46','A64:N87'],
 '难度与怪物':['A1:Q27'],
 '掉落概率':['A33:L51'],
 '路线经济':['A1:R14'],
 '配置字段':['A28:E33'],
 '红装周投放':['A1:M29','A33:J66','A80:F94'],
 '双币市场':['A1:H44','A48:N70'],
 '商店与活动':['A1:J35','A39:I70','A72:F96'],
 '全服资源账':['A1:N36','A39:L63','A66:F80'],
};
await fs.mkdir(path.join(qaDir,'previews_v2'),{recursive:true});
for(const name of Object.keys(previewRanges)){let n=0;for(const range of previewRanges[name]){const preview=await workbook.render({sheetName:name,range,scale:1.25,format:'png'});await fs.writeFile(path.join(qaDir,'previews_v2',`${name}_${++n}.png`),new Uint8Array(await preview.arrayBuffer()));}}
const exported=await SpreadsheetFile.exportXlsx(workbook);await exported.save(path.join(outputDir,'Season_Balance_Model.xlsx'));
await fs.rename(path.join(outputDir,'Season_Balance_Model.xlsx.inspect.ndjson'),path.join(qaDir,'Season_Balance_Model.xlsx.inspect.ndjson'));
console.log(JSON.stringify({file:path.join(outputDir,'Season_Balance_Model.xlsx'),worksheets:sheetNames.length,checks:validationResults.length,previewCount:Object.values(previewRanges).reduce((a,v)=>a+v.length,0)}));
